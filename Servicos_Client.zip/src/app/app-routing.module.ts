import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';

const routes: Routes = [
   {
      path: 'steelworks/:id_line',
      loadChildren: './processes/steelworks/steelworks.module#SteelworksModule'
   },
   {
      path: '',
      redirectTo: '',
      pathMatch: 'full'
   }
];

@NgModule({
   imports: [RouterModule.forRoot(routes, { useHash: true, preloadingStrategy: PreloadAllModules })],
   exports: [RouterModule]
})
export class AppRoutingModule { }
