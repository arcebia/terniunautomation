import { Pipe, PipeTransform } from '@angular/core';
import { jsonpCallbackContext } from '@angular/common/http/src/module';

@Pipe({
   name: 'HeaderGraph'
})

export class HeaderGraphComponentPipe implements PipeTransform {
   transform(string: any, ...args: any[]): any {
      if (string) {
         return JSON.parse(string);
      } else {
         return null;
      }
   }
}
