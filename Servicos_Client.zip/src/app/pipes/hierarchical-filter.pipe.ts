import { Pipe, PipeTransform, Injectable } from '@angular/core';
import * as _ from 'lodash';

@Pipe({
   name: 'Hfilter',
   pure: false
})
@Injectable()
export class HierachicalFilterPipe implements PipeTransform {

   /**
    * @items = object from array
    * @term = term's search
    */
   transform(items: any, term: any): any {
      if (term === undefined) return items;
      return this.filterItems(items, term);
   }

   filterItems(items, term) {
      return _.filter(items, (item) => {
         for (const property in item) {
            if (item[property] === null) {
               continue;
            }
            if (Array.isArray(item[property])) {
               if (item[property].length > 0) {
                  const arrItems = this.filterItems(item[property], term);
                  if (arrItems && arrItems.length > 0) {
                     return true;
                  }
               }
            }
            if (item[property].toString().toLowerCase().includes(term.toLowerCase())) {
               return true;
            }
         }
         return false;
      });
   }
}
