import { Pipe, PipeTransform } from '@angular/core';

/*
 * Raise the value exponentially
 * Takes an exponent argument that defaults to 1.
 * Usage:
 *   value | keys
 * Example:
 *   {{ {a: []} |  keys}}
 *   formats to: [{key: a, values: []}]
*/
@Pipe({ name: 'keys' })
export class KeysPipe implements PipeTransform {
   transform(value, args: string[]): any {
      const keys = [];
      // tslint:disable-next-line:forin
      for (const key in value) {
         keys.push({ key: key, value: value[key] });
      }
      return keys;
   }
}
