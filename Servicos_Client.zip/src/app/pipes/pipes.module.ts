import { NgModule } from '@angular/core';

import { FilterPipe } from './filter.pipe';
import { HierachicalFilterPipe } from './hierarchical-filter.pipe';
import { IsEmptyPipe } from './is-empty.pipe';
import { KeysPipe } from './keys.pipe';
import { DateFormatPipe } from './date-format.pipe';
import { HeaderGraphComponentPipe } from './header-graph-component.pipe';

@NgModule({
   imports: [],
   exports: [
      FilterPipe,
      HierachicalFilterPipe,
      IsEmptyPipe,
      KeysPipe,
      DateFormatPipe,
      HeaderGraphComponentPipe
   ],
   declarations: [
      FilterPipe,
      HierachicalFilterPipe,
      IsEmptyPipe,
      KeysPipe,
      DateFormatPipe,
      HeaderGraphComponentPipe
   ],
   providers: [],
})
export class PipesModule { }
