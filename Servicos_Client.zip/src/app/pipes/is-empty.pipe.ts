import { Pipe, PipeTransform } from '@angular/core';
import * as _ from 'lodash';

/*
 * Raise the value exponentially
 * Takes an exponent argument that defaults to 1.
 * Usage:
 *   value | isEmpty:exponent
 * Example:
 *   {{ 2 |  isEmpty:10}}
 *   formats to: 1024
*/
@Pipe({ name: 'isEmpty' })
export class IsEmptyPipe implements PipeTransform {
   transform(input: any): boolean {
      return _.size(input) === 0;
   }
}
