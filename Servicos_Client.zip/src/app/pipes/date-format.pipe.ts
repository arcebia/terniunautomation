import { Pipe, PipeTransform } from '@angular/core';

import * as moment from 'moment';

/*
 * Raise the value exponentially
 * Takes an exponent argument that defaults to 1.
 * Usage:
 *   value | dateFormat:exponent
 * Example:
 *   {{ 2 |  dateFormat:10}}
 *   formats to: 1024
*/
@Pipe({ name: 'dateFormat' })
export class DateFormatPipe implements PipeTransform {
   transform(input: string, hhmm: boolean, hhmmss: boolean): string {
      let format = 'DD/MM/YYYY';
      const formatHHMM = 'HH:mm';
      const formatHHMMSS = ':ss';
      if (hhmm) {
         format += ' ' + formatHHMM;
      }
      if (hhmmss) {
         format += formatHHMMSS;
      }
      // if (moment(input).isValid()) {
      if (!input) {
         return '';
      } else if (!moment.isMoment(input) && (input.indexOf('AM') > -1 || input.indexOf('PM') > -1)) {
         return moment(input, 'MM/DD/YYYY HH:mm:ss A').format(format);
      } else {
         return moment(input).format(format);
      }
      // } else {
      // return moment(input, 'DD/MM/YYY HH:mm:ss a').format(format);
      // }
   }
}
