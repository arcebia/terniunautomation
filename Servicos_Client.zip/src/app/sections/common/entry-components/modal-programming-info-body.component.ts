// import { Component, OnInit, Input } from '@angular/core';

// export class DataModal {
//    data: any;
// }

// @Component({
//    selector: 'modal-programming-info-body',
//    templateUrl: './modal-programming-info-body.component.html'
// })

// export class ModalProgrammingInfoBodyComponent implements OnInit {
//    @Input() generals: any = [];
//    @Input() generalsExtra: any;
//    @Input() specifications: any;

//    variable: any;
//    collapsedRadiation: any;
//    collapsedDimension: any;

//    ngOnInit() {

//    }
// }
