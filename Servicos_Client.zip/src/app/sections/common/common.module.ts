// import { NgModule } from '@angular/core';
// import { FormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// import { NgbCollapseModule, NgbPopoverModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';

// import { SharedModule } from 'src/app/shared/shared.module';
// import { PipesModule } from 'src/app/pipes/pipes.module';

// import { ModalProgrammingInfoBodyComponent } from './entry-components/modal-programming-info-body.component';
// // import { MaterialInfoComponent } from './components/material-info.component';


// @NgModule({
//    imports: [
//       FormsModule,
//       SharedModule,
//       NgbCollapseModule,
//       NgbPopoverModule,
//       NgbTooltipModule,
//       PipesModule,
//       CommonModule,
//    ],
//    exports: [
//       ModalProgrammingInfoBodyComponent,

//    ],
//    declarations: [
//       ModalProgrammingInfoBodyComponent,

//    ],
//    entryComponents: [
//       ModalProgrammingInfoBodyComponent,

//    ],
//    providers: [

//    ],
// })
// export class CommonsModule { }
