// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute } from '@angular/router';

// import * as _ from 'lodash';
// import * as moment from 'moment';

// import { SharedService } from 'src/app/services/shared.service';
// import { CurvesService } from 'src/app/services/curves.service';
// import { ProductionService } from 'src/app/services/production.service';
// import { DatepickerService } from 'src/app/services/datepicker.service';
// import { ChartService } from 'src/app/services/chart.service';

// @Component({
//    selector: 'curves',
//    templateUrl: './curves.component.html'
// })

// export class CurvesComponent implements OnInit {

//    selectedTypeChart: any;
//    selectedType3dGraph: any[] = [];
//    material: any;
//    ofa: any;
//    defects: any;
//    config: any;
//    joinYAxis: boolean;
//    multiPanel: boolean;
//    selectedX: any;
//    selectedY: any[];
//    loadingGraph: boolean;
//    graphLoaded: boolean;
//    graph: any;
//    graphList: any[] = [];
//    title: string;
//    idLine: string;
//    search = ''; // 3A577060UG200;
//    activeLimits = false;
//    dataCurves: any;
//    tableGridCurves2d: {
//       containerHeight: 100
//    };
//    xConfig = {
//       attribute: 'description',
//       multiple: false,
//       list: [],
//       classes: '',
//       classesBtn: 'btn-default full-width',
//       classesItems: 'full-width',
//       id: 'xDropdown',
//       nonSelectionText: 'Eje X',
//       loading: true
//    };
//    yConfig = {
//       attribute: 'description',
//       multiple: true,
//       list: [],
//       classes: '',
//       classesBtn: 'btn-default full-width',
//       classesItems: 'full-width',
//       id: 'yDropdown',
//       nonSelectionText: 'Variables',
//       multipleSelectionText: 'Múltiples Variables',
//       loading: true,
//       search: true
//    };

//    typeChartConfig = {
//       attribute: 'curve_type',
//       multiple: false,
//       list: [],
//       classes: '',
//       classesBtn: 'btn-default full-width',
//       classesItems: 'full-width',
//       id: 'SConfigTypeChar',
//       nonSelectionText: 'Tipo de Gráfico',
//       multipleSelectionText: 'Múltiples Variables',
//       loading: false,
//       search: false
//    };

//    Type3dGraphSelection = {
//       attribute: 'name',
//       multiple: true,
//       list: [],
//       classes: '',
//       classesBtn: 'btn-default',
//       classesItems: '',
//       id: 'type_graph_selection',
//       nonSelectionText: 'Seleccione una variable', // Estado de Cobertura
//       multipleSelectionText: 'Múltiples Secciones',
//       loading: false
//    };
//    chartHeight: number;
//    idExit: any;
//    message: string;
//    noData = false;
//    maxLimitY: number = null;
//    minLimitY: number = null;
//    params: any;
//    isCurves3D: any;
//    type_planeza: any = [];
//    curveData3D: any[] = [];
//    graphList3D: any = [];
//    curvesPUI: any = [];
//    typeChartData: any = [];
//    constructor(
//       private activatedRoute: ActivatedRoute,
//       public sharedService: SharedService,
//       private curvesService: CurvesService,
//       private productionService: ProductionService
//    ) {

//       this.idLine = this.activatedRoute.snapshot.paramMap.get('id_line');
//       this.idExit = this.activatedRoute.snapshot.queryParamMap.get('id_exit');
//       this.material = this.activatedRoute.snapshot.queryParamMap.get('material');
//       this.ofa = this.activatedRoute.snapshot.queryParamMap.get('ofa');
//       this.search = this.material;
//       // this.sharedService.updateIdLine(this.idLine);
//       // this.sharedService.updateState(this.$state.$current);
//       // this.sharedService.idLine = this.idLine;
//    }

//    ngOnInit(): void {
//       this.graphLoaded = false;
//       this.loadingGraph = true;
//       this.getConfig();
//    }

//    getCurves3D() {
//       this.curvesService.getCurves3D(this.params)
//          .then((resp) => {
//             if (resp.success) {
//                this.Type3dGraphSelection.list = resp.dropdown_labels;
//                this.curveData3D = resp.curves;
//             }
//          });
//    }

//    getValueRangeY(val) {
//       if (val > 0) {
//          return val + 10;
//       } else {
//          return val - 10;
//       }
//    }

//    selectTypeChart(item) {
//       this.graphLoaded = false;
//       this.loadingGraph = true;
//       this.isCurves3D = item.curve_type.toLowerCase() !== 'curva';

//       if (this.isCurves3D) {
//          this.Type3dGraphSelection.list[0].selected = true;
//          this.selectType3dPlaneza(this.Type3dGraphSelection.list);
//       }

//       setTimeout(() => {
//          this.graphLoaded = true;
//          this.loadingGraph = false;
//       }, 500);
//    }

//    selectType3dPlaneza(list) {
//       this.graphList3D = [];
//       _.each(list, (o, i) => {
//          if (o.selected) {
//             const curveData = _.find(this.curveData3D, { id_variable: o.id_variable });
//             const curveConfig = this.curvesService.getSioBasicConfigCurved3d(curveData, 'graph-p-' + i, curveData.description);
//             curveConfig.layout.height = this.chartHeight;
//             this.graphList3D.push(curveConfig);
//          }
//       });
//    }

//    existingInSelected(str) {
//       return this.type_planeza.indexOf(str) > -1 ? true : false;
//    }

//    getCurvesTypes(curvesTypes) {
//       this.params = {
//          id_line: this.idLine,
//          id_exit: this.idExit,
//          id_variable_type: ''
//       };
//       this.getCurves3D();
//       this.selectedTypeChart = this.typeChartConfig.list[0];
//    }

//    getConfig() {
//       this.curvesService.getCurveConfig({ material: this.idExit, id_line: this.idLine })
//          .then((resp) => {
//             this.config = resp;
//             this.joinYAxis = this.config.join_y_axis_default === 1;
//             this.multiPanel = this.config.multi_panel_default === 1;
//             this.xConfig.list = resp.x_axis;
//             this.yConfig.list = resp.y_axis;
//             const selectedX = _.find(this.xConfig.list, (item: any) => item.selected === true);
//             if (selectedX) {
//                this.selectX(selectedX);
//             } else {
//                this.selectX(this.xConfig.list[0]);
//             }
//             this.typeChartConfig.list = resp.curve_types;
//             if (resp.curve_types.length > 0) {
//                this.getCurvesTypes(resp.curve_types);
//             }
//             this.xConfig.loading = false;
//             this.yConfig.loading = false;
//             console.log('typeChartConfig.list', resp);
//          });
//    }

//    selectX(item) {
//       this.selectedX = item;
//       this.curvesService.getYAxis({ x_axi: item.id_variable, id_line: this.idLine })
//          .then((resp) => {

//             this.yConfig.list = resp;
//             if (resp.length > 0) {
//                const selected = _.filter(this.yConfig.list, (item: any) => item.selected === true);
//                if (selected.length === 0) {
//                   // resp[0].selected = true;
//                   this.selectY([resp[0]]);
//                } else {
//                   this.selectY(selected);
//                }
//             }
//          });
//    }

//    selectY(item) {
//       this.selectedY = item;
//       this.getCurveData();
//    }

//    getCurveData() {
//       const body = {
//          'id_exit': this.idExit,
//          'material': '',
//          'id_line': this.idLine,
//          'x_axis_description': this.selectedX.description,
//          'y_axis_list': this.selectedY, // _.map(material.selectedY, 'tag'),
//          'y_axis_description': _.map(this.selectedY, 'id_variable')
//       };

//       this.curvesService.getCurveData(body)
//          .then((resp) => {
//             this.dataCurves = resp;
//             this.renderData(resp);
//          });
//    }

//    findMaterial() {
//       this.loadingGraph = true;
//       const params = {
//          id_line: this.idLine,
//          start_date: moment().format('YYYY-MM-DD'),
//          end_date: moment().format('YYYY-MM-DD'),
//          filter: this.search
//       };
//       this.productionService.getProductionSearch(params)
//          .then((resp) => {
//             if (resp.length > 0) {
//                const material = resp[0];
//                // this.$state.go('curves', { id_line: this.idLine, id_exit: material.id_exit, material: material.exit_material, ofa: material.need });
//             }
//             this.loadingGraph = false;
//          });
//    }

//    getNextPreviousCoil(is_previous) {
//       const params = {
//          id_exit: this.idExit,
//          is_previous: is_previous
//       };
//       this.curvesService.getNextPreviousCoil(params)
//          .then((resp) => {
//             // this.$state.go('curves', { id_line: this.idLine, id_exit: resp.id_exit, material: resp.material, ofa: resp.ofa });
//          });
//    }

//    renderData(resp) {
//       this.loadingGraph = true;
//       this.graphLoaded = false;
//       this.graphList = [];
//       const isArray = _.isArray(resp);
//       if ((isArray && resp.length === 0) || (!isArray && !resp.Success)) {
//          this.loadingGraph = false;
//          this.graphLoaded = false;
//          this.message = resp.ResponseText;
//          this.noData = true;
//       } else {
//          const data = resp.YAxis;
//          this.title = '<b>Material:</b> ' + this.material + '<br>';
//          if (!_.isEmpty(this.ofa)) {
//             this.title += '<b>OFA:</b> ' + this.ofa + ' ';
//          }
//          if (data[0].AdditionalInformation) {
//             this.title += data[0].AdditionalInformation;
//          }
//          if (this.activeLimits) {
//             _.each(data, (o: any, i) => {
//                const yValues = _.clone(o.Y || o.Values);
//                yValues.push(this.maxLimitY);
//                yValues.push(this.minLimitY);
//                this.maxLimitY = +_.max(yValues);
//                this.minLimitY = +_.min(yValues);
//             });
//          }
//          this.getChartHeight();
//          if (!this.multiPanel) {
//             this.graph = this.getChartConfig(0);
//             this.graph.config.title.text = this.title;
//          }
//          _.each(data, (o: any, i) => {
//             const xValues = resp.XAxi[0].Values;
//             const yValues = o.Y || o.Values;
//             const maximumLimit = o.maxValue || o.MaximumLimit;
//             const minimumLimit = o.minValue || o.MinimumLimit;
//             const chartConfig = {
//                xValues: _.map(xValues, parseFloat),
//                yValues: _.map(yValues, parseFloat),
//                maxValue: _.max(_.map(xValues, parseFloat)),
//                MaximumLimit: maximumLimit,
//                MinimumLimit: minimumLimit,
//                i: i,
//                data: data,
//                o: o,
//                selectedValues: this.selectedY
//             };
//             if (!this.multiPanel) {
//                this.setNonMultipanelData(chartConfig);
//             } else {
//                this.setMultipanelData(chartConfig);
//             }
//          });

//          if (!this.multiPanel) {
//             this.graphList.push(this.graph);
//          }

//          setTimeout(() => {
//             this.graphLoaded = true;
//             this.loadingGraph = false;
//          }, 500);
//       }
//    }

//    getChartConfig(id) {
//       const graph: any = {};
//       graph.series = [];
//       let height = null;
//       if (!this.multiPanel) {
//          height = this.chartHeight;
//       } else {
//          height = this.selectedY.length === 4 ? this.chartHeight / this.selectedY.length : 170;
//       }
//       graph.config = this.curvesService.getSIOBasicConfig(this.selectedX, height, 'chartCurves-' + id);
//       graph.config.xAxis.plotBands = [];
//       graph.config.enabledExport = true;
//       return graph;
//    }

//    setNonMultipanelData(chartConfig) {
//       const i = chartConfig.i;
//       chartConfig.xValues = this.curvesService.convertToDateTime(chartConfig.xValues, this.selectedX);
//       const serie = this.curvesService.getYAxi(chartConfig.selectedValues[i], i);
//       const yAxis = this.curvesService.getYAxisSIOConfig(chartConfig.selectedValues[i], i);
//       this.graph.series.push(serie);
//       this.curvesService.setSeriesData(chartConfig.xValues, chartConfig.yValues, serie);
//       if (chartConfig.data.length === 1) {
//          this.curvesService.getLimitsMaxMin(yAxis, chartConfig.MaximumLimit, chartConfig.MinimumLimit, chartConfig.yValues);
//          this.curvesService.getPlotLineBands(yAxis, chartConfig.o);
//       }
//       if (this.activeLimits) {
//          yAxis.min = this.minLimitY;
//          yAxis.max = this.maxLimitY;
//       }
//       this.graph.config.yAxis.push(yAxis);
//    }

//    setMultipanelData(chartConfig) {
//       const i = chartConfig.i;
//       chartConfig.xValues = this.curvesService.convertToDateTime(chartConfig.xValues, this.selectedX);
//       const serie = this.curvesService.getYAxi(chartConfig.selectedValues[i]);
//       serie.color = this.sharedService.colorsHighcharts[i];
//       delete serie.yAxis;

//       const title = this.getTitle(chartConfig.o, true);
//       let graph: any = {};
//       graph = this.getChartConfig(i);
//       graph.config.title.text = title;
//       this.curvesService.setSeriesData(chartConfig.xValues, chartConfig.yValues, serie);
//       graph.series.push(serie);
//       graph.config.yAxis = this.curvesService.getYAxisSIOConfig(chartConfig.selectedValues[i], i);
//       graph.config.yAxis.labels.style.color = '#666666';
//       graph.config.yAxis.title.style.color = '#666666';
//       graph.config.xAxis.title.text = '';
//       this.curvesService.getLimitsMaxMin(graph.config.yAxis, chartConfig.MaximumLimit, chartConfig.MinimumLimit, chartConfig.yValues);
//       this.curvesService.getPlotLineBands(graph.config.yAxis, chartConfig.o);
//       this.graphList.push(graph);
//    }

//    getTitle(o: any, showLimits) {
//       let title = '';
//       title += '<b>' + o.description.toUpperCase() + '</b>';
//       if (showLimits && o.MaximumLimit && o.MinimumLimit && o.TargetLimit) {
//          title += ' - <b>Límites:</b> ' + o.MinimumLimit + '/' + o.TargetLimit + '/' + o.MaximumLimit;
//       }
//       if (_.trim(o.TexpertComment)) {
//          title += ' - <b>Comentario TExpert:</b> ' + o.TexpertComment;
//       }
//       return title;
//    }

//    toggleJoin() {
//       this.joinYAxis = !this.joinYAxis;
//       this.renderData(this.dataCurves);
//    }

//    toggleMultipanel() {
//       this.multiPanel = !this.multiPanel;
//       this.renderData(this.dataCurves);
//    }

//    toggleLimits() {
//       this.activeLimits = !this.activeLimits;
//       this.renderData(this.dataCurves);
//    }


//    getChartHeight() {
//       this.chartHeight = window.innerHeight - 200;
//    }


// }
