// import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
// import { ElementRef, HostListener } from '@angular/core';

// import { D3Service, D3, Selection } from 'd3-ng2-service';
// import * as _ from 'lodash';

// @Component({
//    selector: 'superficial-inspection',
//    templateUrl: './superficial-inspection.component.html'
// })
// export class SuperficialInspectionComponent implements OnInit {
//    @Input() data: any;
//    @Input() showTable: boolean;
//    @Input() legend: boolean;
//    @Input() allDefects: any[] = [];
//    @Output() change = new EventEmitter();

//    private d3: D3;
//    private parentNativeElement: any;
//    private d3Svg: Selection<SVGSVGElement, any, null, undefined>;
//    private d3ParentElement: Selection<HTMLElement, any, null, undefined>;

//    configInspection: any = {};
//    tooltipInspection: any = {};
//    collapseTable = true;

//    constructor(element: ElementRef, d3Service: D3Service) {
//       this.d3 = d3Service.getD3();
//       this.parentNativeElement = element.nativeElement;
//    }

//    ngOnInit() {
//       this.initRender();
//    }

//    toggleTable() {
//       this.collapseTable = !this.collapseTable;
//       this.change.emit({
//          showTable: this.collapseTable
//       });
//    }

//    @HostListener('window:resize', ['$event']) getWindow(event) {
//       this.initRender(true);
//    }

//    initRender(resize?) {
//       if (this.parentNativeElement !== null) {
//          this.d3ParentElement = this.d3.select(this.parentNativeElement); // <-- use the D3 select method
//          this.d3Svg = this.d3ParentElement.select<SVGSVGElement>('svg');
//          if (this.data.length === 0) return;
//          this.configInspection.svgId = 'svg-inspection-' + this.data[0].id_exit;
//          this.configInspection.containerWidth = document.getElementById('svg-container').offsetWidth;
//          this.configInspection.height = 100;
//          this.configInspection.containerMaterialX = this.configInspection.containerWidth - 80;
//          this.configInspection.containerMaterialY = 75;
//          this.configInspection.xOffset = 40;
//          this.configInspection.lengthMaterial = +this.data[0]['length'];
//          this.configInspection.widthMaterial = +this.data[0]['width'];
//          this.configInspection.layersHigher = ['Operador', 'Centro', 'Motor'];
//          this.configInspection.layersLower = ['Motor', 'Centro', 'Operador'];
//          this.configInspection.partitionsX = 4;
//          this.configInspection.partitionsY = 3;
//          const attrsContainer = {
//             'x': 0,
//             'y': 0,
//             'height': this.configInspection.isEddyCurrent ? this.configInspection.height - 250 : this.configInspection.height,
//             'width': this.configInspection.containerWidth,
//             'fill': 'transparent'
//          };
//          if (resize) {
//             this.d3.select('#' + this.configInspection.svgId).remove();
//             this.d3.select('#svg-container').append('svg').attr('id', this.configInspection.svgId);
//             this.d3Svg = this.d3ParentElement.select<SVGSVGElement>('svg');
//          }
//          this.d3Svg
//             .classed('svg-content', true)
//             .attr('width', attrsContainer.width)
//             .attr('id', this.configInspection.svgId)
//             .attr('height', attrsContainer.height);

//          this.d3Svg
//             .append('rect')
//             .attr('x', attrsContainer.x)
//             .attr('y', attrsContainer.y)
//             .attr('height', attrsContainer.height)
//             .attr('width', attrsContainer.width)
//             .attr('fill', attrsContainer.fill);

//          const tooltipId = this.configInspection.svgId + '-tootltip';
//          this.configInspection.tooltipId = tooltipId;
//          this.d3.select('#' + tooltipId).remove();
//          if (!this.configInspection.isEddyCurrent) {
//             this.tooltipInspection = this.d3.select('body')
//                .append('div')
//                .attrs({
//                   'id': tooltipId
//                })
//                .classed('gantt-tooltip-inspection', true);

//             this.renderLayer('Superior');
//          } else {
//             // this.renderEddyCurrent();
//          }
//       }
//    }

//    clearSvg(svgId) {
//       const svg = this.d3.select('#' + svgId);
//       if (svg) {
//          this.d3Svg.selectAll('*').remove();
//       }
//    }

//    renderLayer(layer) {
//       this.configInspection.yOffset = 5;
//       const data = this.data;

//       const attrsText = {
//          'x': 0,
//          'y': 0,
//          'font-size': '13',
//          'fill': '#666'
//       };

//       const attrsContainerMaterial = {
//          'x': this.configInspection.xOffset,
//          'y': this.configInspection.yOffset,
//          'height': this.configInspection.containerMaterialY,
//          'width': this.configInspection.containerMaterialX,
//          'stroke': '#666',
//          'fill': 'none'
//       };

//       const factorMaterialX = this.configInspection.containerMaterialX / this.configInspection.partitionsX;
//       const factorMaterialY = this.configInspection.containerMaterialY / this.configInspection.partitionsY;

//       const factorPositionX = this.configInspection.containerMaterialX / this.configInspection.lengthMaterial;
//       const factorPositionY = this.configInspection.containerMaterialY / this.configInspection.widthMaterial;

//       const groupLayer = this.d3Svg.append('g').attr('id', layer.toLowerCase());

//       const containerFactorX = this.configInspection.xOffset + this.configInspection.containerMaterialX;

//       groupLayer
//          .append('rect')
//          .attrs(attrsContainerMaterial);

//       const xText = Math.round(this.configInspection.lengthMaterial / this.configInspection.partitionsX);
//       const yText = Math.round(this.configInspection.widthMaterial / this.configInspection.partitionsY);
//       const translateTitle = this.configInspection.yOffset + (this.configInspection.containerMaterialY) / 2;

//       const dataLayers = [];
//       let x = this.configInspection.xOffset;
//       for (let i = 0; i <= this.configInspection.partitionsX; i++) {
//          const groupAxis = groupLayer.append('g').attr('id', layer.toLowerCase() + '-x-' + i);
//          if (i > 0 && i < this.configInspection.partitionsX) {
//             groupAxis
//                .append('line')
//                .attrs({
//                   'x1': x,
//                   'x2': x,
//                   'y1': this.configInspection.yOffset,
//                   'y2': this.configInspection.yOffset + this.configInspection.containerMaterialY
//                });
//          }
//          groupAxis
//             .append('text')
//             .attrs({
//                'class': 'axis-value-x',
//                'x': x,
//                'y': this.configInspection.yOffset + this.configInspection.containerMaterialY + 15
//             })
//             .text(xText * i);
//          x += factorMaterialX;
//       }

//       let name = '';
//       let topValue = 0;
//       let y = this.configInspection.yOffset;
//       const xOffsetAxisName = 8;
//       const yOffsetAxisName = (factorMaterialY - 15) / 2 + 12;
//       const xOffsetAxisValue = containerFactorX + 10;
//       for (let i = 0; i < this.configInspection.partitionsY; i++) {
//          const groupAxis = groupLayer.append('g').attr('id', layer.toLowerCase() + '-y-' + i);
//          if (i > 0 && i < this.configInspection.partitionsY) {
//             groupAxis
//                .append('line')
//                .attrs({
//                   'x1': this.configInspection.xOffset,
//                   'x2': containerFactorX,
//                   'y1': y,
//                   'y2': y
//                });
//          }
//          if (i === 0) {
//             groupAxis
//                .append('text')
//                .attrs({
//                   'class': 'axis-value',
//                   'x': xOffsetAxisValue,
//                   'y': y + 5
//                })
//                .text('0');
//          }
//          name = this.configInspection.layersHigher[i];
//          topValue = yText * (i + 1) - 1;
//          groupAxis
//             .append('text')
//             .attrs({
//                'class': 'axis-value',
//                'x': xOffsetAxisValue,
//                'y': y + factorMaterialY
//             })
//             .text(topValue);
//          groupAxis
//             .append('text')
//             .attrs({
//                'class': 'axis-name',
//                'x': xOffsetAxisName,
//                'y': yOffsetAxisName + y
//             })
//             .text(name.toUpperCase().substring(0, 3) + '.');

//          dataLayers.push({
//             name: name.toLowerCase(),
//             top: topValue,
//             y: y
//          });
//          y += factorMaterialY;
//       }

//       const groupDefects = groupLayer.append('g').attr('id', 'defects-' + layer.toLowerCase());
//       _.each(data, (o, i) => {
//          const dataSide = _.find(dataLayers, { name: o.side.toLowerCase() });
//          const y = dataSide ? dataSide.y : null;
//          if (!o.mts_start && !o.mts_end && o.id_location) {
//             switch (o.id_location) {
//                case 'INI':
//                   o.mts_end = this.configInspection.lengthMaterial / 3;
//                   break;
//                case 'FIN':
//                   o.mts_start = 2 * this.configInspection.lengthMaterial / 3;
//                   o.mts_end = this.configInspection.lengthMaterial;
//                   break;
//                case 'MED':
//                   o.mts_start = this.configInspection.lengthMaterial / 3;
//                   o.mts_end = 2 * this.configInspection.lengthMaterial / 3;
//                   break;
//                case 'INIMED':
//                   o.mts_start = 0;
//                   o.mts_end = 2 * this.configInspection.lengthMaterial / 3;
//                   break;
//                case 'INIFIN':
//                   o.mts_start = 0;
//                   o.mts_end = this.configInspection.lengthMaterial;
//                   break;
//                case 'TOD':
//                   o.mts_start = 0;
//                   o.mts_end = this.configInspection.lengthMaterial;
//                   break;
//                case 'MEDFIN':
//                   o.mts_start = this.configInspection.lengthMaterial / 3;
//                   o.mts_end = this.configInspection.lengthMaterial;
//                   break;
//                default:
//                   break;
//             }
//             o.mts_start = _.round(o.mts_start);
//             o.mts_end = _.round(o.mts_end);
//          }
//          groupDefects
//             .append('rect')
//             .attrs({
//                'x': this.configInspection.xOffset + parseFloat(o.mts_start) * factorPositionX,
//                'y': y,
//                'height': factorMaterialY,
//                'width': (+o.mts_end - +o.mts_start) < 3 ? 3 : (+o.mts_end - +o.mts_start) * factorPositionX,
//                'fill': o.face.toLowerCase() === 'superior' ? '#2C3E50' : (o.face.toLowerCase() === 'inferior' ? '#F39C12' : '#16A085'), // InspectionService.getIntensity(o.intensity),
//                'id': this.configInspection.svgId + '-data-' + i
//             })
//             .on('mouseover', () => {
//                this.tooltipInspection
//                   .transition()
//                   .duration(200)
//                   .style('visibility', 'visible')
//                   .style('cursor', 'pointer');
//                this.tooltipInspection
//                   .html(`
//                         <table class="tooltip-table">
//                             <tbody>
//                                 <tr>
//                                     <td colspan="2" class="header">` + o.defect + `</td></tr>
//                                 <tr>
//                                     <td class="content-title">Prioridad</td>
//                                     <td class="content-value">` + (o.priority || '') + `</td>
//                                 </tr>
//                                 <tr>
//                                     <td class="content-title">Intensidad</td>
//                                     <td class="content-value">` + o.intensity + `</td>
//                                 </tr>
//                                 <tr>
//                                     <td class="content-title">Cara</td>
//                                     <td class="content-value">` + o.face + `</td>
//                                 </tr>
//                                 <tr>
//                                     <td class="content-title">Lado</td>
//                                     <td class="content-value">` + o.side + `</td>
//                                 </tr>
//                                 <tr>
//                                     <td class="content-title">Mts Inicio</td>
//                                     <td class="content-value">` + o.mts_start + `</td>
//                                 </tr>
//                                 <tr>
//                                     <td class="content-title">Mts Fin</td>
//                                     <td class="content-value">` + o.mts_end + `</td>
//                                 </tr>` +
//                      (o.img ?
//                         `<tr>
//                                         <td colspan=2><img width="230" src='` + o.img + `'/></td>
//                                     </tr>` : '')
//                      + `
//                             </tbody>
//                         </table>`)
//                   .style('left', (this.d3.event.pageX + 10) + 'px')
//                   .style('top', (this.d3.event.pageY - 28) + 'px');	// .css("visibility", "visible");
//             })
//             .on('mouseout', (d) => {
//                this.tooltipInspection
//                   .transition()
//                   .duration(500)
//                   .style('visibility', 'hidden');
//             });
//       });
//    }
// }
