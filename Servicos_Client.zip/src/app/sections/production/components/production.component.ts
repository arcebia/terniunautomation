// import { Component, OnInit, ElementRef, OnDestroy, ViewChild } from '@angular/core';
// import { ActivatedRoute, Router } from '@angular/router';

// import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
// import * as _ from 'lodash';

// import { ModalCoilDefectsComponent } from '../entry-components/modal-coil-defects.component';
// import { ModalSuperficialInspectionComponent } from '../entry-components/modal-superficial-inspection.component';
// import { ModalEssaysReportComponent } from '../entry-components/modal-essays-report.component';
// import { ModalProgrammingInfoComponent } from '../../program/entry-components/modal-programming-info.component';
// import { ModalCalendarComponent } from 'src/app/shared/components/modals/modal-calendar.component';

// import { ProductionService } from 'src/app/services/production.service';
// import { SharedService } from 'src/app/services/shared.service';
// import { MaterialInfoService } from 'src/app/services/material-info.service';
// import { BaseService } from 'src/app/services/base.service';
// import { SsiService } from 'src/app/services/ssi.service';

// @Component({
//    selector: 'production',
//    templateUrl: './production.component.html'
// })

// export class ProductionComponent implements OnInit, OnDestroy {

//    @ViewChild('table') table: any;

//    row: any;
//    data: any[];
//    columns: any[];
//    gantt: any = {};
//    summary: any;
//    efficiency: any;
//    status: any;
//    // params = {
//    //     id_line: null,
//    //     date: '',
//    //     shift: null,
//    //     order_asc: false
//    // }
//    params: any = {};
//    dateShift: any;
//    tableConfig = {
//       hasGantt: true,
//       headersType: 'simple',
//       headersPosition: 'fixed',
//       minRows: 5
//    };
//    userConfig: any = {};
//    selectedMaterial: any;
//    lineLoaded = false;
//    idReport = 1;
//    reportTitle = 'Producción';
//    icons = [
//       { icon: 'file_download', format: 'excel', text: 'Exportar a Excel' },
//       { icon: 'format_list_numbered', format: 'customizer', text: 'Customizar Tabla' },
//    ];
//    idLineSubcription: any;

//    isFetchingColumns = true;
//    isFetchingLineStatus = true;
//    isFetchingCoils = true;
//    isFetchingGantt = true;
//    isFetchingSummary = true;
//    isFetchingEfficiency = true;

//    divGanttElement: HTMLElement;

//    constructor(
//       private router: Router,
//       private activatedRoute: ActivatedRoute,
//       private productionService: ProductionService,
//       private baseService: BaseService,
//       private ssiService: SsiService,
//       private modalService: NgbModal,
//       private materialInfoService: MaterialInfoService,
//       public sharedService: SharedService
//    ) { }

//    ngOnDestroy() {
//       if (this.divGanttElement) this.divGanttElement.remove();
//    }

//    ngOnInit() {
//       this.activatedRoute.paramMap.subscribe(async (params) => {
//          this.lineLoaded = true;
//          this.params.id_line = params.get('id_line');
//          this.dateShift = this.sharedService.dateShift.getValue();

//          this.productionService.getProductionColumns(this.params)
//             .then((data) => {
//                this.columns = data;
//                this.isFetchingColumns = false;
//             });

//          this.productionService.getLineStatus(this.params.id_line)
//             .then((data) => {
//                this.status = data;
//                this.isFetchingLineStatus = false;
//             });

//          const userConfigParams: any = {};

//          userConfigParams.id_line = params.get('id_line');
//          userConfigParams.id_report = '1';

//          if (this.sharedService.user.getValue()) {
//             userConfigParams.username = this.sharedService.user.getValue().username;
//          } else {
//             const user = await this.ssiService.getCurrentUser();
//             userConfigParams.username = user.username;
//          }

//          const res = await this.baseService.getReportUserConfig(userConfigParams);
//          if (res.userConfig.columnsConfig) this.userConfig.columns = res.userConfig.columnsConfig;
//          // if (res.UserConfig && res.UserConfig[0] && res.UserConfig[0].colums_config && res.UserConfig[0].colums_config !== '') {
//          //    this.userConfig.columns = JSON.parse(res.UserConfig[0].colums_config);
//          // }

//          this.userConfig.idLine = params.get('id_line');
//          this.userConfig.idReport = '1';
//          this.userConfig.username = userConfigParams.username;

//       });
//    }

//    getProduction() {
//       this.data = null;
//       this.gantt = null;

//       this.isFetchingCoils = true;
//       this.isFetchingSummary = true;
//       this.isFetchingGantt = true;
//       this.isFetchingEfficiency = true;

//       this.productionService.getEfficiency(this.params)
//          .then((data: any) => {
//             this.efficiency = data.Eficiencia_Neta_Real === '' ? 0 : data.Eficiencia_Neta_Real;
//             this.isFetchingEfficiency = false;
//          });

//       this.productionService.getProductionCoils(this.params)
//          .then((data) => {
//             this.data = data;
//             this.isFetchingCoils = false;
//          });
//       this.productionService.getProductionSummary(this.params)
//          .then((resp) => {
//             this.summary = resp;
//             this.isFetchingSummary = false;
//          });
//       const gantt_params = _.clone(this.params);
//       gantt_params.order_asc = true;

//       this.productionService.getProductionGantt(gantt_params)
//          .then((data) => {
//             this.gantt = data;
//             this.gantt.process = this.sharedService.selectedProcess;
//             this.gantt.timeStart = this.dateShift.shift.labelStart;
//             this.gantt.timeEnd = this.dateShift.shift.labelEnd;
//             this.gantt.shift = this.params.shift;
//             this.isFetchingGantt = false;

//             // Div del tooltip en el gantt por mouseover (para removerlo)
//             setTimeout(() => {
//                this.divGanttElement = document.getElementById('tooltip-svgGantt');
//             }, 0);
//          });
//    }

//    columnsFromModalReceived(columns: any) {
//       this.userConfig.columns = columns;
//    }

//    selectMaterial(material) {
//       if (!this.selectedMaterial) {
//          this.selectedMaterial = material;
//       } else if (this.selectedMaterial.id_exit === material.id_exit) {
//          this.selectedMaterial = undefined;
//       } else {
//          this.selectedMaterial = material;
//       }
//    }

//    dateShiftChanged(dateFromPicker) {
//       if (!dateFromPicker.date) return;
//       this.dateShift = dateFromPicker;
//       this.params.date = dateFromPicker.date.format('YYYY-MM-DD');
//       this.params.shift = dateFromPicker.shift.shift;
//       this.getProduction();
//    }

//    openCalendar() {
//       const modalRef = this.modalService.open(ModalCalendarComponent);
//       modalRef.componentInstance.data = this.dateShift;
//       modalRef.result
//          .then((result: any) => {
//             if (result) {
//                this.dateShiftChanged(result);
//             }
//          });
//    }

//    handleMsgInfoIconsClick(event: any) {
//       switch (event.format) {
//          case 'excel':
//             this.exportToExcel();
//             break;
//          case 'customizer':
//             this.openCustomizerTableModal();
//             break;
//          default:
//             console.log('Nada programado');
//             break;
//       }
//    }

//    openCustomizerTableModal() {
//       this.table.customizerTableModalHandler();
//    }

//    exportToExcel() {
//       this.params.id_report = this.idReport;
//       console.log('params export', this.params);
//       this.productionService.exportExcelProduction(this.params)
//          .then(() => {
//             console.log('Se Exporto el archivo a Excel');
//          });
//    }

//    handlerCellClick(event): void {

//       const column = event.column;
//       this.sharedService.selectedMaterial = event.data;
//       if (column.alias_column === 'defect_quantity') {
//          event.data.modal_type = 'production';
//          const modalRef = this.modalService.open(ModalCoilDefectsComponent, {
//             windowClass: 'modal-md'
//          });
//          modalRef.componentInstance.data = event.data;
//       } else if (column.alias_column === 'curves_quantity') {

//          this.router.navigate(
//             ['../production/curves'],
//             {
//                relativeTo: this.activatedRoute,
//                queryParams: {
//                   'id_exit': event.data.id_exit,
//                   'material': event.data.exit_material,
//                   'ofa': event.data.need
//                }
//             });
//          // this.$state.go('curves', { id_line: event.data.id_line, id_exit: event.data.id_exit, material: event.data.exit_material, ofa: event.data.need });
//       } else if (column.alias_column === 'inspection_entrance') {
//          const modalRef = this.modalService.open(ModalSuperficialInspectionComponent, {
//             windowClass: 'size-md'
//          });
//          modalRef.componentInstance.data = event.data;

//       } else if (column.alias_column === 'exit_material') {
//          const obj = {
//             id_line: this.params.id_line,
//             report_code: 'production'
//          };
//          event.data.report_code = 'production';

//          this.materialInfoService.updateMaterialInfo(event.data);
//          this.router.navigate(
//             ['../material_detail'],
//             {
//                relativeTo: this.activatedRoute,
//                queryParams: {
//                   'material': event.data.exit_material,
//                   'source': 'production'
//                }
//             });
//          // this.$state.go('material', { id_line: this.params.id_line, material: event.data.exit_material, source: 'production' });

//       } else if (column.alias_column === 'rollers_material') {
//       } else if (column.alias_column === 'superficial_samples') {
//          if (event.data.superficial_samples === '1') {
//             const modalRef = this.modalService.open(ModalEssaysReportComponent, {
//                size: 'lg'
//             });
//             modalRef.componentInstance.data = event.data;
//          }
//       } else if (column.alias_column === 'necessity') {
//          if (event.data.show_ts) {
//             const modalRef = this.modalService.open(ModalProgrammingInfoComponent, {
//                windowClass: 'size-md'
//             });
//             modalRef.componentInstance.data = event.data;
//          }
//       }
//    }

// }
