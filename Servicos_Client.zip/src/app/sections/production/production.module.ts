// import { NgModule } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { FormsModule } from '@angular/forms';

// import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

// import { SharedModule } from 'src/app/shared/shared.module';
// import { PipesModule } from 'src/app/pipes/pipes.module';

// import { ProductionComponent } from './components/production.component';
// import { CurvesComponent } from './components/curves.component';

// import { ModalCoilDefectsComponent } from './entry-components/modal-coil-defects.component';
// import { ModalEssaysReportComponent } from './entry-components/modal-essays-report.component';
// import { ModalSuperficialInspectionComponent } from './entry-components/modal-superficial-inspection.component';

// import { ProgramModule } from '../program/program.module';
// import { CommonsModule } from 'src/app/common/common.module';

// import { SuperficialInspectionComponent } from './components/superficial-inspection.component';
// import { ProductionRoutingModule } from './production-routing.module';


// @NgModule({
//    imports: [
//       SharedModule,
//       CommonModule,
//       PipesModule,
//       NgbModule,
//       FormsModule,
//       ProgramModule,
//       CommonsModule,
//       ProductionRoutingModule
//    ],
//    exports: [],
//    declarations: [
//       ProductionComponent,
//       ModalCoilDefectsComponent,
//       ModalEssaysReportComponent,
//       ModalSuperficialInspectionComponent,
//       SuperficialInspectionComponent,
//       CurvesComponent
//    ],
//    entryComponents: [
//       ModalCoilDefectsComponent,
//       ModalEssaysReportComponent,
//       ModalSuperficialInspectionComponent,
//    ],
//    providers: [],
// })
// export class ProductionModule { }
