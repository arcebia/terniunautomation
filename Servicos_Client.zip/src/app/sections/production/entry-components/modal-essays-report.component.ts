// import { Component, OnInit, Input } from '@angular/core';

// import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

// import { ProductionUtilsService } from 'src/app/services/production-utils.service';

// @Component({
//    selector: 'modal-essays',
//    templateUrl: './modal-essays-report.component.html'
// })

// // export class ModalEssaysReportComponent implements OnInit  {
// export class ModalEssaysReportComponent implements OnInit {
//    essay_data: any = [];
//    @Input() data: any;

//    constructor(
//       private productionUtilsService: ProductionUtilsService,
//       public activeModal: NgbActiveModal,
//    ) {
//    }

//    confirm() {
//       // we set dialog result as true on click on confirm button,
//       // then we can get dialog result from caller code
//       // this.result = true;
//       // this.close();
//       this.activeModal.close();
//    }

//    ngOnInit(): void {
//       const params = {
//          id_line: this.data.id_line,
//          id_exit: this.data.id_exit
//       };
//       this.productionUtilsService.GetEssaysReport(params)
//          .then((data) => {
//             this.essay_data = data[0];
//             this.essay_data.length = Object.keys(this.essay_data).length;
//          });
//    }
// }
