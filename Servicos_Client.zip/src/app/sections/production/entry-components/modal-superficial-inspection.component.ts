// import { Component, OnInit } from '@angular/core';

// import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
// import * as _ from 'lodash';


// export class DataModal {
//    data: any;
// }

// @Component({
//    selector: 'modal-superficial-inspection',
//    templateUrl: './modal-superficial-inspection.component.html'
// })

// export class ModalSuperficialInspectionComponent implements OnInit {
//    data: any;
//    // typeConfig = {
//    //     attribute: "description",
//    //     multiple: false,
//    //     list: [{
//    //         id_type: 1,
//    //         description: 'Inspección Superficial'
//    //     }, {
//    //         id_type: 2,
//    //         description: 'Defectos de Producción'
//    //     }],
//    //     classes: "",
//    //     classesBtn: "btn-default",
//    //     classesItems: "full-width",
//    //     id: "typeDropdown",
//    //     nonSelectionText: "Seleccionar...",
//    //     loading: false
//    // }
//    // selectedType: any = {};
//    // percentOk : any;

//    constructor(
//       public activeModal: NgbActiveModal
//    ) {
//    }

//    confirm() {
//       this.activeModal.close();
//    }

//    ngOnInit(): void {
//       // this.selectType(this.typeConfig.list[1]);
//    }

//    // selectType(item) {
//    //     this.selectedType = item;
//    //     if (item.id_type == 1) {
//    //         this.getInspection();
//    //     } else {
//    //         this.getProductionDefects();
//    //     }
//    // }

//    // getInspection() {
//    //     this.data.inspectionLoaded = false;
//    //     var params = {
//    //         "id_line": this.data.id_line,
//    //         "id_material": +this.data.has_defects_superficial_exit > 0 ? this.data.id_exit: this.data.id_exit,
//    //         "id_graph_type": 1,
//    //         "is_entrance": +this.data.has_defects_superficial_entrance > 0,
//    //         "id_defect_status": 0
//    //     }

//    //     this.data.allDefects = [];
//    //     this.productionService.getSuperficialInspection(params)
//    //     .then((resp) => {
//    //         this.data.groupByDefects = {};
//    //         _.each(resp, (o) => {
//    //             var equal = {
//    //                 defect: o.defect,
//    //                 priority: o.priority,
//    //                 side: o.side,
//    //                 face: o.face,
//    //                 mts_start: o.mts_start,
//    //                 mts_end: o.mts_end
//    //             }
//    //             var exist = _.find(this.data.allDefects, equal)
//    //             if (!exist) {
//    //                 this.data.allDefects.push(o);
//    //             }
//    //         });
//    //         this.data.groupByDefects = _.groupBy(resp, 'defect');
//    //         this.data.groupByDefectsKeys = _.keys(this.data.groupByDefects);
//    //         this.data.inspectionData = resp;
//    //         this.data.inspectionLoaded = true;
//    //     })
//    // }

//    // getProductionDefects() {
//    //     this.data.inspectionLoaded = false;
//    //     var params = {
//    //         "id_line": this.data.id_line,
//    //         "id_exit": this.data.id_exit
//    //     }

//    //     this.data.allDefects = [];
//    //     this.productionService.getProductionDefectsMap(params)
//    //     .then((resp) => {
//    //         this.data.allDefects = resp;
//    //         if(this.data.allDefects[0].percent_ok && this.data.allDefects[0].percent_ok != null){
//    //             this.percentOk = this.data.allDefects[0].percent_ok;
//    //         }

//    //         this.data.inspectionData = _.filter(resp, (o) => {
//    //             return o.mts_start && o.mts_end;
//    //         });
//    //         if (this.data.inspectionData.length == 0) return;
//    //         this.data.inspectionLoaded = true;
//    //     })
//    // }
// }
