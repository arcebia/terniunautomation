// import { Component, OnInit, Input } from '@angular/core';
// import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

// import { ProgramService } from 'src/app/services/program.service';
// import { ProductionService } from 'src/app/services/production.service';

// @Component({
//    selector: 'modal-coil-defects',
//    templateUrl: './modal-coil-defects.component.html'
// })

// export class ModalCoilDefectsComponent implements OnInit {
//    material: any;
//    defects: any;
//    @Input() data: any;

//    constructor(
//       private programService: ProgramService,
//       private activeModal: NgbActiveModal,
//       private productionService: ProductionService) {
//    }

//    confirm() {
//       // we set dialog result as true on click on confirm button,
//       // then we can get dialog result from caller code
//       // this.result = true;
//       // this.close();
//       this.activeModal.close();
//    }

//    ngOnInit(): void {
//       this.material = this.data;
//       if (this.data.modal_type === 'production') {
//          this.productionService.getCoilDefects({ id_exit: this.material.id_exit, id_line: this.material.id_line })
//             .then((data) => {
//                this.getDefects(data);
//             });
//       } else if (this.data.modal_type === 'program') {
//          this.programService.getMaterialDefects({ id_material: this.material.id_material, id_line: this.material.id_line })
//             .then((data) => {
//                this.getDefects(data);
//             });
//       } else {
//          this.productionService.getDefectsGeneric({
//             id_line: this.material.id_line,
//             id: this.material.id,
//             type: this.material.modal_type
//          }).then((data) => {
//             this.getDefects(data);
//          });
//       }

//    }

//    getDefects(data): void {
//       this.defects = data;
//       if (data[0].value_defect_1 !== '') {
//          this.material.defect_quantity = 1;
//       }
//       if (data[0].value_defect_2 !== '') {
//          this.material.defect_quantity = 2;
//       }
//       if (data[0].value_defect_3 !== '') {
//          this.material.defect_quantity = 3;
//       }
//       if (data[0].value_defect_4 !== '') {
//          this.material.defect_quantity = 4;
//       }
//       if (data[0].value_defect_5 !== '') {
//          this.material.defect_quantity = 5;
//       }
//    }

// }
