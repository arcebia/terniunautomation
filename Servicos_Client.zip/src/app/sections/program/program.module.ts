// import { NgModule } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { FormsModule } from '@angular/forms';
// import { RouterModule } from '@angular/router';

// /**
//  * Necesitamos el NgbModule para los entryComponents en Lazy Loading
//  * no podemos traer el module especifico de la clase de ngb que necesitemos
//  * para este modulo, por lo que se carga entero el NgbModule. Evitar
//  * hacer esto en modulos que no usen entryComponents.
//  */
// // 3° party Modules
// import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

// // Custom Modules
// import { SharedModule } from 'src/app/shared/shared.module';
// import { PipesModule } from 'src/app/pipes/pipes.module';
// // import { CommonsModule } from '../common/common.module';

// // Custom Components
// import { AvailableMaterialsComponent } from './reports/available-materials.component';
// import { AvailableProgramsComponent } from './reports/available-programs.component';
// import { ProgramDetailComponent } from './reports/program-detail.component';
// import { ModalProgrammingInfoComponent } from './entry-components/modal-programming-info.component';
// import { ModalProgrammingObservationsComponent } from './entry-components/modal-programming-observations.component';
// import { ModalProgrammingRecipeComponent } from './entry-components/modal-programming-recipe.component';
// import { ProgrammingProcessComponent } from './reports/programming-process.component';

// @NgModule({
//    imports: [
//       RouterModule,
//       CommonModule,
//       FormsModule,
//       NgbModule,
//       SharedModule,
//       PipesModule,
//    ],
//    exports: [
//    ],
//    declarations: [
//       AvailableMaterialsComponent,
//       AvailableProgramsComponent,
//       ProgramDetailComponent,
//       ProgrammingProcessComponent,
//       ModalProgrammingInfoComponent,
//       ModalProgrammingObservationsComponent,
//       ModalProgrammingRecipeComponent
//    ],
//    entryComponents: [
//       ModalProgrammingInfoComponent,
//       ModalProgrammingObservationsComponent,
//       ModalProgrammingRecipeComponent
//    ],
//    providers: [],
// })
// export class ProgramModule { }
