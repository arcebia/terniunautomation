// import { Component, OnInit, Input } from '@angular/core';

// import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
// import * as _ from 'lodash';

// @Component({
//    selector: 'modal-programming-recipe',
//    templateUrl: './modal-programming-recipe.component.html'
// })

// export class ModalProgrammingRecipeComponent implements OnInit {
//    params: any;
//    @Input() data: any;
//    constructor(
//       public activeModal: NgbActiveModal
//    ) {
//    }

//    confirm() {
//       this.activeModal.close();
//    }

//    ngOnInit(): void {
//    }
// }
