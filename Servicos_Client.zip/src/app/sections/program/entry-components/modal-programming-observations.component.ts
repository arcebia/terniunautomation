// import { Component, OnInit, Input } from '@angular/core';

// import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
// import * as _ from 'lodash';

// import { ProgramService } from 'src/app/services/program.service';
// import { SsiService } from 'src/app/services/ssi.service';
// import { SharedService } from 'src/app/services/shared.service';

// @Component({
//    selector: 'modal-programming-observations',
//    templateUrl: './modal-programming-observations.component.html'
// })

// export class ModalProgrammingObservationsComponent implements OnInit {
//    params: any;
//    programming: any = '';
//    process_prod: any = '';
//    has_obs: any = {};
//    has_programming_obs = false;
//    has_processs_prod_obs = false;
//    id_programming_comments: any;
//    id_process_prod: any;
//    source = 'programming';
//    permission = {
//       programming: true,
//       production_process: true
//    };
//    reaload: boolean;

//    @Input() data: any;
//    constructor(
//       public activeModal: NgbActiveModal,
//       public programService: ProgramService,
//       private ssiService: SsiService,
//       public sharedService: SharedService
//    ) {
//    }

//    confirm() {
//       // we set dialog result as true on click on confirm button,
//       // then we can get dialog result from caller code
//       // this.result = true;
//       // this.close();
//       // let reaload = this.reaload;
//       this.activeModal.close(this.reaload);
//    }

//    ngOnInit(): void {
//       this.params = {
//          'IdLine': this.data.id_line,
//          'IdCoverType': this.data.id_cover_type,
//          'IdProgram': this.data.id_program,
//          'Item': this.data.rel_number,
//          'Necessity': this.data.necessity
//       };

//       this.ssiService.getPermissions(this.data.id_line, this.sharedService.RolProgrammingProcessProgram + ';' + this.sharedService.RolProgrammingProcessProduction)
//          .then((resp_perm) => {
//             if (resp_perm[this.sharedService.RolProgrammingProcessProgram]) {
//                this.permission.programming = true;
//                // resp_perm[this.sharedService.RolProgrammingProcessProgram].Escritura;
//                this.permission.production_process = true;
//                // resp_perm[this.sharedService.RolProgrammingProcessProduction].Escritura;
//             }
//          });

//       this.programService.getProgrammingProcessComments(this.params)
//          .then((resp) => {
//             this.has_obs = resp;

//             for (const i in this.has_obs) {
//                if (this.has_obs[i].source === 'programming') {
//                   this.programming += this.has_obs[i].comments;
//                   this.id_programming_comments = this.has_obs[i].id_programming_comments;
//                   this.has_programming_obs = true;
//                } else if (this.has_obs[i].source === 'production-process') {
//                   this.process_prod += this.has_obs[i].comments;
//                   this.id_process_prod = this.has_obs[i].id_programming_comments;
//                   this.has_processs_prod_obs = true;
//                }
//             }
//          });
//    }

//    selectTab($event?) {
//       this.source = $event.target.id; // ? $event.nextId : this.source;
//       switch (this.source) {
//          case 'programming':
//             this.params.source = this.source;
//             break;
//          case 'production-process':
//             this.params.source = this.source;
//             break;
//          default: break;
//       }
//    }

//    modifyObservation() {
//       if (this.permission.programming === true) {
//          this.source = 'programming';
//          this.params.comments = this.programming; // : this.process_prod;
//          this.params.IdProgrammingComments = this.id_programming_comments; // : this.id_process_prod;
//          this.params.source = this.source;

//          if (this.has_programming_obs) {
//             this.updateProgram();
//          } else if (!this.has_programming_obs) {
//             this.postProgram();
//          }

//       }

//       if (this.permission.production_process === true) {
//          this.source = 'production-process';
//          this.params.comments = this.process_prod;
//          this.params.IdProgrammingComments = this.id_process_prod;
//          this.params.source = this.source;

//          if (this.has_processs_prod_obs) {
//             this.updateProgram();
//          } else if (!this.has_processs_prod_obs) {
//             this.postProgram();
//          }
//       }
//    }

//    postProgram() {
//       this.programService.postProgrammingProcessComments(this.params)
//          .then((resp) => {
//             this.reaload = true;
//             this.confirm();
//          });
//    }

//    updateProgram() {
//       this.programService.updateProgrammingProcessComments(this.params)
//          .then((resp) => {
//             this.reaload = true;
//             this.confirm();
//          });
//    }
// }
