// import { Component, OnInit } from '@angular/core';

// import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

// import { ProgramService } from 'src/app/services/program.service';

// export class DataModal {
//    data: any;
// }

// @Component({
//    selector: 'modal-programming-info',
//    templateUrl: './modal-programming-info.component.html'
// })

// export class ModalProgrammingInfoComponent implements OnInit {
//    generals_extra: any;
//    data: any;
//    generals: any = {};
//    specifications: any[] = [];
//    loading = true;
//    no_general = false;
//    no_specifications = false;

//    constructor(
//       public activeModal: NgbActiveModal,
//       private programService: ProgramService
//    ) {
//    }

//    confirm() {
//       // we set dialog result as true on click on confirm button,
//       // then we can get dialog result from caller code
//       // this.result = true;
//       this.activeModal.close();
//    }

//    ngOnInit(): void {
//       this.programService.getTechnicalSpecification({ id_line: this.data.id_line, id_order: this.data.id_order, id_program: this.data.id_program })
//          .then(resp => {
//             this.generals = resp['General'] || [];
//             this.generals_extra = resp['GeneralExtra'] || [];
//             this.specifications = resp['Specifications'] || [];

//             this.loading = false;
//          });
//    }

// }
