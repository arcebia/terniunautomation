// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute, Router } from '@angular/router';

// import * as _ from 'lodash';

// import { ProgramService } from 'src/app/services/program.service';
// import { BaseService } from 'src/app/services/base.service';

// @Component({
//    selector: 'available-programs',
//    templateUrl: './available-programs.component.html'
// })

// export class AvailableProgramsComponent implements OnInit {

//    constructor(
//       private router: Router,
//       private activatedRoute: ActivatedRoute,
//       private programService: ProgramService,
//       private baseService: BaseService
//    ) { }

//    params = {
//       id_line: null
//    };

//    programs: any[];
//    program: any;
//    idReport = 310;
//    reportTitle = 'SECUENCIA DE PROGRAMAS';
//    toggle = false;
//    idProgram: any;
//    selectedAll = false;
//    Program: any = [];
//    loadingMaster: boolean;

//    icons = [
//       { icon: 'file_download', format: 'excel' }
//    ];

//    ngOnInit(): void {

//       this.params.id_line = this.activatedRoute.snapshot.paramMap.get('id_line');

//       const parameter = {
//          id_line: this.params.id_line,
//          id_report: 310,
//          username: '',
//          report_code: ''
//       };

//       this.baseService.getReportUserConfig(parameter)
//          .then((resp) => {
//             let iconConfig = [];
//             if (resp && resp.DefaultConfig.length > 0) {
//                iconConfig = JSON.parse(resp.DefaultConfig[0].report_config).icons;
//             }
//             if (iconConfig && iconConfig.length > 0) {
//                iconConfig.push(this.icons[0]);

//                this.icons = iconConfig;
//             }
//          });

//       this.loadingMaster = true;
//       this.programService.getAvailablePrograms(this.params)
//          .then((data) => {
//             this.programs = data;
//             _.each(this.programs, (d) => {
//                d.selected = false;
//             });
//             this.loadingMaster = false;
//          });
//    }

//    // Navegación programatica
//    goToProgramDetail(item) {

//       this.router.navigate(
//          ['../program_detail'],
//          {
//             relativeTo: this.activatedRoute,
//             queryParams: { 'id_program': item.program }
//          });
//    }

//    setProgram(item) {
//       this.program = item;
//    }

//    toggleChange($event) {
//       this.selectedAll = !this.selectedAll;
//       _.each(this.programs, (d) => {
//          d.selected = this.selectedAll;
//       });
//    }

//    actionExport($event) {

//       const selectedPrograms = _.filter(this.programs, (program: any) => program.selected);
//       const id_programs = _.map(selectedPrograms, 'id_program');

//       if ($event.format === 'pdf') {
//          const programList = [];
//          _.forEach(_.filter(id_programs), function (x) {
//             programList.push({
//                'id_program': x,
//                'id_order': 0
//             });
//          });

//          const parameters = {
//             idLine: this.params.id_line,
//             idReport: this.idReport,
//             program_order: JSON.stringify(programList)
//          };

//          this.programService.sequeceProgramExportPdf(parameters)
//             .then((resp) => {
//                console.log('Se Exporto el archivo en PDF');
//             });
//       } else {
//          this.idProgram = id_programs.toString();

//          const parameters_excel = {
//             idLine: this.params.id_line,
//             idReport: this.idReport,
//             idProgram: this.idProgram
//          };

//          this.programService.sequeceProgramExportExcel(parameters_excel)
//             .then((resp) => {
//                console.log('Se Exporto el archivo a Excel');
//             });
//       }
//    }
// }
