// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute } from '@angular/router';

// import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
// import * as _ from 'lodash';

// import { BaseService } from 'src/app/services/base.service';
// import { ModalCoilDefectsComponent } from '../../production/entry-components/modal-coil-defects.component';
// import { SharedService } from 'src/app/services/shared.service';
// import { ProgramService } from 'src/app/services/program.service';

// @Component({
//    selector: 'program-detail',
//    templateUrl: './program-detail.component.html'
// })

// export class ProgramDetailComponent implements OnInit {

//    params: any = {};
//    programConfig = {
//       attribute: 'program',
//       multiple: false,
//       list: [],
//       classes: '',
//       classesBtn: 'btn-default',
//       classesItems: '',
//       id: 'programDropdown',
//       nonSelectionText: 'Programa',
//       loading: true,
//       search: true
//    };
//    selectedProgram: any;
//    defects: any[];
//    materials: any[];
//    programInfo: any;
//    columns: any[];
//    gantt: any = {
//       SteelCoils: null
//    };
//    program: any;
//    loadingDetails = true;
//    id_report: any;
//    reportTitle: any;
//    isGeneric: any = false;
//    height: any;
//    icons = [
//       { icon: 'file_download', format: 'excel' }
//    ];

//    tableConfig = {
//       headersPosition: 'notFixed',
//       headersType: 'simple',
//       rowPositionColumn: false
//    };
//    isFetchingColumns: boolean;
//    isFetchingData: boolean;

//    constructor(
//       private activatedRoute: ActivatedRoute,
//       private modalService: NgbModal,
//       private programService: ProgramService,
//       public sharedService: SharedService,
//       private baseService: BaseService
//    ) { }

//    ngOnInit() {

//       this.activatedRoute.paramMap.subscribe(params => {

//          this.params.id_report = 2;
//          this.params.id_line = params.get('id_line');
//          if (this.activatedRoute.snapshot.queryParamMap.get('id_program')) {
//             this.params.program = this.activatedRoute.snapshot.queryParamMap.get('id_program');
//          }
//          // if (params.get('id_program')) this.params.program = params.get('id_program');

//          this.id_report = 2;
//          this.reportTitle = 'Consulta por Programa';
//          const columns = [{
//             width: '30',
//             display_name: 'Def',
//             alias_column: 'defect_quantity',
//             dynamic_column: 'True',
//             pinned: 'True',
//             to_show: 'True'
//          }, {
//             width: '40',
//             display_name: 'Rep',
//             alias_column: 'reworked',
//             dynamic_column: 'True',
//             pinned: 'True',
//             to_show: 'True'
//          },
//          {
//             width: '80',
//             display_name: 'Procesado',
//             alias_column: 'processed',
//             dynamic_column: 'True',
//             pinned: 'True',
//             to_show: 'True'
//          },
//          {
//             width: '100',
//             display_name: 'Material',
//             alias_column: 'material',
//             pinned: 'True',
//             to_show: 'True'
//          },
//          {
//             width: '80',
//             display_name: 'Secuencia',
//             alias_column: 'material_sequence',
//             pinned: 'True',
//             to_show: 'True'
//          }];

//          this.baseService.getReportColumns(this.params)
//             .then((data) => {
//                this.columns = _.concat(columns, data);
//                this.isFetchingColumns = false;
//             });

//          this.getDetails();

//       });

//    }

//    handlerCellClick(event): void {
//       const column = event.column;
//       if (column && event.data) {
//          this.sharedService.selectedMaterial = event.data;
//          if (column.alias_column === 'defect_quantity') {
//             event.data.modal_type = 'program';
//             const modalRef = this.modalService.open(ModalCoilDefectsComponent, {
//                windowClass: 'modal-md'
//             });
//             modalRef.componentInstance.data = event.data;
//          }

//       }
//    }

//    selectProgram(item) {
//       this.params.program = item.program;
//       this.getDetails();
//    }

//    findProgram() {
//       // this.params.program = this.program;
//       this.getDetails();
//    }

//    actionExport($event) {
//       if ($event.format === 'excel') {
//          this.programService.programmDetailExportExcel(this.params)
//             .then(() => {
//                console.log('Se Exporto el archivo a Excel');
//             });
//       }
//    }

//    getDetails() {
//       this.isFetchingData = true;
//       this.loadingDetails = true;
//       this.programService.getProgramDetail(this.params)
//          .then((data) => {
//             this.defects = data['Defects'];
//             this.materials = data['Materials'];
//             this.programInfo = data['ProgramInfo'][0];
//             this.programConfig.list = data['ProgramList'];
//             this.programConfig.loading = false;
//             this.selectedProgram = _.find(this.programConfig.list, { program: this.params.program });
//             if (!this.selectedProgram) {
//                this.selectedProgram = data['ProgramInfo'][0];
//                this.params.program = this.selectedProgram.program;
//             }
//             this.gantt.SteelCoils = new Array();
//             this.gantt.Ranges = new Object();
//             this.gantt.Schedules = new Array();
//             this.gantt.Defects = new Array();
//             this.gantt.TypeGantt = 'PROG';
//             _.each(this.materials, (o: any) => {
//                const clone = _.clone(o);
//                clone['RowId'] = +o.id_material;
//                clone['BottomValue'] = +o.thickness;
//                clone['TopValue'] = +o.width;
//                clone['Category'] = o.gantt_category;
//                clone['Details'] = new Array();
//                clone['Details'].push({
//                   Key: 'Material',
//                   Value: o.material
//                });
//                clone['Details'].push({
//                   Key: 'Programa',
//                   Value: o.program,
//                   Tooltip: true
//                });
//                clone['Details'].push({
//                   Key: 'Secuencia',
//                   Value: o.material_sequence,
//                   Tooltip: true
//                });
//                clone['Details'].push({
//                   Key: 'Ancho',
//                   Value: o.width,
//                   Tooltip: true
//                });
//                clone['Details'].push({
//                   Key: 'Espesor',
//                   Value: o.thickness,
//                   Tooltip: true
//                });
//                this.gantt.SteelCoils.push(clone);
//             });

//             _.each(this.defects, (o) => {
//                const clone = _.clone(o);
//                clone['RowId'] = +o.id_material;
//                clone['Details'] = new Array();
//                clone['Details'].push({
//                   Key: 'Defectos',
//                   Value: ''
//                });
//                clone['Details'].push({
//                   Key: o.defect_code,
//                   Value: o.defect_desc,
//                   Tooltip: true
//                });
//                this.gantt.Defects.push(clone);
//             });

//             this.gantt.Ranges['ganttTopMin'] = Math.round(_.minBy(this.gantt.SteelCoils, 'TopValue')['TopValue'] * 0.75);
//             this.gantt.Ranges['ganttTopMax'] = Math.round(_.maxBy(this.gantt.SteelCoils, 'TopValue')['TopValue'] * 1.10);
//             this.gantt.Ranges['ganttBottomMin'] = 0; // _.minBy(this.gantt.SteelCoils, "BottomValue")["BottomValue"];
//             this.gantt.Ranges['ganttBottomMax'] = Math.round(_.maxBy(this.gantt.SteelCoils, 'BottomValue')['BottomValue'] * 1.10);
//             this.gantt.Schedules.push({
//                RowId: this.programInfo.program,
//                Details: [
//                   {
//                      Key: 'Programa',
//                      Value: this.programInfo.program,
//                      Tooltip: true
//                   },
//                   {
//                      Key: 'Cant. Materiales',
//                      Value: this.programInfo.material_quantity,
//                      Tooltip: true
//                   },
//                   {
//                      Key: 'Fecha Alta',
//                      Value: this.programInfo.record_date,
//                      Tooltip: true
//                   },
//                   {
//                      Key: 'Fecha Liberación PP',
//                      Value: this.programInfo.release_date,
//                      Tooltip: true
//                   }
//                ]
//             });
//             this.isFetchingData = false;
//             this.loadingDetails = false;
//          });
//    }

// }
