// import { Component, OnInit, HostListener, OnDestroy } from '@angular/core';
// import { ActivatedRoute } from '@angular/router';

// import { interval } from 'rxjs';

// import * as _ from 'lodash';
// import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

// import { ModalProgrammingObservationsComponent } from '../entry-components/modal-programming-observations.component';
// import { ModalProgrammingRecipeComponent } from '../entry-components/modal-programming-recipe.component';
// import { ModalProgrammingInfoComponent } from '../entry-components/modal-programming-info.component';

// import { ProgramService } from 'src/app/services/program.service';
// import { SharedService } from 'src/app/services/shared.service';
// import { ProcessService } from 'src/app/services/process.service';
// import { BaseService } from 'src/app/services/base.service';
// import { SsiService } from 'src/app/services/ssi.service';

// @Component({
//    selector: 'programming-process',
//    templateUrl: './programming-process.component.html'
// })

// export class ProgrammingProcessComponent implements OnInit, OnDestroy {

//    wWindow: number;
//    hWindow: number;

//    efficiency: any = 100;
//    totalSummary: any;
//    summaryStatus: any;
//    summaryValidations: any;
//    programDetail: any;
//    selectedCoverType: any;
//    selectedEstimationType: any;
//    selectedArray = [];
//    params: any = {
//       id_report: 303,
//       id_cover_type: -1,
//       id_estimate_type: -1,
//       efficiency: this.efficiency
//    };
//    collapsed = false;
//    idReport = this.params.id_report;
//    reportTitle = 'PROGRAMACIÓN EN CURSO';
//    icons = [
//       { icon: 'file_download', format: 'excel' }
//    ];

//    coverTypeConfig = {
//       attribute: 'cover_type_description',
//       multiple: false,
//       list: [],
//       classes: '',
//       classesBtn: 'btn-default',
//       classesItems: '',
//       id: 'coverTypeDropdown',
//       nonSelectionText: 'Tipo de Cubierta',
//       loading: true
//    };

//    estimationTypeConfig = {
//       attribute: 'estimation',
//       multiple: false,
//       list: [],
//       classes: 'margin-left',
//       classesBtn: 'btn-default',
//       id: 'estimationDropdown',
//       nonSelectionText: 'Tipo de Estimación',
//       loading: true
//    };
//    loadedGraph = false;
//    loadedTable = true;
//    program: string;
//    dateShift: any;
//    graphSummaryStatus: any = {};
//    graphSummaryValidations: any = {};
//    summaryStatusData: any = [];
//    summaryValidationsData: any = [];
//    materials: any[] = [];
//    columnsConfig: any[] = [];
//    height: any;
//    hasscroll: 0;
//    totalActual: number;
//    intervalRefreshing;
//    reportCode: any = 'PROGRAMMING_PROCESS';
//    reportUserConfig: any = {};
//    selectedInformation: any[] = [];
//    currentUser: any = {};
//    userConfig: any = {};

//    // new
//    selectableColumns: any = {};
//    tableConfig: any = {};
//    isFetchingColumns = true;
//    isFetchingData = true;
//    isFetchingRptUsrConfig = true;

//    constructor(
//       private activatedRoute: ActivatedRoute,
//       private programService: ProgramService,
//       public sharedService: SharedService,
//       private modalService: NgbModal,
//       private processService: ProcessService,
//       private baseService: BaseService,
//       private ssiService: SsiService
//    ) {
//       // this.params.id_line = this.$state.params.id_line;
//       // this.sharedService.updateIdLine(this.params.id_line);
//       // this.sharedService.idLine = this.params.id_line;
//       // this.sharedService.updateState(this.$state.$current);
//       // this.dateShift = this.sharedService.dateShift;
//       // this.sharedService.updateStyle(this.$state.params.style);
//       // this.currentUser = this.sharedService.currentUser;
//    }

//    ngOnDestroy() {
//       if (this.intervalRefreshing) {
//          this.intervalRefreshing.unsubscribe();
//       }
//    }

//    ngOnInit(): void {

//       this.tableConfig.caption = 'Programación';
//       this.tableConfig.goToCurrent = true;
//       this.tableConfig.rowPositionColumn = false;

//       this.selectableColumns.reportCode = this.reportCode;
//       this.selectableColumns.enable = true;


//       this.params.id_line = this.activatedRoute.snapshot.paramMap.get('id_line');
//       this.sharedService.updateIdLine(this.params.id_line);

//       this.dateShift = this.sharedService.dateShift.getValue();

//       this.currentUser = this.sharedService.user.getValue();

//       const parameter = {
//          id_line: this.params.id_line,
//          id_report: 303,
//          username: '',
//          report_code: ''
//       };

//       this.estimationTypeConfig.list = [{
//          estimation: 'Programado',
//          id_estimate_type: '1'
//       }, {
//          estimation: 'Apropiado',
//          id_estimate_type: '2'
//       }];
//       this.estimationTypeConfig.loading = false;
//       this.selectedEstimationType = this.estimationTypeConfig.list[1];
//       this.selectedInformation = [];
//       if (!this.currentUser) {
//          this.ssiService.getCurrentUser()
//             .then((usr) => {
//                this.currentUser = usr;
//                this.fillData();
//             });
//       } else {
//          this.fillData();
//       }

//       this.intervalRefreshing = interval(60000 * 5)
//          .subscribe(() => {
//             this.getProgrammingProcess();
//          });
//    }

//    classIcon(item, column) {
//       if (column.alias_column === 'id_status') {
//          return item.id_status === '1' ? 'item-processed' : item.id_status === '2' ? 'item-actual' : 'item-to_process';
//       } else if (column.alias_column === 'has_dat') {
//          return item.has_dat === '0' ? 'icon-receipt' : '';
//       } else if (column.alias_column === 'add_obs') {
//          return item.add_obs === '1' ? 'icon-red' : '';
//       } else if (column.alias_column === 'thickness_in' || column.alias_column === 'thickness_out') {
//          return item.thickness_dif_higher === '1' ? 'be-red' : '';
//       } else if (column.alias_column === 'transition') {
//          return item.transition === '1' ? 'icon-red' : '';
//       } else if (column.alias_column === 'necessity') {
//          return 'font-bold';
//       } else if (column.alias_column === 'selected') {

//       }
//    }

//    textClass(item, column) {
//       if (column.alias_column === 'necessity') {
//          return 'font-bold';
//       } else if (column.alias_column === 'thickness_in' || column.alias_column === 'thickness_out') {
//          return item.thickness_dif_higher === '1' ? 'be-red' : '';
//       }
//    }

//    setIcon(item, column) {
//       if (column.alias_column === 'id_status') {
//          return 'fiber_manual_record';
//       } else if (column.alias_column === 'has_dat') {
//          return 'receipt';
//       } else if (column.alias_column === 'add_obs') {
//          return 'comment';
//       } else if (column.alias_column === 'transition') {
//          return item.transition === '1' ? 'done' : '';
//       }
//    }

//    async fillData() {
//       const userconfig_columns = {
//          id_line: this.params.id_line,
//          id_report: 0,
//          report_code: this.reportCode,
//          username: this.currentUser.username
//       };

//       const reportColumns = await this.baseService.getReportColumns(this.params);
//       await _.each(reportColumns, (column) => {
//          column.icon_class = this.classIcon;
//          column.text_class = this.textClass;

//          if (column.alias_column === 'id_status') {
//             column.icon = 'fiber_manual_record';
//          } else if (column.alias_column === 'has_dat') {
//             column.icon = 'receipt';
//          } else if (column.alias_column === 'add_obs') {
//             column.icon = 'comment';
//          } else if (column.alias_column === 'transition') {
//             column.icon = 'done';
//             column.icon_func = this.setIcon;
//          } else if (column.alias_column === 'selected') {
//             column.icon = 'check';
//             column.is_selectable = true;
//          }
//       });
//       this.columnsConfig = reportColumns;
//       this.selectableColumns.columnsConfig = reportColumns;

//       const reportUserConfig = await this.baseService.getReportUserConfig(userconfig_columns);
//       let iconConfig = [];
//       if (reportUserConfig && reportUserConfig.DefaultConfig.length > 0) {
//          iconConfig = JSON.parse(reportUserConfig.DefaultConfig[0].report_config).icons;
//       }

//       if (iconConfig && iconConfig.length > 0) {
//          iconConfig.push(this.icons[0]);

//          this.icons = iconConfig;
//       }

//       if (reportUserConfig.UserConfig && reportUserConfig.UserConfig[0] && reportUserConfig.UserConfig[0].colums_config && reportUserConfig.UserConfig[0].colums_config !== '') {
//          this.userConfig.columns = JSON.parse(reportUserConfig.UserConfig[0].colums_config);
//       }

//       this.userConfig.idLine = this.params.id_line;
//       this.userConfig.idReport = 303;
//       this.userConfig.username = this.currentUser.username;


//       this.reportUserConfig = reportUserConfig;
//       this.selectableColumns.reportUserConfig = reportUserConfig;

//       this.isFetchingRptUsrConfig = false;

//       const coverTypes = await this.processService.getCoverTypes(this.params);
//       this.coverTypeConfig.list = coverTypes;
//       this.coverTypeConfig.loading = false;

//       const substratumObjetive = await this.processService.getSubstratumObjetive(this.params);
//       const coverType = _.find(this.coverTypeConfig.list, { cover_type_description: substratumObjetive[0].cover_type }) || {};
//       this.selectedCoverType = coverType;
//       this.params.id_cover_type = this.selectedCoverType.id_cover_type;
//       this.getProgrammingProcess();

//       this.isFetchingColumns = false;

//    }

//    // Borrar seguramente
//    setSelectedInfo(columns) {
//       if (columns.length === 0) {
//          const default_columns = _.filter(this.columnsConfig, (column: any) => column.has_template === 'False' && column.pinned === 'True');
//          columns = default_columns.length === 0 ? this.columnsConfig : default_columns;
//          columns = _.map(columns, (x: any) => {
//             return parseInt(x.id_column);
//          });
//       }

//       _.each(this.columnsConfig, (o) => {
//          const selected = _.indexOf(columns, parseInt(o.id_column));
//          o.enable = selected > -1;
//       });

//       this.selectedInformation = _.filter(this.columnsConfig, (column: any) => column.enable === true);
//       this.isFetchingColumns = false;

//    }

//    getProgrammingProcess() {
//       this.params.id_estimate_type = this.selectedEstimationType.id_estimate_type;
//       this.params.id_cover_type = this.selectedCoverType.id_cover_type;
//       this.params.efficiency = this.efficiency;
//       this.loadedGraph = false;

//       if (this.programDetail) {
//          this.selectedArray = _.filter(this.programDetail, { selected: true });
//       }

//       this.programService.getProgrammingProcess(this.params)
//          .then((resp) => {
//             this.totalSummary = resp.TotalSummary[0];
//             this.summaryStatus = resp.SummaryStatus;
//             this.summaryValidations = resp.SummaryValidations;
//             this.programDetail = resp.ProgramDetail;
//             this.totalActual = (_.find(this.summaryStatus, { id_status: '2' }) as any).value;
//             this.fillCharts();
//             this.loadedGraph = true;

//             _.each(this.programDetail, (o) => {
//                o.selected = false;
//                o.icons_editable = ['warning', 'done'];
//             });

//             if (this.selectedArray) {
//                _.each(this.selectedArray, (o) => {
//                   const index = _.findIndex(this.programDetail, { RowID: o.RowID, necessity: o.necessity });
//                   if (index > -1) {
//                      this.programDetail[index].selected = true;
//                   }
//                });
//             }

//             this.materials = this.programDetail;
//             this.isFetchingData = false;
//             this.setStyles();
//             this.loadedTable = true;
//          });
//    }

//    goToActual($event) {
//       const id = _.findIndex(this.programDetail, { id_status: '2' });
//       const mainDiv = document.getElementById('scrollTo' + id);
//       if (mainDiv) {
//          document.getElementById('table-container').scrollTo({ top: mainDiv.offsetTop, behavior: 'smooth' });
//       }
//    }

//    selectCoverType($event) {
//       this.selectedCoverType = $event;
//       this.getProgrammingProcess();
//    }

//    selectEstimationType($event) {
//       this.selectedEstimationType = $event;
//       this.getProgrammingProcess();
//    }

//    handlerColumn($event) {
//       // this.hasscroll = $event.scroll;
//       // console.log(this.hasscroll);
//       let selected_item = false;
//       let rowId = 0;
//       if ($event.data) {
//          $event.data.id_cover_type = this.params.id_cover_type;
//          selected_item = $event.data.selected;
//          rowId = $event.data.RowID;
//          if (this.programDetail && this.programDetail.length > 0) {
//             const found: any = _.find(this.programDetail, { RowID: rowId });
//             if (found) {
//                found.selected = selected_item;
//             }
//          }
//       }

//       if ($event.column) {
//          if ($event.column.display_name === 'Obs') {
//             const modalRef = this.modalService.open(ModalProgrammingObservationsComponent);
//             modalRef.componentInstance.data = $event.data;
//             modalRef.result
//                .then((result: any) => {
//                   if (result) {
//                      this.getProgrammingProcess();
//                   }
//                });
//          } else if ($event.column.alias_column === 'has_dat') {
//             const modalRef = this.modalService.open(ModalProgrammingRecipeComponent);
//             modalRef.componentInstance.data = $event.data;
//          } else if ($event.column.alias_column === 'necessity') {
//             const modalRef = this.modalService.open(ModalProgrammingInfoComponent, { windowClass: 'size-md' });
//             modalRef.componentInstance.data = $event.data;
//          }
//       }
//    }

//    fillCharts() {
//       let summaryValidationsData: any = this.summaryValidations;
//       const summaryStatusData: any = [];
//       const series = [];
//       const colorStatus = {
//          '1': 'rgb(22, 160, 133)',
//          '2': 'rgb(192, 57, 43)',
//          '3': 'rgb(44, 62, 80)'
//       };

//       _.each(summaryValidationsData, (o) => {
//          o.value = +o.value;
//          series.push({
//             y: o.value,
//             color: o.color
//          });
//       });

//       summaryValidationsData = _.orderBy(summaryValidationsData, 'value', ['desc']);

//       _.each(this.summaryStatus, (o) => {
//          const color = colorStatus[o.id_status];
//          summaryStatusData.push({
//             name: o.description,
//             y: _.parseInt(o.value),
//             color: color
//          });
//       });

//       this.graphSummaryStatus.config = {
//          chart: {
//             height: 130,
//             type: 'pie'
//          },
//          id: 'Process',
//          title: {
//             text: null
//          },
//          tooltip: {
//             formatter: function () {
//                return this.point.name + ' (' + this.y + '%)';
//             }
//          },
//          plotOptions: {
//             pie: {
//                allowPointSelect: true,
//                cursor: 'pointer',
//                dataLabels: {
//                   enabled: false
//                },
//                showInLegend: true,
//                size: 120,
//                innerSize: 50
//             }
//          },
//          legend: {
//             align: 'left',
//             verticalAlign: 'top',
//             layout: 'vertical',
//             labelFormatter: function () {
//                return this.name + '  ' + this.y + '%';
//             },
//             itemMarginBottom: 5,
//             margin: 5,
//             x: 40,
//             y: 0
//          },
//          series: [{
//             type: 'pie',
//             name: 'Estatus',
//             colorByPoint: true,
//             data: summaryStatusData
//          }]
//       };

//       this.graphSummaryValidations = {
//          config: {
//             chart: {
//                type: 'bar',
//                height: 130,
//                // width: 600
//             },
//             id: 'SubProcess',
//             title: {
//                text: null
//             },
//             xAxis: {
//                categories: _.map(summaryValidationsData, 'description'),
//                labels: {
//                   style: {
//                      fontSize: '11px'
//                   }
//                }
//             },
//             yAxis: {
//                tickInterval: 1,
//                labels: {
//                   enabled: true
//                },
//                title: {
//                   text: null
//                }
//             },
//             series: [{
//                showInLegend: false,
//                name: 'Valor',
//                data: series
//             }]
//          }
//       };
//    }

//    actionExport($event) {
//       if ($event.format === 'excel') {   // this.params.to_show = 2;
//          this.programService.programmingProcessExportExcel(this.params)
//             .then((resp) => {
//                console.log('Se Exporto el archivo a Excel');
//             });
//       } else if ($event.format === 'collapsing') {
//          this.collapsed = $event.collapsed;
//          this.setStyles();
//       } else if ($event.format === 'pdf') {
//          const selectedPrograms = _.filter(this.materials, (material: any) => material.selected === true);
//          const idProgram = _.map(selectedPrograms, 'id_program').toString();
//          const idOrder = _.map(selectedPrograms, 'id_order').toString();

//          const programList = [];
//          _.forEach(_.filter(this.materials, (material: any) => material.selected === true), function (x) {
//             programList.push({
//                'id_program': x['id_program'],
//                'id_order': x['id_order']
//             });
//          });
//          const parameters = {
//             idLine: this.params.id_line,
//             idReport: this.idReport,
//             program_order: JSON.stringify(programList)
//          };

//          this.programService.sequeceProgramExportPdf(parameters)
//             .then((resp) => { });
//       }
//    }

//    @HostListener('window:resize', ['$event']) getWindow(event) {
//       this.hWindow = event.target.innerHeight;
//       this.setStyles();
//    }

//    // for transcluded content
//    // ngAfterContentInit() {
//    //     this.hWindow = window.innerHeight;
//    //     this.setStyles();
//    // }

//    setStyles(): void {
//       let height = window.innerHeight - 480;
//       if (this.collapsed) {
//          height = height + 185;
//       }
//       if (height < 200) {
//          height = 200;
//       }
//       this.height = height;
//    }

//    columnConfigChange($event) {
//       // console.log($event);
//       this.selectedInformation = _.filter($event.columnsConfig, { enable: true });
//    }
// }
