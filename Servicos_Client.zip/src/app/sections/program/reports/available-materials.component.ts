// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute } from '@angular/router';

// import * as _ from 'lodash';

// import { ProgramService } from 'src/app/services/program.service';
// import { BaseService } from 'src/app/services/base.service';

// @Component({
//    selector: 'available-materials',
//    templateUrl: './available-materials.component.html'
// })

// export class AvailableMaterialsComponent implements OnInit {
//    constructor(
//       private programService: ProgramService,
//       private baseService: BaseService,
//       private activatedRoute: ActivatedRoute
//    ) { }

//    tableConfig = {
//       headersPosition: 'notFixed',
//       headersType: 'simple',
//       rowPositionColumn: false
//    };

//    params = {
//       id_line: null,
//       id_report: 9
//    };

//    materials: any[];
//    program: any;
//    columns: any[];
//    loadingMaterials: boolean;

//    icons = [
//       { icon: 'file_download', format: 'excel' }
//    ];

//    ngOnInit(): void {

//       this.params.id_line = this.activatedRoute.snapshot.paramMap.get('id_line');

//       const columns = [{
//          width: '150',
//          display_name: 'Material',
//          alias_column: 'material'
//       }, {
//          width: '150',
//          display_name: 'Última Modificación',
//          alias_column: 'last_modified_date'
//       }];
//       this.baseService.getReportColumns(this.params)
//          .then((data) => {
//             this.columns = _.concat(columns, data);
//          });
//       this.loadingMaterials = true;
//       this.programService.getAvailableMaterials(this.params)
//          .then((data) => {
//             this.materials = data;
//             this.loadingMaterials = false;
//          });
//    }

//    actionExport($event) {

//       if ($event.format === 'excel') {
//          this.programService.availableMaterialExportExcel(this.params)
//             .then(() => {
//                console.log('Se Exporto el archivo a Excel');
//             });
//       }
//    }

// }
