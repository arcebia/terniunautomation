import { Component, OnInit, Input } from '@angular/core';

@Component({
   selector: 'summary-report',
   templateUrl: 'summary-report.component.html',
   styleUrls: ['summary-report.component.css']
})

export class SummaryReportComponent implements OnInit {

   @Input() columns: any;
   @Input() rowHeaders: any;
   @Input() data: any;

   constructor() { }

   ngOnInit() { }
}
