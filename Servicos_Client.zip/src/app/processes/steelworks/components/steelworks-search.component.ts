import { Component, Input, EventEmitter, Output, OnChanges, SimpleChanges, SimpleChange } from '@angular/core';

import { ProductionService } from 'src/app/services/production.service';

@Component({
   selector: 'steelworks-search',
   templateUrl: 'steelworks-search.component.html'
})

export class SteelworksSearchComponent implements OnChanges {

   @Input() placeholder: any;
   @Input() idLine: any;
   @Input() clearSearchField: boolean;

   @Output() searchResultFetched = new EventEmitter<any>();

   materialNumber: any;

   searchParams: any = {};

   searchError = false;
   messageError: string;

   constructor(
      private productionService: ProductionService
   ) { }

   ngOnChanges(changes: SimpleChanges) {
      if (changes.clearSearchField && changes.clearSearchField.currentValue) {
         this.materialNumber = '';
      }
   }

   searchByMaterial() {
      this.searchParams = { 'id_line': this.idLine, 'material_number': this.materialNumber };
      if (!this.searchParams.material_number) {
         this.messageError = 'Debe ingresar un Nro de Colada';
         this.searchError = true;
         setTimeout(() => {
            this.searchError = false;
         }, 2000);
      } else {
         this.productionService.steelworkSearchByMaterial(this.searchParams)
            .then((res: any) => {
               if (Object.keys(res).length === 0 || res.fecha === '') {
                  this.messageError = `No se ha encontrado la colada ${this.materialNumber}`;
                  this.searchError = true;
                  setTimeout(() => {
                     this.searchError = false;
                  }, 2000);
               } else {
                  this.searchResultFetched.emit(res);
                  this.clearSearchField = false;
               }
            });
      }
      this.clearSearchField = false;
   }
}
