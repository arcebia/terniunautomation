import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SteelworksGenericComponent } from './reports/steelworks-generic/steelworks-generic.component';

const routes: Routes = [
   {
      path: 'steelworks_generic',
      component: SteelworksGenericComponent
   },
];

@NgModule({
   imports: [RouterModule.forChild(routes)],
   exports: [RouterModule]
})
export class SteelworksRoutingModule { }
