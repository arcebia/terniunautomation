import { Component, OnInit, ViewChild, ChangeDetectorRef, AfterViewChecked } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { combineLatest } from 'rxjs';
import { debounceTime, map } from 'rxjs/operators';

import * as moment from 'moment';

import { ProductionService } from 'src/app/services/production.service';
import { BaseService } from 'src/app/services/base.service';
import { SharedService } from 'src/app/services/shared.service';
import { SsiService } from 'src/app/services/ssi.service';

@Component({
   selector: 'steelworks-generic',
   templateUrl: 'steelworks-generic.component.html',
})
export class SteelworksGenericComponent implements OnInit, AfterViewChecked {

   @ViewChild('customTable') customTable: any;

   summaryParams: any = {
      id_line: null,
      id_report: null
   };
   genericParams: any = {
      id_line: null,
      id_report: null
   };
   dataTableParams: any = {
      id_line: null,
      id_report: null,
      start_date: null,
      end_date: null,
      shift: null
   };
   statisticsParams: any = {
      id_line: null,
      id_report: null,
      start_date: null,
      end_date: null,
      shift: null,
      mode: 2
   };

   layoutConfig: any = {};

   tableConfig: any = {};

   userConfig: any = {};

   dateFromSearch: any;

   isFetchingData = true;
   isFetchingSummaryData = true;
   isFetchingDateParams = true;
   isFetchingLayoutConfig = true;
   isFetchingStatistics = false;

   dataTableColumns: any;
   dataTableData: any;
   summaryColumns: any;
   summaryData: any;
   statisticsData: any = {};

   reportTitle: any;
   reportConfig: any;

   summaryCollapsed = false;

   icons = [
      { icon: 'file_download', format: 'excel', text: 'Exportar a Excel' },
      { icon: 'format_list_numbered', format: 'customizer', text: 'Customizar Tabla' },
   ];
   toggleFilters = false;
   toggleStatistics = false;

   itemSearched: any;
   newDateFromSearch: any;
   clearSearch = false;

   constructor(
      private activatedRoute: ActivatedRoute,
      private productionService: ProductionService,
      private baseService: BaseService,
      private ssiService: SsiService,
      public sharedService: SharedService,
      private cdRef: ChangeDetectorRef
   ) { }

   openCustomizerTableModal() {
      this.customTable.customizerTableModalHandler();
   }

   ngAfterViewChecked() {
      this.cdRef.detectChanges();
   }

   ngOnInit() {
      /**
       * Hay que escuchar tanto el cambio de id_line como el
       * cambio en el id_report, por eso se combinan los dos
       * observables para armar el reporte correspondiente
       * a los parametros recibidos a partir de la navegacion
       */
      const URLParams = combineLatest(this.activatedRoute.paramMap, this.activatedRoute.queryParamMap).pipe(
         map(([params, queryParams]) => ({ id_line: params.get('id_line'), id_report: queryParams.get('id_report') })),
         debounceTime(50), // Pequeño debounceTime para que no emita 2 veces si detecta cambio en linea y reporte a destiempo
      );

      URLParams.subscribe(async (params: any) => {
         if (params.id_line) {
            this.dataTableParams.id_line = params.id_line;
            this.statisticsParams.id_line = params.id_line;
            this.genericParams.id_line = params.id_line;
            this.summaryParams.id_line = params.id_line;
         }

         if (params.id_report) {
            this.dataTableParams.id_report = params.id_report;
            this.statisticsParams.id_report = params.id_report;
            this.genericParams.id_report = params.id_report;

         } else {
            this.dataTableParams.id_report = '1';
            this.statisticsParams.id_report = '1';
            this.genericParams.id_report = '1';
         }

         this.resetLayout();

         /**
          * En el cambio de linea/reporte hay que esperar a que
          * se obtenga la configuracion de ese reporte antes de
          * ir a buscar los datos, porque sino usaria la configuracion
          * del reporte anterior cuando se mantiene la fecha al
          * cambiar entre lineas/reportes. El orden en el que se
          * obtengan las configuraciones no importa, por eso
          * se usa un Promise.all()
          */
         await Promise.all([this.getLayoutConfig(), this.getReportConfig()]);

         if (this.dataTableParams.start_date && (this.dataTableParams.start_date === this.dataTableParams.end_date)) {
            this.getData();
         }

      });
   }

   resetLayout() {
      this.toggleFilters = false;
      this.toggleStatistics = false;

      this.isFetchingData = true;
      this.isFetchingSummaryData = true;
      this.isFetchingLayoutConfig = true;
      this.isFetchingDateParams = true;
      this.isFetchingStatistics = false;

      this.dataTableColumns = null;
      this.dataTableData = null;
      this.statisticsData = null;
      this.summaryColumns = null;
      this.summaryData = null;
      this.summaryCollapsed = false;
      this.userConfig = {};
   }

   async getLayoutConfig() {
      this.isFetchingLayoutConfig = true;

      if (this.sharedService.user.getValue()) {
         this.genericParams.username = this.sharedService.user.getValue().username;
      } else {
         const user = await this.ssiService.getCurrentUser();
         this.genericParams.username = user.username;
      }
      const res = await this.baseService.getReportUserConfig(this.genericParams);

      if (res.defaultConfig.reportConfig) {
         const layoutConfig = res.defaultConfig.reportConfig;
         this.layoutConfig.hasSummaryTable = layoutConfig.hasSummaryTable;
         this.layoutConfig.hasSummaryGraph = layoutConfig.hasSummaryGraph;
         this.layoutConfig.hasStatisticsTable = layoutConfig.hasStatisticsTable;
         this.layoutConfig.hasTableFilters = layoutConfig.hasTableFilters;
         this.layoutConfig.hasItemSearch = layoutConfig.hasItemSearch;
         if (this.layoutConfig.hasSummaryTable) this.layoutConfig.summaryRowHeaders = layoutConfig.summaryRowHeaders.split(', ');
         this.layoutConfig.datePickerType = layoutConfig.datePickerType;
         this.tableConfig.headersType = layoutConfig.headersType;
         this.tableConfig.headersPosition = layoutConfig.headersPosition;
      }

      if (res.userConfig.columnsConfig) this.userConfig.columns = res.userConfig.columnsConfig;

      this.userConfig.idLine = this.genericParams.id_line;
      this.userConfig.idReport = this.genericParams.id_report;
      this.userConfig.username = this.genericParams.username;

      if (this.layoutConfig.hasTableFilters) {
         if (this.icons.findIndex((icon: any) => icon.icon === 'filter') === -1) {
            this.icons.push({ icon: 'filter', format: 'filter', text: 'Filtros por Columna' });
         }
      } else {
         const index = this.icons.findIndex((icon: any) => icon.icon === 'filter');
         if (index !== -1) {
            this.icons.splice(index, 1);
         }
      }
      if (this.layoutConfig.hasStatisticsTable) {
         if (this.icons.findIndex((icon: any) => icon.icon === 'blur_linear') === -1) {
            this.icons.push({ icon: 'blur_linear', format: 'statistics', text: 'Estadisticas de Tabla' });
         }
      } else {
         this.toggleStatistics = false;
         const index = this.icons.findIndex((icon: any) => icon.icon === 'blur_linear');
         if (index !== -1) {
            this.icons.splice(index, 1);
         }
      }

      this.isFetchingLayoutConfig = false;

      switch (this.tableConfig.headersType) {
         case 'multi':
            this.getMultiHeaders();
            break;
         case 'simple':
            this.getHeaders();
            break;
      }

      if (this.layoutConfig.datePickerType === 'none') this.getData();
   }

   async getReportConfig() {
      const res = await this.baseService.getReportConfig(this.genericParams);

      this.reportConfig = res;
      this.reportTitle = res.report.toUpperCase();
      if (res.id_gantt_type !== '') {
         this.tableConfig.hasGantt = false;
      }
      if (res.has_summary === '1') {
         this.summaryParams.id_report = res.id_summary_report;
         this.getSummaryHeaders();
      }
   }

   getMultiHeaders() {
      this.baseService.getMultiHeaders(this.genericParams)
         .then((res: any) => {
            if (res.success === '1') this.dataTableColumns = res.data.filter((columns: any) => columns.id_line !== '0');
         });
   }

   getHeaders() {
      this.baseService.getReportColumns(this.genericParams)
         .then((res: any) => {
            this.dataTableColumns = res;
         });
   }

   getSummaryHeaders() {
      this.baseService.getReportColumns(this.summaryParams)
         .then((res: any) => {
            this.summaryColumns = res;
         });
   }

   dateChanged(dateReceived: any) {
      if (dateReceived.date) {
         const dateFromEvent = dateReceived.date.format('YYYY-MM-DD');
         const dateFromParams = this.dataTableParams.start_date;
         const shiftFromEvent = (dateReceived.shift.shift).toString();
         const shiftFromParams = this.dataTableParams.shift;
         /**
          * Hay que validar que cuando se cambia de linea/reporte y se genera un nuevo
          * datepicker por la config del reporte este no vaya a buscar los datos que
          * ya se fueron a buscar en el OnInit porque habia parametros de fecha
          */
         if ((dateFromEvent !== dateFromParams) || (shiftFromEvent !== shiftFromParams)) {
            this.itemSearched = {};
            this.clearSearch = true;
            this.setDataTableParams(dateReceived);
            this.getData();
         }
      } else {
         this.itemSearched = {};
         this.clearSearch = true;
         this.setDataTableParams(dateReceived);
         this.getData();
      }
   }

   setDataTableParams(date: any) {
      this.isFetchingDateParams = true;

      if (date.shift) {
         this.dataTableParams.start_date = date.date.format('YYYY-MM-DD');
         this.dataTableParams.end_date = this.dataTableParams.start_date;
         this.dataTableParams.shift = date.shift.shift;

         this.statisticsParams.start_date = date.date.format('YYYY-MM-DD');
         this.statisticsParams.end_date = this.dataTableParams.start_date;
         this.statisticsParams.shift = date.shift.shift;
      } else {
         this.dataTableParams.start_date = date.start_date.format('YYYY-MM-DD');
         this.dataTableParams.end_date = date.end_date.format('YYYY-MM-DD');
         this.dataTableParams.shift = 0;

         this.statisticsParams.start_date = date.start_date.format('YYYY-MM-DD');
         this.statisticsParams.end_date = date.end_date.format('YYYY-MM-DD');
         this.statisticsParams.shift = 0;
      }
      this.isFetchingDateParams = false;
   }

   getData() {
      this.isFetchingData = true;
      this.isFetchingSummaryData = true;

      this.productionService.getReportDataSteelWorks(this.dataTableParams)
         .then((res: any) => {
            this.dataTableData = res.production;
            if (Array.isArray(res.summary) && res.summary.length) this.summaryData = res.summary;
            this.isFetchingSummaryData = false;
            this.isFetchingData = false;
            this.toggleFilters = false;
         });
      if (this.layoutConfig.hasStatisticsTable) {
         this.isFetchingStatistics = true;
         this.productionService.getReportDataSteelWorks(this.statisticsParams)
            .then((res: any) => {
               this.statisticsData = res.production;
               this.isFetchingStatistics = false;
            });
      }
   }

   searchResultReceived(item: any) {
      this.newDateFromSearch = {};
      this.newDateFromSearch.date = moment(item.fecha, 'DD/MM/YYYY');
      this.itemSearched = item;

      this.baseService.getShifts(this.genericParams.id_line)
         .then((shifts: any) => {
            this.newDateFromSearch.shift = shifts.find((shift: any) => shift.shift === item.turno);
            this.dateChangedSearch(this.newDateFromSearch);

         });
   }

   dateChangedSearch(dateFromSearch: any) {
      this.dateFromSearch = dateFromSearch;
      this.clearSearch = false;
      this.setDataTableParams(dateFromSearch);
      this.getData();
   }

   columnsFromModalReceived(columns: any) {
      this.userConfig.columns = columns;
   }

   handleMsgInfoIconsClick(event: any) {
      switch (event.format) {
         case 'collapsing':
            this.summaryCollapsed = event.collapsed;
            break;
         case 'excel':
            this.exportToExcel();
            break;
         case 'filter':
            this.toggleFilters = !this.toggleFilters;
            break;
         case 'statistics':
            this.toggleStatistics = !this.toggleStatistics;
            break;
         case 'customizer':
            this.openCustomizerTableModal();
            break;
         default:
            console.log('Nada programado');
            break;
      }
   }

   exportToExcel() {
      this.productionService.exportExcelSteelworkProduction(this.dataTableParams)
         .then(() => {
            console.log('Exportado a Excel');
         });
   }
}
