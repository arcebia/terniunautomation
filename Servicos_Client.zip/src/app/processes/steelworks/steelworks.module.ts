import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { PipesModule } from 'src/app/pipes/pipes.module';

import { SharedModule } from 'src/app/shared/shared.module';
import { SteelworksRoutingModule } from './steelworks-routing.module';

import { SteelworksGenericComponent } from './reports/steelworks-generic/steelworks-generic.component';
import { SummaryReportComponent } from './components/summary-report.component';
import { SteelworksSearchComponent } from './components/steelworks-search.component';

@NgModule({
   imports: [
      CommonModule,
      FormsModule,
      SteelworksRoutingModule,
      SharedModule,
      PipesModule
   ],
   exports: [
   ],
   declarations: [
      SteelworksGenericComponent,
      SummaryReportComponent,
      SteelworksSearchComponent
   ]
})
export class SteelworksModule { }
