import { Component, OnInit } from '@angular/core';
import { Router, RoutesRecognized } from '@angular/router';

import { ToastyService, ToastyConfig } from 'ng2-toasty';

import { SharedService } from './services/shared.service';
import { NavigationService } from './services/navigation.service';

@Component({
   selector: 'app-root',
   templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {

   hideMenu = true;
   hideHeaders = true;

   constructor(
      private router: Router,
      private navigationService: NavigationService,
      public sharedService: SharedService,
      public toastyConfig: ToastyConfig,
      private toastyService: ToastyService
   ) { }

   ngOnInit() {

      this.navigationService.navigationHandler();

      this.router.events.subscribe(navigationEvent => {
         if (navigationEvent instanceof RoutesRecognized) {
            const moduleRoute = navigationEvent.state.root.firstChild;
            const componentRoute = moduleRoute.firstChild;
            if (componentRoute && componentRoute.data) {
               const routeData = componentRoute.data;

               if (routeData.hideMenu !== undefined) {
                  this.hideMenu = routeData.hideMenu;
               } else {
                  this.hideMenu = false;
               }
               if (routeData.hideHeaders !== undefined) {
                  this.hideHeaders = routeData.hideHeaders;
               } else {
                  this.hideHeaders = false;
               }
            } else {
               this.hideMenu = false;
               this.hideHeaders = false;
            }
         }
      });

      this.sharedService.user.subscribe((user: any) => {
         // Cuando se obtiene el usuario se hace la redirección inicial (o no)
         if (user) this.navigationService.initialRedirectionHandler();
      });

      const isIEOrEdge = /msie\s|trident\/|edge\//i.test(window.navigator.userAgent);
      this.sharedService.isIEorEdge.next(isIEOrEdge);

      this.sharedService.toastSubject.subscribe(options => {
         this.toastyConfig.position = options.position;
         switch (options.type) {
            case 'default': this.toastyService.default(options); break;
            case 'info': this.toastyService.info(options); break;
            case 'success': this.toastyService.success(options); break;
            case 'wait': this.toastyService.wait(options); break;
            case 'error': this.toastyService.error(options); break;
            case 'warning': this.toastyService.warning(options); break;
         }
      });
   }
}
