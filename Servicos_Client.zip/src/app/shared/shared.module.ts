// Angular Modules
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { PipesModule } from '../pipes/pipes.module';
import { NgbTooltipModule, NgbDropdownModule, NgbCarouselModule, NgbDatepickerModule, NgbModule } from '@ng-bootstrap/ng-bootstrap';


import { D3Service } from 'd3-ng2-service';
import { Daterangepicker } from 'ng2-daterangepicker';
import { ChartModule } from 'angular2-highcharts';
import { HighchartsStatic } from 'angular2-highcharts/dist/HighchartsService';

import { DragulaModule, DragulaService } from 'ng2-dragula';

import { MaterialIconComponent } from './components/material-icon/material-icon.component';
import { ToggleComponent } from './components/toggles/toggle.component';
import { LoadingComponent } from './components/loading/loading.component';
import { ModalTableCustomizerComponent } from './components/tables/modal-table-customizer.component';
import { CustomTableComponent } from './components/tables/custom-table.component';
import { TableGridCurves2dComponent } from './components/tables/table-grid-curves2d.component';

import { DateShiftComponent } from './components/dates/date-shift.component';
import { DateRangeComponent } from './components/dates/date-range.component';


// Tables
import { DynamicCellComponent } from './components/tables/dynamic-cell.component';
import { TableHeaderGraphComponent } from './components/tables/table-header-graph.component';
import { ColumnFilterComponent } from './components/tables/column-filter.component';
import { ColumnsSelectionComponent } from './components/tables/columns-selection.component';
import { ModalColumnsSelectionComponent } from './components/tables/modal-columns-selection.component';
import { DynamicTemplateComponent } from './components/tables/dynamic-template.component';
import { DropdownComponent } from './components/dropdown/dropdown.component';
import { HighchartsComponent } from './components/highcharts/highcharts.component';
import { MessageInformationComponent } from './components/message-information/message-information.component';
import { GanttProgramComponent } from './components/gantt/gantt-program.component';


import { ModalCalendarComponent } from './components/modals/modal-calendar.component';

import { GanttComponent } from './components/gantt/gantt.component';
import { DatePickerHandlerComponent } from './components/dates/date-picker-handler.component';
import { DatePickerSwitcheableComponent } from './components/dates/date-picker-switcheable.component';

export function highchartsFactory() {
   const hc = require('highcharts');

   const stock = require('highcharts/modules/stock');
   stock(hc);
   const hcMore = require('highcharts/highcharts-more');
   hcMore(hc);
   const xRange = require('highcharts/modules/xrange');
   xRange(hc);
   const exporting = require('highcharts/modules/exporting');
   exporting(hc);

   return hc;
}


@NgModule({
   imports: [
      CommonModule,
      FormsModule,
      Daterangepicker,
      DragulaModule,
      NgbTooltipModule,
      NgbDropdownModule,
      NgbCarouselModule,
      NgbDatepickerModule,
      NgbModule,
      PipesModule,
      ChartModule
   ],
   exports: [
      MaterialIconComponent,
      ToggleComponent,
      LoadingComponent,
      CustomTableComponent,
      DynamicCellComponent,
      ColumnFilterComponent,
      ColumnsSelectionComponent,
      DynamicTemplateComponent,
      DateShiftComponent,
      DateRangeComponent,
      DatePickerHandlerComponent,
      DatePickerSwitcheableComponent,
      DropdownComponent,
      HighchartsComponent,
      MessageInformationComponent,
      GanttProgramComponent,
      GanttComponent,
      TableGridCurves2dComponent
   ],
   declarations: [
      MaterialIconComponent,
      ToggleComponent,
      LoadingComponent,
      CustomTableComponent,
      ModalTableCustomizerComponent,
      DynamicCellComponent,
      TableHeaderGraphComponent,
      ColumnFilterComponent,
      ColumnsSelectionComponent,
      ModalColumnsSelectionComponent,
      DynamicTemplateComponent,
      DateShiftComponent,
      DateRangeComponent,
      DatePickerHandlerComponent,
      DatePickerSwitcheableComponent,
      DropdownComponent,
      HighchartsComponent,
      ModalCalendarComponent,
      MessageInformationComponent,
      GanttProgramComponent,
      GanttComponent,
      TableGridCurves2dComponent
   ],
   entryComponents: [
      ModalColumnsSelectionComponent,
      ModalTableCustomizerComponent
   ],
   providers: [
      DragulaService,
      D3Service,
      {
         provide: HighchartsStatic,
         useFactory: highchartsFactory
      }
   ]
})
export class SharedModule { }
