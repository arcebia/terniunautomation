import { Component, OnInit, Input, ViewChild, EventEmitter, Output, OnChanges, SimpleChanges } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Subject } from 'rxjs/internal/Subject';
import { debounceTime } from 'rxjs/operators';

import * as _ from 'lodash';
import * as moment from 'moment';
import { DaterangePickerComponent } from 'ng2-daterangepicker';

import { DatepickerService } from 'src/app/services/datepicker.service';
import { BaseService } from 'src/app/services/base.service';
import { SharedService } from 'src/app/services/shared.service';

@Component({
   selector: 'date-shift',
   templateUrl: './date-shift.component.html',
   styleUrls: ['./date-shift.component.less']
})
// <date-shift [config]="{}" (change)="dateShiftChanged($event)"></date-shift>
export class DateShiftComponent implements OnInit, OnChanges {

   @Input() support: any;
   @Input() config: any;

   @Output() change = new EventEmitter();

   @ViewChild(DaterangePickerComponent) picker: DaterangePickerComponent;

   debouncer = new Subject();
   pendingDateChange = false;

   currentIdLine: any;
   shifts: any[];
   currentShift: any;

   chosenDate: any;

   options: any = {};
   rightarrow = 'assets/images/rightarrow.png';
   leftarrow = 'assets/images/leftarrow.png';
   daterange: any = {};
   all: any = {};
   lastShiftIndex: number;

   constructor(
      public sharedService: SharedService,
      private activatedRoute: ActivatedRoute,
      private baseService: BaseService,
      private dateService: DatepickerService
   ) {
      this.debouncer
         .pipe(debounceTime(1500))
         .subscribe((date: any) => {
            this.pendingDateChange = false;
            this.change.emit(date);
         });
   }

   /**
    * Cuando se recibe una fecha del componente padre en el input support
    * por ej. cuando se utiliza el buscador de coladas y se envia la fecha
    * del resultado de la busqueda. Simplemente posicionar el calendario
    * y el turno correspondiente a la fecha resultado de la busqueda,
    * no enviar la fecha devuelta al componente padre
    */
   ngOnChanges(changes: SimpleChanges) {

      if (!changes.support.firstChange && changes.support.currentValue) {
         this.chosenDate.date = changes.support.currentValue.date;
         this.chosenDate.shift = changes.support.currentValue.shift;
         /**
          * Se le pasa false para que no emita la fecha al componente padre
          * que ya realizo la request de la busqueda, de esta manera se evita
          * que haga 2 request iguales al mismo momento
          */
         this.applyDatePicker(this.chosenDate.date, false);
         this.options.startDate = this.chosenDate.date._i;
      }
   }

   async ngOnInit() {

      this.currentIdLine = this.activatedRoute.snapshot.paramMap.get('id_line');

      this.config.singleDatePicker = true;
      this.options = this.dateService.getConfig(this.config);

      await this.setShifts();

      if (this.sharedService.dateShift.getValue()) {
         // Hay fecha en el shared. Posiciona el picker en fecha
         this.chosenDate = this.sharedService.dateShift.getValue();
         this.applyDatePicker(this.chosenDate.date);
         this.options.startDate = moment(this.chosenDate.date);
      } else {
         // No hay fecha. Posiciona el picker en hoy

         await this.getCurrentShift();
         this.options.startDate = this.chosenDate.date;

      }

   }

   // Selecciona fecha desde el calendario, mantiene el turno que estaba
   selectedDate(value: any) {
      /**
       * Al seleccionar una fecha desde el calendario damos tiempo a que
       * seleccione un turno antes de hacer la request al server
       */
      this.pendingDateChange = true;
      this.applyDatePicker(value.start, true, true);
      // see original project for full list of options
      // can also be setup using the config service to apply to multiple pickers

      // this.daterange.start = value.start;
      // this.daterange.end = value.end;
      // this.daterange.label = value.label;
      // this.support.date = value.start;
   }

   // Asigna los turnos y setea turno Todos
   async setShifts() {
      this.shifts = await this.baseService.getShifts(this.currentIdLine);
      this.lastShiftIndex = this.shifts.length - 1;

      this.all = {
         shift: '0',
         start_time: this.shifts[0].start_time,
         end_time: this.shifts[this.lastShiftIndex].end_time,
         start_seconds: this.shifts[0].start_seconds,
         end_seconds: this.shifts[this.lastShiftIndex].end_time
      };
   }

   // Consigue el turno actual para la fecha del momento
   async getCurrentShift() {
      this.currentShift = await this.baseService.getCurrentShift(this.currentIdLine);

      this.chosenDate = {};
      this.chosenDate.shift = this.shifts[+this.currentShift[0].shift - 1];
      this.chosenDate.date = moment();

      this.applyDatePicker(this.chosenDate.date);
   }

   // Define el turno a partir de la seleccion de los botones
   selectShift(shift): void {
      if (!shift) {
         shift = this.all;
      }
      this.chosenDate.shift = shift;
      if (!this.pendingDateChange) this.applyDatePicker(this.chosenDate.date);
   }

   prevShift(): void {
      if (this.chosenDate.shift.shift === '0') {
         this.chosenDate.date.subtract(1, 'day');
      } else if (this.chosenDate.shift.shift === '1') {
         this.chosenDate.shift = this.shifts[this.lastShiftIndex];
         this.chosenDate.date.subtract(1, 'day');
      } else {
         this.chosenDate.shift = this.shifts[+this.chosenDate.shift.shift - 2];
      }
      this.applyDatePicker(this.chosenDate.date, true, true);
   }

   nextShift(): void {
      if (this.chosenDate.shift.shift === '0') {
         this.chosenDate.date.add(1, 'day');
      } else if (this.chosenDate.shift.shift === (this.lastShiftIndex + 1).toString()) {
         this.chosenDate.shift = this.shifts[0];
         this.chosenDate.date.add(1, 'day');
      } else {
         this.chosenDate.shift = this.shifts[+this.chosenDate.shift.shift];
      }
      this.applyDatePicker(this.chosenDate.date, true, true);
   }

   /**
    * Se encarga de setear los label de los turnos, emitir la fecha al componente padre
    * y actualizar el subject de dateShift en el shared service. Solo este componente
    * debería actualizar dicho subject, es su responsabilidad. De esta manera se mantiene
    * la ultima fecha y turno seleccionados aunque se cambie de reporte
    */
   applyDatePicker(date?: any, emit = true, debounce = false): void {

      this.chosenDate.date = date || moment();

      const dateToCompare = this.chosenDate.date.clone();
      dateToCompare.set({ 'hour': 0, 'minute': 0, 'second': 0, 'millisecond': 0 });

      const dateToAddStartSeconds = dateToCompare.clone();
      const dateToAddEndSeconds = dateToCompare.clone();

      const startSeconds = +this.chosenDate.shift.start_seconds;
      const endSeconds = +this.chosenDate.shift.end_seconds;

      const startDate = dateToAddStartSeconds.add(startSeconds, 'seconds').format('YYYY-MM-DD');
      const endDate = dateToAddEndSeconds.add(endSeconds, 'seconds').format('YYYY-MM-DD');

      this.chosenDate.shift.labelStart = `${startDate} ${this.chosenDate.shift.start_time}`;
      this.chosenDate.shift.labelEnd = `${endDate} ${this.chosenDate.shift.end_time}`;

      // Actualiza la fecha del shared y emite la fecha al componente padre.
      this.sharedService.dateShift.next(this.chosenDate);
      if (emit) {
         if (debounce) {
            this.debouncer.next(this.chosenDate);
         } else {
            this.change.emit(this.chosenDate);
         }
      }

      this.picker.datePicker.setStartDate(this.chosenDate.date);
      this.picker.datePicker.setEndDate(this.chosenDate.date);
   }

   /**
    * datePickerEvent(e: any) { }  Agregar en el html input si se quiere usar el evento(showCalendarDaterangepicker)="datePickerEvent($event)"
    **/
}

