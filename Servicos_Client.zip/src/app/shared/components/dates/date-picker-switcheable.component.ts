import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';

@Component({
   selector: 'date-picker-switcheable',
   templateUrl: 'date-picker-switcheable.component.html'
})

export class DatePickerSwitcheableComponent implements OnInit {

   @Input() config: any;
   @Input() support: any;
   @Input() defaultMode: any;

   filters: any = {
      byRange: false,
      byShift: true
   };

   @Output() change = new EventEmitter<any>();

   constructor() { }

   ngOnInit() {
      if (this.defaultMode) {
         this.filters = {
            byRange: false,
            byShift: false
         };
         this.filters[this.defaultMode] = true;
      }
   }

   selectFilter(option) {
      this.filters = {
         byRange: false,
         byShift: false
      };
      this.filters[option] = true;
   }

   handleDateChange(event: any) {
      this.change.emit(event);
   }
}
