import { Component, OnInit, Input, ViewChild, EventEmitter, Output } from '@angular/core';

import * as _ from 'lodash';
import * as moment from 'moment';
import { DaterangePickerComponent } from 'ng2-daterangepicker';

import { DatepickerService } from 'src/app/services/datepicker.service';

@Component({
   selector: 'date-range',
   templateUrl: './date-range.component.html'
})
// <date-shift [config]="{}" (change)="dateShiftChanged($event)"></date-shift>
export class DateRangeComponent implements OnInit {
   @Input() support: any;
   @Input() config: any;
   @Input() classes: any;

   @Output() change = new EventEmitter();

   @ViewChild(DaterangePickerComponent) picker: DaterangePickerComponent;
   options: any = {};

   id: number;

   constructor(
      private dateService: DatepickerService
   ) { }

   ngOnInit(): void {
      if (!this.support) {
         this.support = {};
      }
      if (!this.support.start_date) {
         this.support.start_date = moment();
      } else if (_.isString(this.support.start_date)) {
         this.support.start_date = moment(this.support.start_date);
      }
      if (!this.support.end_date) {
         this.support.end_date = moment();
      } else if (_.isString(this.support.end_date)) {
         this.support.end_date = moment(this.support.end_date);
      }
      this.config.singleDatePicker = false;
      this.options = this.dateService.getConfig(this.config);
      this.options.startDate = this.support.start_date;
      this.options.endDate = this.support.end_date;
      this.applyDatePicker();



      this.generate();
   }
   getRandomInt(min, max) {
      return Math.floor(Math.random() * (max - min + 1)) + min;
   }

   generate = function () {
      this.id = this.getRandomInt(1, 100);
   };
   // see original project for full list of options
   // can also be setup using the config service to apply to multiple pickers
   selectedDate(value: any) {
      this.support.start_date = value.start;
      this.support.end_date = value.end;
      // this.daterange.label = value.label;
      // this.support.date = value.start;
      this.applyDatePicker();
   }

   datePickerEvent(e: any) {
      // this.picker = e.picker;
   }

   applyDatePicker(): void {
      this.change.emit(this.support);
   }

}
