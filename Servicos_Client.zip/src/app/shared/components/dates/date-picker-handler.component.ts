import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
   selector: 'date-picker-handler',
   templateUrl: 'date-picker-handler.component.html'
})

export class DatePickerHandlerComponent implements OnInit {

   @Input() support: any;
   @Input() config: any;
   @Input() datePickerType: any;
   @Input() defaultMode: any;

   @Output() change = new EventEmitter<any>();

   constructor() { }

   ngOnInit() { }

   handleDateChange(event: any) {
      this.change.emit(event);
   }
}
