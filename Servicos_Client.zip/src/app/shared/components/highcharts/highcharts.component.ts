import { Component, OnInit, Input, EventEmitter, Output, HostListener, AfterContentInit } from '@angular/core';
import * as _ from 'lodash';
import { SharedService } from 'src/app/services/shared.service';
import * as Highcharts from 'highcharts';

@Component({
   selector: 'highcharts',
   templateUrl: './highcharts.component.html'
   // template: '<chart [options]="options"></chart>'
})

export class HighchartsComponent implements OnInit, AfterContentInit {
   @Input() title: string;
   @Input() categories: any[];
   @Input() series: any[];
   @Input() type: string;
   @Input() config: any;
   @Input() chart: any;
   @Output() chartInstance = new EventEmitter();
   @Output() zoomX = new EventEmitter();
   @Output() zoomY = new EventEmitter();
   @Output() chartSelection = new EventEmitter();
   @Output() chartSelectedRange = new EventEmitter();

   highchartConfig: any;
   // chart: any;
   constructor(
      public sharedService: SharedService) {
   }

   ngAfterContentInit() {
      this.initRender();
      this.loadCustomIcons();
   }

   loadCustomIcons() {
      // Temporalmente comentado bug de highchart para dibujar los iconos en las tablas
      // y no usar base 64
      // Highcharts.SVGRenderer.prototype.symbols.download = function (x, y, w, h) {
      //     var path = [
      //
      //         'M', x + w * 0.5, y,
      //         'L', x + w * 0.5, y + h * 0.7,
      //         // Arrow head
      //         'M', x + w * 0.3, y + h * 0.5,
      //         'L', x + w * 0.5, y + h * 0.7,
      //         'L', x + w * 0.7, y + h * 0.5,
      //         // Box
      //         'M', x, y + h * 0.9,
      //         'L', x, y + h,
      //         'L', x + w, y + h,
      //         'L', x + w, y + h * 0.9
      //     ];
      //     return path;
      // };
      //
      // Highcharts.SVGRenderer.prototype.symbols.table = function (x, y, w, h) {
      //       var path = [
      //         'M', x , y + (h * .14),
      //         'L', x + w, y + (h * .14),
      //         'M', x + w, y + (h * .14),
      //         'Z',
      //         'L', x + w, y + h,
      //         'M', x + w, y + h,
      //         'L', x, y + h,
      //         'Z',
      //         'M', x, y + h,
      //         'L', x, y + (h * .14),
      //         'M', x , y + (h * .16),
      //         'L', x + w, y + (h * .16),
      //         'M', x , y + (h * .26),
      //         'L', x + w, y + (h * .26),
      //         'M', x , y + (h * .36),
      //         'L', x + w, y + (h * .36),
      //         'M', x , y + (h * .7),
      //         'L', x + w, y + (h * .7),
      //         'M', x + (w * .5), y + (h * .36),
      //         'L', x + (w * .5 ), y + h,
      //       ]
      //       return path;
      //   };
   }




   // ngAfterViewInit

   ngOnInit(): void {
      // this.initRender();
   }

   @HostListener('window:resize', ['$event']) getWindow(event) {
      this.initRender();
   }

   initRender() {
      const highchartComponent = this;
      this.highchartConfig = {
         chart: {
            type: this.type,
            renderTo: this.config.id,
            height: this.config.id && document.getElementById(this.config.id) ? +document.getElementById(this.config.id).offsetHeight : null,
            width: this.config.id && document.getElementById(this.config.id) ? +document.getElementById(this.config.id).offsetWidth : null,
            style: {
               fontFamily: 'open-sans',
               color: this.sharedService.colorFontHighchart
            }
         },
         credits: {
            enabled: false
         },
         exporting: {
            enabled: false
         },
         lang: {
            printChart: 'Imprimir Gráfica ',
            downloadPNG: 'Descargar como PNG',
            downloadJPEG: 'Descargar como JPEG',
            downloadPDF: 'Descargar como PDF',
            downloadSVG: 'Descargar como SVG',
         },
         navigation: {
            buttonOptions: {
               align: 'left',
               y: -8,
               X: 10
            }
         },
         colors: this.sharedService.colorsHighcharts,
         title: {
            style: {
               color: this.sharedService.colorFontHighchart
            }
         },
         legend: {
            itemStyle: {
               color: this.sharedService.colorFontHighchart
            }
         },
         xAxis: {},
         series: this.series
      };
      this.highchartConfig = _.merge(this.highchartConfig, this.config);

      if (this.config.enabledExport) {
         this.highchartConfig.exporting = {
            enabled: true,
            buttons: {
               contextButtons: {
                  symbolFill: '#282934',
                  enabled: false,
                  menuItems: null,
               },
               ShowGridButton: {
                  className: 'custom-hc-button',
                  symbol: 'url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAMAAADDpiTIAAACEFBMVEUAAAAAAACAgIBVVVWAgIBmZmZVVVVtbW1gYGBxcXFmZmZdXV1qampiYmJtbW1mZmZgYGBpaWlra2tmZmZhYWFoaGhkZGRiYmJkZGRmZmZjY2NoaGhkZGRmZmZjY2NlZWVpaWlnZ2dlZWVoaGhkZGRnZ2dlZWVoaGhmZmZkZGRnZ2dmZmZnZ2dlZWVoaGhmZmZkZGRnZ2dlZWVnZ2dmZmZlZWVlZWVnZ2dmZmZlZWVnZ2dlZWVnZ2dlZWVnZ2dlZWVnZ2dmZmZlZWVnZ2dnZ2dmZmZlZWVnZ2dlZWVnZ2dmZmZlZWVnZ2dlZWVnZ2dlZWVmZmZnZ2dmZmZnZ2dlZWVmZmZmZmZnZ2dmZmZnZ2dmZmZlZWVmZmZmZmZnZ2dmZmZmZmZnZ2dmZmZnZ2dmZmZmZmZnZ2dmZmZmZmZmZmZnZ2dmZmZlZWVmZmZnZ2dmZmZlZWVnZ2dmZmZmZmZmZmZlZWVmZmZmZmZnZ2dlZWVmZmZmZmZnZ2dmZmZlZWVmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmb///+KWaT/AAAArnRSTlMAAQIDBAUGBwgJCgsMDQ4PEBETFBUWFxocHh8gISMkJicqKywzNDU2Nzg5PD4/QEFCQ0RFRkdJSktMTU5PUVJTVFVWV1laW1xdXl9gYWJjZWdoa21vcXZ3gIGCg4SFhoeMkJSVlpmaoKKjpKWmqKmssLO5u76/wMHCxMXGx8jJysvNztDR0tPU1dbX2Nrb3N3e3+Dh4uPk5ebn6Ovs7e7v8PLz9PX29/j5+vv8/f6CiztVAAAAAWJLR0SvzmyjMQAACApJREFUeNrt3Vtsl2cBx/Gnb0uPwHoAkdHJaZQ6ycYqLR0LVsZGTLYswBKRLNGpiQkXmphFbrxdjNF4o8bEGBNNNGYx1rigMduyOZAAZYhm49Cl61o3tWMt9MiYtNSLloPQ9i1OQt/3+XxuNuiT5p9fv3v//R/ahQAAAAAAAAAAAAAAAAAAAADMdQWzO1a5ZNXiqqqiioqiSpvNaf2jIyMX+8/2dvYM/L8CWNJQe89yy2ZO98mOv5390AHc0bK2sciYGTXa1r5/4EMEkGxsbC41Y6a9f7jt6KX/LYCyRzffZcAcePvAvgs3H0DxYy2+/Hnx91f2XbzJAJp3+b4vT7qePXIzASz77Gab5cyBZ/856wAe+vxCg+XOwM9emeJvC2/8q/Iv7y4xV/6UNledvDiLAGq/uslY+bR6ZcdQagDrvum7v9xauqnjvZQAtny9wk45vht4sK9rxgB2fGmelfKsaMPo6RkCePQLiY3yLbl3sGPaALZ8xdc/9wrWn+meJoANX/O6XwzXgPXtZ6YMYPk3fP8Xx/cB9x0fnCKA8qdrbROHshWHRm8M4Klmy8RicenxGwLYttsu8ajr67z8HcHkPxftskpMdlVfdwX44j1GiUl5ybH/ugLcv9Umcdl237UBlDxpkcgU7J53zV3A45+2SGxqRtqvXAGK3QFE6JF5VwL4zJ3miM+yRy4HUOQOIEpbCycD2LjCGDFa2TgZQKMt4rRxIoBFD5giTg9Uh5CE0OJdYJEqbgkhCaHeErGqCyEJNfcbIlYbqkIS1nkfYLQKPxGSsNoO8VoTklBnhnjdHZLKNWaI19qFydICM8Qr+Wiy0goxW5nUGCFmNUm1EWK2KFlghJhVJH4cLGrzBSAA3AUQ7xWg2AgxK/ZSYOQEIAAEgAAQAAJAAAgAASAABIAAEAACIK9S/w8BO2/zDWx1+27p7XMFcBeAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAhAAAgAASAABIAAEAACIBIFrTZwBUAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgACY64rSDuy8zTew1e27pbfPFcBdAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAAEgAASAABAAAkAACIBIFLTawBUAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACYK4rSjuw8zbfwFa375bePlcAdwEIAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAAJg6gIspB+bZKMtKUj7+QTKccmKhEbMs7cs3nIyknFhkxCxbnPLxkdQrwFojZlld6hXgfMqJu4yYZR9LvQIMppxonm/F7FrQlHJgKDmbcqJiixmz66HylAN9SW/a5/hUkR2zqrgl7URv0pV2ZPUOQ2bV9hVpJ7qSnvHUz1JnyWz6+Pa0E5feTfpPph0q2+uRQDYfATxdmnbkxGASOlM/UfWepdbMnjv3VKeeeSsk4VT6p6p/psGeWfPJZ2bxHN6JkIRTo+nnqvY+6emATCn93N7K9FMXT4WiMPBq8yweTzyx+Q/PX7BrVr78D2+rnc25tuFQFEJ782zOfuSpHUe63+zvGzPvnFZYU7V6+cZZvoZ7OoSCEBb+qNxuURreMxKSEAaPmCJOh0cm3hJ2zBRxOhYmAjh0yhYxeq1tMoDxPxkjRvvHJwMIL3VaIz5vvhwuBzB20BzxOXDpSgDhudftEZvj+8LVAMZ+cckicRn71cSXvHDij32Vd9skKn98MVxzBQih9ZxNYtLXOvkvk1eAcL5nU4FZ4rkD+N5b1wUQ/lFWb5do/PaFcH0A4cTyZYaJxMGfXHkn6NUfDx/9ea9l4nDml1cf9F29AoThk02lxolA/7feCVMFEM51bvJDIPl34TtvhKkDCGfON3gokHfjPz0UpgsgdPSsdw3I+X//P3w5TB9A6O5oKDFSjg1+92iYKYDw7mv3egN4fv3r26fDzAGEc39d6ueA8urV778d0gIIQwdDvV8el0djv/7xUEgPIIy/3l3vjeL5894Pnp/ib6d+2Ff++PZii+XKB797bspfBzXd4/4VTzxotBz582+6p/7AtE/8JA9vXWO3nHjjxZeme8vXTM/8NTy23nY5cPz3f5n+gzM+9Zs0NTV7fSjb3j/c1jbTbwFKe+7/jpa1jZ4dzqrRtvb9AzMfmcWLP2Wr1tU2+aXhWfPvo+8c60r/5R+zfPWvcsmqxVVVFfPLF1h2jhs6PzTSf7a3s2fAFgAAAAAAAAAAAAAAAAAAAJAT/wH2zSNo1LUIzgAAAABJRU5ErkJggg==)',
                  symbolStrokeWidth: 1,
                  symbolSize: 16,
                  onclick: function () {
                     highchartComponent.showGridTable();
                  },
               },
               excelButton: {
                  className: 'custom-hc-button',
                  symbolSize: 16,
                  symbol: 'url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAYAAAAIACAMAAAC8QUvIAAACi1BMVEUAAAAAAACAgIBVVVWAgIBmZmZVVVVtbW1gYGBxcXFmZmZdXV1qampiYmJtbW1paWljY2Nra2tmZmZhYWFkZGRqampmZmZiYmJoaGhjY2NoaGhkZGRpaWlmZmZjY2NlZWVpaWlmZmZkZGRnZ2dlZWVoaGhmZmZkZGRnZ2dlZWVoaGhmZmZkZGRnZ2dlZWVoaGhkZGRnZ2dlZWVoaGhmZmZkZGRnZ2dlZWVoaGhmZmZkZGRlZWVnZ2dmZmZlZWVnZ2dlZWVnZ2dmZmZlZWVnZ2dlZWVnZ2dmZmZlZWVnZ2dlZWVnZ2dmZmZlZWVnZ2dlZWVmZmZlZWVnZ2dnZ2dmZmZlZWVnZ2dlZWVnZ2dmZmZlZWVnZ2dmZmZnZ2dmZmZlZWVmZmZmZmZnZ2dmZmZlZWVmZmZmZmZnZ2dmZmZlZWVmZmZmZmZnZ2dmZmZlZWVmZmZmZmZnZ2dmZmZmZmZnZ2dmZmZnZ2dmZmZlZWVlZWVmZmZmZmZmZmZlZWVmZmZmZmZnZ2dmZmZnZ2dlZWVmZmZmZmZnZ2dmZmZlZWVmZmZmZmZnZ2dmZmZmZmZnZ2dmZmZlZWVmZmZmZmZnZ2dmZmZlZWVmZmZmZmZmZmZmZmZmZmZnZ2dmZmZlZWVmZmZmZmZnZ2dmZmZmZmZlZWVmZmZmZmZnZ2dmZmZmZmZmZmZnZ2dmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmb///9lFD+CAAAA13RSTlMAAQIDBAUGBwgJCgsMDQ4REhMUFRcYGRobHyAhIiMkJicoKSorLC0uLzAxMjM0NTY4OTo7PD0+P0BBQkRFRkdISUpLTE1OT1BRUlNUVVZXWFpbXF5fYGFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6e3x/gIGChoeIjY6PkZKTlJWZmpydnp+goaKjpKWoqaqrrK2ur7CxsrS2t7i5uru8vb7DxMXGx8jKy8zOz9DR0tXW19jZ2tvc3eHi4+Tl5ufo6err7O3u7/Dx8vP09fb3+Pn6+/z9/qFHsHUAAAABYktHRNgADUeuAAAKnklEQVR42u3d+2PVdR3H8ffm1gYy2GqMi0AbYMI2uYgMNAREV6BuaIkKKJGhhNHIKMNIUkvMyjDUMkEMEEiloW4gd4XBLlx2OWff8/l3+qEImIydc77v7/fzvTyf/8Dne16PHbZzdvZFhIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIyM9Grd7Z1Gr6zzn1yd+XFLOTR03eYdIp8VIZW3nR0h6TZqdnspZ+vzLp11PPXto9aTIpMYvFdJvYkxGAOTaYzVT7h8mw9WymWWWm+5v2Qaym2IaMAcxCVlOsMXOAl1lNsQuZA+xkNb2KMt/fNDGbXiOyADjBbAAAQAAAQAAAQAAAQAAAQAAAQAAAQAAAQAAAQAAAQAAAQAAAQAAAQAAAQAAAQAAAQAAAQAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAABAAABAAABAAABAAABAAABAAABAAABAAABAAABAAABAAABAAABAAABAAABAAABAAABAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAEAAAEAAAEAAAEAAAEAAAEAAAEAAAEAAuCn3zud2ffTRXxu+GVeAwbUvf3D8bNP7z5TbmD+n/pP/PVLn9fI4AhSsPnPpqNTfJvu+/+C/XPFYzy+OH8C4z648rHdtjr/7f+PDqx/tz+IGMONMn+P+nO/rN8Wmvg93ebwAZnd+5bx3C338+m/8yvFdNXECqG67xoFb8+19/RtjLs6KD8Ct7dc80a/nwDX3N6ZjalwAKtv6OdIfgX72N6a9Oh4AE073e6YfAv3ub0zLzXEAGHv8Ood6L3Cd/Y05NT76AKOPXvdUrwWuu78xx8ZEHWDEoQGO9VZggP2NOTI62gDDmwc810uBAfc35tCIKAOUNKZxsHcCaexvTFNpdAGG7U/rZK8E0trfmMbiqAIU7UnzaG8E0tzfmI+HRRPgxl1pn+2FQNr7G7NnSBQBCt/L4HB9gQz2N+afg6IHkP92RqdrC2S0vzHbC6IGkLc1w+N1BTLc35i38qMFkPtaxudrCmS8vzFv5EUJIOeVLC5ATyCL/Y15NTdCAC8YY1Fg0IdZHb8xOgDrTXb9UeU39TmvZ3n8c1EBWGuybb3G8fVZH/98NAAaTPbNUPj5qzn745+NAsAaF/ubve7/EZrj4vjUD8MP8H3HDYCZ5voCXnRzfGpl2AGWplztbza5voIDrs53Hgo3wHcS7vY3h11fQqu7C3C+F2aAWrf7m9RQt6/BXT4FTc894QW4o9O4rsrtRbS7vYLEvWEF0NjfTHd7Fc2uL0HhQ4tWAG5tN0EA2Oz+GjpnhxFgSofG/uYmt499kcJFXJgZPoCqNpX9u1y/Jzn4C4XLOPOtsAGMO6Gyv9nt/hvgCo3raKsMF0DFlzr7mzXuAQr+pXEhx8eGCWDk50r7J0Yp/BBeesS6gM8AavubF1XeCLilReNa3Hxo0V+AkgM665+eMuxrOu+FlZ+0LOArgNb+J8r1fiOlI9A8PAwAxft19j+puL+WQGNJ8AGK9gZxfy2B/cOCDjBkdzD3F6lQEdhTFGyAwh1B3V9LYNeNQQYo2Ka0f4V4UIXGmxLmvcLgAuS9GeT9tQTezg8qwA1bdPb/wqP9tQS25gUTIHdz0PfXEngtN4gAOb8N/v5a70q8khNAgI1h2F9L4IXgAfxSaf/xImEQ+HXQANbp7N9yi0g4BH4eLICfhGd/kUkqAg1BAvhBKkT7awmsCQ7AMqX9J4mESCD1RFAAHuwN2f4ik85oCCwNBkBd+PYXmawh0Ls4CAD39IRwfyWBRK19gPk6+5/xeX8lgZ4FtgFmXdTZ3/+bR+sIdN5hF2BqR2j3VxK4WGMToLo9xPsrCXRMsQcwsSXU+4tUagi0VdkCGH8q5PuLVJ5VeACnJ9gBGHMs9PsrCXxZYQNglMpHXs3ZSpHQCxy9yX+AsoOR2F+kSkPg85F+A5Q2RWR/JYGDZf4CFP87MvsrCRwo8RNg6D6d/atEIiOwv9g/gCEfRGp/kapWhYezt8gvgEHvR2x/kWoNgd1D/AEo2K6yf2uA9lcS2FHoB0D+Wzr7V0ugmqbxtuK2Au8B8t6I5P4i0zUE3szzGiD3VZX9O6aJRFJgyw3eAuT8Xmf/6SIRFdic6ynAbyK8v5LAJi8Bno/0/iK3nVN4eBu9A3g24vsrCfzCK4C1OvvfJhJxgXXeAKxU+QDiuUDvryTwjBcAj8dif5EZCgKpFfoADznx2F9JYJk2QH1vXPbXEeh9UBfg3oTK/jNEYiNQpwmg8wHQsOyvI3DVHXddAsy+GK/9RW4/7/7xdt6pBTDzQtz21xG44o67rgB07oB77naRuAl0TNUAuFnlA6DnQ7a/jkB7tXuACafiub/ITAWBloluAcYej+v+OgKnxrsDGH00vvvrCBwb4wZgxCGV/WeKxFfgyKjsAYY3x3t/kRoFgYNl2QKUNMZ9f5EahddATaXZAQzbz/4iC7rdb7BvaDYALTs19u++W0LeHIX/CWdfubHUhRoJfRrPgY8t7d+9QCKQxnPATp1zRBBg/7gKRGd/kbu62B+BDPe/SwQBe3VFbP+wCURvf5G5XeyPQJr7zxVBgP31m9fF/ggMuP88EQTYP64CUd9fZH4X+1sW6GZ/BPr5/ct8EQTYP64C8dlf5O5u9kcgap8/CbdA3PYXWZhgf7stCpBAYqEIAhb3XySCAPvHVSC++4vcl2D/uAvEe3/7Aon7JObdn2B/ywJJ9o+rQPJ+1rcpwP52Bdj/cg8k2T9uAskHWP3K6pLsHycB9rcrkKxjb5sC7G9XgP37qz7J/tEXSNazs00B9r9+i3vZP8oCycUsPFAPO97t38v+abTEMwHnYda1KeAsYVubAuyffo847B81AecRVs2kRx32j5IA+9sVcB5lT5sC7G9XgP2z7TGH/cMv4DzGjjYF2N9dSx32D7OAs5QFbQqwv0bLUuwfToG+/y83+SvA/nYF2F+z5Sn2D5dAajmb2RRgf/1Wpdg/LAKpx1nLpkBqFVt501PsHwKB1FPsZFWA/e0KsL/HPc3+QRZ4mn2sCrC/L61m/2AKrGYZqwLs72M/Zn/LrevzvlCqgU38bV7blfu3zmURvxv9p/9/YMj5wyj2sFBFw+6TyeTJXT8tZwsiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIvKx4Su2f9piyJdaPt32xPCr5h+3xWEWf3O2jL28/3fPM4j/nau9tP8qvvztPAme/O/+9Sm2sFOqTkSkrIMlbNVeKiK/Ywd7vSQyMskM9kqUyY9YwWYr5V1GsNk7cpARbNYkvAaz+2pM2MBuAAAAAAEAAAEAAAEAAAEAAAEAAAEAAAEAAAEAAAEAAAEAAAEAAAEAAGkC8OFcq52TZkaw2Wf8gYbd3pEVjGCz5fyRntUSZSKbmMFeG/lDbau1l4qIzOEfIUslv83NOmx26WYd3K7G0muw2ss3DPr6hk4G8bfODSV9b1l2uJtZ/Kn7cN9blhERERERERERERERERERERERERERERERUZj7D1bgkN40TVguAAAAAElFTkSuQmCC)',
                  symbolStrokeWidth: 1,
                  onclick: function () {
                     highchartComponent.exportDataToCsv();
                  },
               }
            }
         };
      }
   }

   showGridTable() {
      this.config.gridHide = !this.config.gridHide;
      const _parentID = this.config.id;
      setTimeout(function () {
         const scroller = document.getElementById('table_content_grid_2d_for_' + _parentID);
         if (scroller) {
            scroller.scrollIntoView();
         }
      }, 500);
   }

   removeTransformInCustomButtons() {
      setTimeout(() => {
         const elements = document.getElementsByClassName('custom-hc-button');
         if (elements) {
            for (let i = 0; i < elements.length; i++) {
               elements[i].getElementsByTagName('image')[0].removeAttribute('transform');
            }
         }
      }, 500);
   }

   saveInstance(chartInstance) {
      this.chart = chartInstance;
      this.chartInstance.emit(this.chart);
      this.removeTransformInCustomButtons();
   }

   onAfterSetExtremesX(e) {
      this.zoomX.emit({
         e: e,
         chart: this.chart
      });
   }

   onAfterSetExtremesY(e) {
      this.zoomY.emit({
         e: e,
         chart: this.chart
      });
   }

   onChartSelection(e) {
      this.chartSelection.emit(e);
   }

   onChartSelectedRange(e) {
      this.chartSelectedRange.emit(e);
   }

   // Generar el archivo de Excel
   exportDataToCsv() {
      const _data = this.generateDataFile();
      const _fileName = 'data_line_curve.csv';
      const blob = new Blob([_data], { type: 'text/csv' });
      if (window.navigator.msSaveOrOpenBlob) {
         window.navigator.msSaveBlob(blob, _fileName);
      } else {
         const elem = window.document.createElement('a');
         elem.href = window.URL.createObjectURL(blob);
         elem.download = _fileName;
         document.body.appendChild(elem);
         elem.click();
         document.body.removeChild(elem);
      }
   }

   generateDataFile() {
      let _fileData = '';
      _fileData += this.generateRowTable(this.series[0].data, '', true);

      for (const serie of this.series) {

         const _data = serie.data;
         const _variableName = serie.name;
         // Header Data
         _fileData += this.generateRowTable(_data, _variableName);
      }

      return _fileData;
   }

   generateRowTable(_data, _variableName, isForHeader = false) {
      let row = _variableName + ',';
      for (const item of _data) {
         const _item = isForHeader ? this.getXAxisLabel(item[0]) : item[1];
         row += _item + ',';
      }

      return row + '\n';
   }

   getXAxisLabel(val) {
      let date: Date;
      if (this.config.xAxis.type === 'datetime') {
         date = new Date(val);
         return date.getUTCHours() + ':' + date.getUTCMinutes() + ':' + date.getUTCSeconds();
      }
      return val.toFixed(2);
   }

}
