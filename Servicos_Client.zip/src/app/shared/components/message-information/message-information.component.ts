import { Component, OnInit, Input, EventEmitter, Output, OnChanges, SimpleChanges } from '@angular/core';
import { BaseService } from 'src/app/services/base.service';
import { ActivatedRoute } from '@angular/router';

@Component({
   selector: 'message-information',
   templateUrl: './message-information.component.html'
})

export class MessageInformationComponent implements OnInit, OnChanges {

   @Input() reportConfig: any;
   @Input() idReport: string;
   @Input() reportTitle: string;
   @Input() isGeneric: boolean;
   @Input() icons = [];
   @Input() collapsed: boolean;
   @Input() collapsable: boolean;
   @Output() action: EventEmitter<any> = new EventEmitter();

   idLine;

   bannerMessage: string;
   bannerClass: any;

   constructor(
      private baseService: BaseService,
      private activatedRoute: ActivatedRoute
   ) {
   }

   ngOnChanges(changes: SimpleChanges) {

      if (!this.idLine) this.idLine = this.activatedRoute.snapshot.paramMap.get('id_line');

      if (this.idLine) {
         if (!this.idReport && this.reportConfig) {
            this.bannerMessage = this.reportConfig.banner_message;
            this.bannerClass = this.reportConfig.banner_class;
         } else if (this.idReport) {

            if (this.isGeneric === undefined) {
               this.isGeneric = false;
            }

            const reportParams = {
               id_line: this.idLine,
               id_report: this.idReport ? this.idReport : -1
            };

            const genericReportParams = {
               id_line: this.idLine,
               id_generic_report: this.idReport ? this.idReport : -1
            };

            if (this.isGeneric === false) {
               this.baseService.getReportConfig(reportParams)
                  .then((data) => {
                     this.bannerMessage = data.banner_message;
                     this.bannerClass = data.banner_class;
                  });
            } else {
               this.baseService.getGenericReportConfig(genericReportParams)
                  .then((data) => {
                     this.bannerMessage = data.banner_message;
                     this.bannerClass = data.banner_class;
                  });
            }

         }
      }
   }

   ngOnInit() { }

   iconClick(format) {
      this.action.emit({
         format: format
      });
   }

   collapsing() {
      this.collapsed = !this.collapsed;
      this.action.emit({
         format: 'collapsing',
         collapsed: this.collapsed
      });
   }
}
