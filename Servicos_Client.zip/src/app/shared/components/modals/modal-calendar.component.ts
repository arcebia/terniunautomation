import { Component, OnInit } from '@angular/core';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import * as _ from 'lodash';

import { BaseService } from 'src/app/services/base.service';
import { SharedService } from 'src/app/services/shared.service';
import { ActivatedRoute } from '@angular/router';

export class DataModal {
   data: any;
}

@Component({
   selector: 'modal-calendar',
   templateUrl: './modal-calendar.component.html'
})

export class ModalCalendarComponent implements OnInit {

   currentIdLine: any;
   data: any;
   currentMonth: number;
   now: Date = new Date();
   model: NgbDateStruct;
   shifts: any[];
   all: any = {};
   date: {
      year: number,
      month: number
   };
   rightarrow = 'assets/images/rightarrow.png';
   leftarrow = 'assets/images/leftarrow.png';

   constructor(
      private activatedRoute: ActivatedRoute,
      public sharedService: SharedService,
      public activeModal: NgbActiveModal,
      private baseService: BaseService
   ) { }

   confirm(resp) {
      // we set dialog result as true on click on confirm button,
      // then we can get dialog result from caller code
      // this.result = true;
      if (resp) {
         this.data.date = moment([this.model.year, this.model.month - 1, this.model.day]);
         if (this.data.shift.shift === '1') {
            const d = this.data.date.clone();
            this.data.shift.labelStart = d.subtract(1, 'day').format('YYYY-MM-DD') + ' ' + this.data.shift.start_time;
            this.data.shift.labelEnd = this.data.date.format('YYYY-MM-DD') + ' ' + this.data.shift.end_time;
         } else if (this.data.shift.shift === '0') {
            const d = this.data.date.clone();
            this.data.shift.labelStart = d.subtract(1, 'day').format('YYYY-MM-DD') + ' ' + this.all.start_time;
            this.data.shift.labelEnd = this.data.date.format('YYYY-MM-DD') + ' ' + this.all.end_time;
         } else {
            this.data.shift.labelStart = this.data.date.format('YYYY-MM-DD') + ' ' + this.data.shift.start_time;
            this.data.shift.labelEnd = this.data.date.format('YYYY-MM-DD') + ' ' + this.data.shift.end_time;
         }
         // this.result = this.data;
      }
      this.activeModal.close(this.data);
   }

   ngOnInit(): void {

      this.currentIdLine = this.activatedRoute.snapshot.paramMap.get('id_line');

      if (!this.data.date) {
         this.selectToday(this.now);
         this.getCurrentShift();
      } else {
         this.selectToday(moment(this.data.date).toDate());
      }
      this.baseService.getShifts(this.currentIdLine)
         .then(shifts => {
            this.shifts = shifts;
            this.all = {
               shift: '0',
               start_time: shifts[0].start_time,
               end_time: shifts[2].end_time
            };
         });
   }

   getCurrentShift(): void {
      this.baseService.getCurrentShift(this.currentIdLine)
         .then((shift) => {
            this.data.shift = this.shifts[+shift.shift - 1];
         });
   }

   prevShift(): void {
      if (this.data.shift.shift === '1' || this.data.shift.shift === '0') {
         this.data.shift = this.shifts[2];
         this.data.date.subtract(1, 'day');
         this.selectToday(moment(this.data.date).toDate());
      } else {
         this.data.shift = this.shifts[+this.data.shift.shift - 2];
      }
   }

   nextShift(): void {
      if (this.data.shift.shift === '3' || this.data.shift.shift === '0') {
         this.data.shift = this.shifts[0];
         this.data.date.add(1, 'day');
         this.selectToday(moment(this.data.date).toDate());
      } else {
         this.data.shift = this.shifts[+this.data.shift.shift + 2];
      }
   }

   selectShift(shift): void {
      if (!shift) {
         shift = this.all;
      }
      this.data.shift = shift;
   }

   selectToday(date: Date) {
      this.model = {
         year: date.getFullYear(),
         month: date.getMonth() + 1,
         day: date.getDate()
      };
      this.currentMonth = this.model.month;
   }

   isPastMonth(date: NgbDateStruct) {
      return date.month !== this.currentMonth;
   }

   isFutureDate(date: NgbDateStruct) {
      return date.month > this.now.getMonth() + 1;
   }

   onDateChange($event) {
      if ($event.current) {
         this.currentMonth = $event.next.month;
      }
   }

   isCurrentDate(date: NgbDateStruct) {
      return _.isEqual(this.model, date);
   }

}
