import { Component, OnInit, Input, AfterContentInit } from '@angular/core';
import { ElementRef, HostListener } from '@angular/core';

import { D3Service, D3, Selection } from 'd3-ng2-service';
import * as moment from 'moment';
import * as _ from 'lodash';

import { GanttService } from 'src/app/services/gantt.service';


@Component({
   selector: 'gantt-program',
   templateUrl: './gantt-program.component.html'
   // template: '',
   // styleUrls: [ './gantt.component.css' ]
})
export class GanttProgramComponent implements OnInit, AfterContentInit {
   @Input() data: any;

   private d3: D3;
   private parentNativeElement: any;
   private d3Svg: Selection<SVGSVGElement, any, null, undefined>;
   ganttConfig: any;
   windowWidth: number;
   measure: any;
   xOffset: number;
   yOffset: number;
   chartWidth: number;
   yAxisSize: number;
   dataNames: any;
   factorHeightTop: number;
   factorHeightBottom: number;
   factorWidth: number;
   ganttData: Object[]; // SteelCoils
   barBottomData: Object[]; // Delays
   xMarksData: Object[]; // Defect
   barTopData: Object[]; // Schedules
   id: string;
   xs: boolean;
   y0: any;
   y1: any;

   constructor(
      element: ElementRef,
      d3Service: D3Service,
      private ganttService: GanttService
   ) {
      this.d3 = d3Service.getD3();
      this.parentNativeElement = element.nativeElement;
   }

   ngOnInit() {
      // Called after the constructor, initializing input properties, and the first call to ngOnChanges.
      // Add 'implements OnInit' to the class.
   }

   ngAfterContentInit() {
      this.id = this.data['svgGanttId'] || 'svgGantt';
      this.initRender();
   }

   @HostListener('window:resize', ['$event']) getWindow(event) {
      this.id = this.data['svgGanttId'] || 'svgGantt';
      this.initRender();
   }

   initRender() {
      const width = document.getElementById('gantt-container').offsetWidth; // + (resize ? 0 : 5);
      this.xs = width <= 425;
      this.windowWidth = width; // < 698 ? 768: width;
      const ganttConfig = {
         svgGanttId: this.id,
         showTime: true,
         type: this.data.TypeGantt,
         width: this.ganttService.Canvas.width,
         height: this.ganttService.Canvas.height,
         timeStart: this.data.timeStart,
         timeEnd: this.data.timeEnd,
         ganttTopMin: this.data.Ranges.ganttTopMin,
         ganttTopMax: this.data.Ranges.ganttTopMax,
         ganttBottomMin: this.data.Ranges.ganttBottomMin,
         ganttBottomMax: this.data.Ranges.ganttBottomMax,
         ganttTopLabel: this.xs ? 'A [mm]' : 'ANCHO   [mm]',
         ganttBottomLabel: this.xs ? 'E [mm]' : 'ESPESOR  [mm]',
         barBottomLabel: 'DEMORAS',
         timeLabel: 'Turno 2',
         xRange: null
      };

      this.measure = this.ganttService.getMeasure(ganttConfig, this.xs);
      this.xOffset = this.measure.xOffset;
      this.yOffset = this.measure.yOffset;
      this.chartWidth = this.windowWidth - this.xOffset;
      this.yAxisSize = this.ganttService.getYAxisSize(ganttConfig.height);
      this.dataNames = this.ganttService.DataNames;

      const d3 = this.d3;
      let d3ParentElement: Selection<HTMLElement, any, null, undefined>;
      let d3Svg: Selection<SVGSVGElement, any, null, undefined>;

      this.clearSvg(ganttConfig.svgGanttId);
      if (this.parentNativeElement !== null) {

         d3ParentElement = d3.select(this.parentNativeElement); // <-- use the D3 select method
         d3Svg = this.d3Svg = d3ParentElement.select<SVGSVGElement>('svg');

         const timeStartParsed = new Date(ganttConfig.timeStart);
         const timeEndParsed = new Date(ganttConfig.timeEnd);

         // Do more D3 things
         ganttConfig.xRange = this.d3.scaleTime()
            .range([0, this.windowWidth - this.xOffset])
            .domain([timeStartParsed, timeEndParsed]);

         this.y0 = this.d3.scaleLinear()
            .range([this.yAxisSize, 0])
            .domain([ganttConfig.ganttTopMin, ganttConfig.ganttTopMax]);

         this.y1 = this.d3.scaleLinear()
            .range([0, this.yAxisSize])
            .domain([ganttConfig.ganttBottomMin, ganttConfig.ganttBottomMax]);

         // var xAxis = this.d3.axisBottom(ganttConfig.xRange)
         //     .ticks(this.d3.timeHour, 1)
         //     .tickFormat(this.d3.timeFormat(this.ganttService.TimeFormat.hour));

         // var yAxisTop = this.d3.axisLeft(y0)
         //     .tickValues([ganttConfig.ganttTopMin, ganttConfig.ganttTopMax]);

         // var yAxisBottom = this.d3.axisLeft(y1)
         //     .tickValues([ganttConfig.ganttBottomMin, ganttConfig.ganttBottomMax]);

         this.d3Svg.attr('width', this.windowWidth)
            .attr('height', this.ganttService.Canvas.height)
            .append('g').attr('transform', 'translate(0, 0)');

         this.factorHeightTop = this.yAxisSize / ganttConfig.ganttTopMax;
         this.factorHeightBottom = this.yAxisSize / ganttConfig.ganttBottomMax;

         // var s = moment(ganttConfig.timeStart);
         // var e = moment(ganttConfig.timeEnd);
         // var total = e.diff(s);

         this.factorWidth = (this.windowWidth - this.xOffset); // (this.windowWidth - this.xOffset) / total;

         this.ganttConfig = ganttConfig;

         // // SteelCoils
         const ganttData = this.data[this.dataNames.GanttDataName];
         this.renderSteelCoils(ganttData);

         // //Delays
         // var barBottomData = this.data[this.dataNames.BarBottomDataName];
         // this.renderDelays(barBottomData);

         // //Defects
         const xMarksData = this.data[this.dataNames.XMarkDataName];
         this.renderDefects(xMarksData);

         // //Schedules
         const barTopData = this.data[this.dataNames.BarTopDataName];
         this.renderSchedules(barTopData);

         // if(!this.ganttConfig.chartTile && this.ganttConfig.type == this.ganttService.Type.production) {
         //     this.d3Svg.append("g")
         //         .attr("class", "x axisX")
         //         .attr("transform", "translate(" + this.xOffset + ", 0)")
         //         .call(xAxis);
         //     this.d3Svg.selectAll(".axisX text").attr("dy", 1);
         // }

         // Limits
         this.renderLimitsY();

         // Lines
         this.renderLinesLimits();

         // Titles
         this.renderTitles();

         // Tooltip
         this.d3.select('body')
            .append('div')
            .attr('id', 'tooltip-' + this.id)
            .attr('class', 'ganttTooltip')
            .style('opacity', 0);
      }
   }

   clearSvg(svgId) {
      const svg = this.d3.select('#' + svgId);
      if (svg) {
         svg.selectAll('*').remove();
      }
   }

   parseDate(date, format?) {
      if (!format) {
         format = this.ganttService.DateFormat.yearMonthDayHourMinuteSecond;
      }

      return this.d3.timeParse(format)(date);
      // return moment(date).format(format);
   }

   formatTime(time, format) {
      if (!format) {
         format = this.ganttService.TimeFormat.hourMinuteSecond;
      }

      return this.d3.timeParse(format)(time);
   }

   renderSteelCoils(data: Object[]) {
      const renderConfig = {
         height: this.ganttConfig.height * this.ganttService.yAxisBottomFactor,
         width: this.ganttService.Type.scheVsReal === this.data.TypeGantt && this.factorWidth / data.length >= 50 ? 50 : (this.factorWidth / data.length).toFixed(2)
      };
      this.ganttConfig.widthMaterial = renderConfig.width;
      this.renderGanttTop(renderConfig, data);
   }

   renderGanttTop(config: any, data: any[]) {
      data.forEach((d, i) => {
         d.rWidth = config.width; // d.durationMs * this.factorWidth;
         // d.rHeightTop = +(d.TopValue * this.factorHeightTop).toFixed(2);
         // d.rHeightBottom = +(d.BottomValue * this.factorHeightBottom).toFixed(2);
      });

      const ganttTop = this.d3Svg.append('g').attr('id', 'ganttTop');
      ganttTop.selectAll('.ganttTop')
         .data(data)
         .enter()
         .append('rect')
         .attr('class', (d) => {
            return this.ganttService.getGanttTopClass(this.ganttConfig.type, d);
         })
         .attr('id', (d) => {
            return 'gt-' + this.id + '-' + d.RowId;
         })
         .attr('x', (d: any, i) => {
            // d.StartTime = this.ganttService.narrowValue(this.timeStartParsed, this.timeEndParsed, this.parseDate(d.StartTime));
            // d.EndTime = this.ganttService.narrowValue(this.timeStartParsed, this.timeEndParsed, this.parseDate(d.EndTime));
            // d.StartTimeX = this.ganttConfig.xRange(d.StartTime);
            // d.EndTimeX = this.ganttConfig.xRange(d.EndTime);
            d.x = this.xOffset + (config.width * i);
            return d.x;
         })
         .attr('width', (d: any) => {
            return config.width;
         })
         .attr('y', (d: any) => {
            d.y = config.height - (this.yAxisSize - this.y0(d.TopValue));
            return d.y;
         })
         .attr('height', (d) => {
            return this.yAxisSize - this.y0(d.TopValue);
         })
         .on('mouseover', (d) => {
            this.ganttService.ganttOver(this.d3, this.ganttConfig, d);
         })
         .on('mouseout', (d) => {
            this.ganttService.ganttOut(this.d3, this.ganttConfig, d);
         });

      const ganttBottom = this.d3Svg.append('g').attr('id', 'ganttBottom');
      ganttBottom.selectAll('.ganttBottom')
         .data(data)
         .enter()
         .append('rect')
         .attr('id', (d) => {
            return 'gb-' + this.id + '-' + d.RowId;
         })
         .attr('class', 'ganttBottom')
         .attr('x', (d, i) => {
            return this.xOffset + (i * config.width);
         })
         .attr('width', (d) => {
            return config.width;
         })
         .attr('y', (d) => {
            return config.height;
         })
         .attr('height', (d) => {
            return this.y1(d.BottomValue);
         })
         .on('mouseover', (d) => {
            this.ganttService.ganttOver(this.d3, this.ganttConfig, d);
         })
         .on('mouseout', (d) => {
            this.ganttService.ganttOut(this.d3, this.ganttConfig, d);
         });

      const borderBase = this.d3Svg.append('g').attr('id', 'borderBase');
      borderBase.selectAll('.borderBase')
         .data(data)
         .enter()
         .append('rect')
         .attr('class', 'borderBase')
         .attr('x', (d, i) => {
            return this.xOffset + (i * config.width);
         })
         .attr('width', (d) => {
            return config.width;
         })
         .attr('y', (d) => {
            return config.height + this.y1(d.BottomValue);
         })
         .attr('height', 3);

      const borderTop = this.d3Svg.append('g').attr('id', 'borderTop');
      borderTop.selectAll('.borderTop')
         .data(data)
         .enter()
         .append('rect')
         .attr('class', 'borderTop')
         .attr('x', (d, i) => {
            return this.xOffset + (i * config.width);
         })
         .attr('width', (d) => {
            return config.width;
         })
         .attr('y', (d: any) => {
            return d.y;
         })
         .attr('height', 3);
   }

   renderDefects(data: any[]) {
      data = _.uniqBy(data, 'RowId');

      const attrsMark = {
         id: null,
         class: 'xMark',
         d: null
      };
      const y = this.ganttConfig.height * 0.77;
      data.forEach((d, i) => {
         this.ganttService.fixValueToLimits(d, this.ganttConfig);
         const x = +document.getElementById('gb-' + this.id + '-' + d.RowId).attributes.getNamedItem('x').value;
         const w = +document.getElementById('gb-' + this.id + '-' + d.RowId).attributes.getNamedItem('width').value;
         attrsMark.id = 'def-' + d.RowId;
         const x1 = x + (w - 5) / 2;
         const y1 = y;
         const x2 = x1 + 5;
         const y2 = y1 + 5;
         attrsMark.d = 'M ' + x1 + ',' + y1 + ' L ' + x2 + ',' + y2 + ' M ' + x1 + ',' + y2 + ' L ' + x2 + ',' + y1;
         this.d3Svg.append('path')
            .attrs(attrsMark)
            .on('mouseover', () => {
               this.ganttService.setTooltipOver(this.d3, this.ganttConfig.svgGanttId, d.Details);
            })
            .on('mouseout', () => {
               this.ganttService.setTooltipOut(this.d3, this.ganttConfig.svgGanttId);
            });
      });
   }

   renderSchedules(data: any[]) {
      const height = this.ganttConfig.height * 0.15;

      this.d3Svg.selectAll('.barTop')
         .data(data)
         .enter()
         .append('rect')
         .attr('class', 'barTop')
         .attr('x', (d, i) => {
            d['width'] = d.List ? this.ganttConfig.widthMaterial * d.List.length : this.factorWidth;
            d['x'] = data[i - 1] ? data[i - 1]['x'] + data[i - 1]['width'] : this.xOffset;
            return d['x'];
         })
         .attr('width', (d) => {
            return d['width'];
         })
         .attr('y', height)
         .attr('height', 17)
         .on('mouseover', (d) => {
            this.ganttService.setTooltipOver(this.d3, this.ganttConfig.svgGanttId, d.Details);
         })
         .on('mouseout', (d) => {
            this.ganttService.setTooltipOut(this.d3, this.ganttConfig.svgGanttId);
         });

      this.d3Svg.selectAll('.barTopText')
         .data(data)
         .enter()
         .append('text')
         .filter((d) => d['width'] > 50)
         .attr('class', 'barTopText')
         .attr('text-anchor', 'middle')
         .attr('x', (d) => {
            return d['x'] + (d['width'] - 45) / 2;
         })
         .attr('y', height + 13)
         .text((d) => {
            return d.RowId;
         })
         .on('mouseover', (d) => {
            this.ganttService.setTooltipOver(this.d3, this.ganttConfig.svgGanttId, d.Details);
         })
         .on('mouseout', (d) => {
            this.ganttService.setTooltipOut(this.d3, this.ganttConfig.svgGanttId);
         });
   }

   getArrowData(data: any[], measure: any): any[] {
      const newData = [];
      data.forEach((d, i) => {
         let arrow;
         // Gets values for X axis
         const xStart = d.attrs.x;
         const xEnd = d.attrs.x + d.attrs.width;

         // Determines if there is a gap between two top bar periods (a new start)
         let xWidthPrev = 0;
         let xStartPrevious = 0;
         if (i > 0) {
            xWidthPrev = data[i - 1].attrs.x + data[i - 1].attrs.width;
            xStartPrevious = data[i - 1].attrs.x;
         }

         const xEndPrevious = xWidthPrev;

         const diffPrev = xWidthPrev - xStartPrevious;

         // Size of a bar top item
         const diff = xEnd - xStart;
         let up = true;

         // Determines how the first arrow will be drawn and/or
         // when there is a gap between two top bar periods
         if (i === 0 || xEndPrevious !== xStart || (diffPrev > 0 && diffPrev < measure.minTimeTextWidth)) {
            // When there is enough space, the arrow will be drawn down together with the next one
            up = diff < 2 * measure.minTimeTextWidth;

            // When there is enough space to show only one arrow (the next one),
            // the first arrow will be displayed up
            if (diff > measure.minTimeTextWidth) {
               arrow = {
                  X: xStart - 100,
                  Time: moment(d.StartTime).format('HH:mm'),
                  Start: true,
                  Up: up
               };
               arrow.RowId = d.RowId;
               newData.push(arrow);
            }

         } // The arrow will beWhen there is enough space to show only one arrow (the next one)
         if (diff > measure.minTimeTextWidth) {
            arrow = {
               X: xEnd - 100,
               Time: moment(d.EndTime).format('HH:mm'),
               Start: false,
               Up: false
            };
            arrow.RowId = d.RowId;
            newData.push(arrow);
         }
      });

      return newData;
   }

   drawLine(x1, x2, y1, y2, classname) {
      this.d3Svg.append('line')
         .attr('x1', x1)
         .attr('y1', y1)
         .attr('x2', x2)
         .attr('y2', y2)
         .attr('class', classname);
   }

   drawText(classname, x, y, anchor, text) {
      this.d3Svg.append('text')
         .attr('class', classname)
         .attr('x', x)
         .attr('y', y)
         .attr('text-anchor', anchor)
         .text(text);
   }

   renderLimitsY() {
      const yTop = this.ganttConfig.height * 0.4;
      const yBottom = this.ganttConfig.height * this.ganttService.yAxisBottomFactor;

      this.drawText('y axisTopY', this.xOffset - 3, yTop + 3, 'none', this.ganttConfig.ganttTopMax);
      this.drawText('y axisTopY', this.xOffset - 3, yBottom - 3, 'none', this.ganttConfig.ganttTopMin);
      this.drawText('y axisBottomY', this.xOffset - 3, yBottom + 11, 'none', this.ganttConfig.ganttBottomMin);
      this.drawText('y axisBottomY', this.xOffset - 3, this.yAxisSize + yBottom + 3, 'none', this.ganttConfig.ganttBottomMax);
   }

   renderLinesLimits() {
      const yTop = this.ganttConfig.height * 0.4;
      const yBottom = this.ganttConfig.height * this.ganttService.yAxisBottomFactor;
      if (this.ganttConfig.showTime) {
         // Initial
         this.drawLine(this.xOffset, this.xOffset, this.yOffset, this.ganttConfig.height, 'smooth');
      }

      if (!this.ganttConfig.chartTitle) {
         this.drawLine(0, this.windowWidth, this.yOffset, this.yOffset, 'smooth');
      }

      this.drawLine(0, this.windowWidth, yBottom, yBottom, 'smooth');
      this.drawLine(this.xOffset, this.windowWidth, yTop, yTop, 'dotted');
      this.drawLine(this.xOffset, this.windowWidth, this.yAxisSize + yBottom, this.yAxisSize + yBottom, 'dotted');
   }

   renderTitles() {
      const yTop = this.ganttConfig.height * 0.4;
      const yBottom = this.ganttConfig.height * this.ganttService.yAxisBottomFactor;
      let x, y, text, anchor;
      x = this.measure.xOffset + (this.windowWidth / 2);
      y = this.yOffset + this.windowWidth * 0.01;
      if (this.ganttConfig.svgGanttId === 'svgGanttProg') {
         text = this.xs ? 'P' : 'Programa';
      } else if (this.ganttConfig.svgGanttId === 'svgGanttReal') {
         text = this.xs ? 'R' : 'Real';
      } else {
         text = this.ganttConfig.type === this.ganttService.Type.production ? this.ganttConfig.timeLabel : (this.xs ? 'P' : 'Programa');
      }

      anchor = 'middle';

      // x = this.measure.xOffset + (this.windowWidth / 2);
      // y = this.yOffset + this.windowWidth * 0.01;
      // text = this.ganttConfig.chartTitle;
      // anchor = "middle";

      // this.drawText("mainTitle", x, y, anchor, text);

      x = this.measure.timeLabelXOffset;
      y = this.ganttConfig.height * 0.25;
      text = text;
      anchor = this.measure.xLabelAlignment;

      this.drawText('leftTitle', x, y, anchor, text);

      x = this.measure.topLabelXOffset;
      y = this.ganttConfig.height * 0.52;
      text = this.ganttConfig.ganttTopLabel;
      anchor = this.measure.yLabelAlignment;

      this.drawText('labelTopAxisY', x, y, anchor, text);

      x = this.measure.topLabelXOffset;
      y = this.ganttConfig.height * 0.8;
      text = this.ganttConfig.ganttBottomLabel;
      anchor = this.measure.yLabelAlignment;

      this.drawText('labelBottomAxisY', x, y, anchor, text);

      // x = 8;
      // y = this.ganttConfig.height * 0.95;
      // text = this.ganttConfig.barBottomLabel;
      // anchor = "none";

      // this.drawText("labelBarBottom", x, y, anchor, text);
   }

}
