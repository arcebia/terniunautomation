import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
   selector: 'toggle',
   templateUrl: './toggle.component.html'
})

export class ToggleComponent implements OnInit {
   @Input() icon: string;
   @Input() toggle: boolean;
   @Input() disabled: boolean;
   @Input() state: string;
   @Input() isWhite = false;
   @Input() animated = true;
   @Output() change: EventEmitter<any> = new EventEmitter();

   ngOnInit(): void {

   }

   toggleChange(event) {
      if (this.disabled) { return; }
      this.toggle = !this.toggle;
      this.change.emit(this.toggle);
   }

}
