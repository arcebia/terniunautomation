import { Component, OnInit, OnChanges, Input, SimpleChanges, ViewChild, EventEmitter, Output } from '@angular/core';

import { NgbDropdown } from '@ng-bootstrap/ng-bootstrap';
import * as _ from 'lodash';

@Component({
   selector: 'dropdown',
   templateUrl: './dropdown.component.html'
})
export class DropdownComponent implements OnInit, OnChanges {
   @Input() config: any;
   @Input() selection: any;
   @Input() error: boolean;
   @Input() disabled: boolean;
   @Input() allSelections = false;
   @Input() height: any;
   @Output() change = new EventEmitter();
   filter: string;

   @ViewChild(NgbDropdown) dropdown: NgbDropdown;
   ngOnInit(): void {
      if (this.config) {
         if (!this.config.classesBtn) {
            this.config.classesBtn = 'btn-default';
         }
         if (this.config.withCaret === undefined) {
            this.config.withCaret = true;
         }
         if (this.config.multiple && !this.selection) {
            this.selection = [];
         }
         if (!this.config.multiple && !this.selection) {
            this.selection = {};
         }
         if (this.config.withCaret === undefined) {
            this.config.withCaret = true;
         }
         if (_.isEmpty(_.get(this.config, 'classes', ''))) {
            this.config.classes = 'full-width';
         }
      }
   }

   ngOnChanges(changes: SimpleChanges) {
      // Called before any other lifecycle hook. Use it to inject dependencies, but avoid any serious work here.
      // Add 'implements OnChanges' to the class.
      if (changes.selection && changes.selection.currentValue) {
         if (this.config.multiple) {
            _.each(changes.selection.currentValue, (o) => {
               const index = _.findIndex(this.config.list, (d) => {
                  return d[this.config.attribute] === o[this.config.attribute];
               });
               this.config.list[index].selected = true;
            });
         } else {
            const index = _.findIndex(this.config.list, (d) => {
               return d[this.config.attribute] === changes.selection.currentValue[this.config.attribute];
            });

            if (index >= 0) {
               this.config.list[index].selected = true;
            }
         }
      }
   }

   selectOption(item, $event) {
      item.selected = !item.selected;
      if (this.config.multiple) {
         this.selection = _.filter(this.config.list, { selected: true });
      } else {
         _.each(this.config.list, (o) => {
            if (o[this.config.attribute] !== item[this.config.attribute]) {
               o.selected = false;
            }
         });
         this.selection = item;
         this.dropdown.close();
      }
      this.change.emit(this.selection);
   }

}
