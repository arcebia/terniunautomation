import {
   Component,
   OnInit,
   Input,
   OnChanges,
   SimpleChanges,
   HostListener,
   ViewChild,
   ElementRef,
   AfterViewInit,
   Renderer2,
   DoCheck,
   EventEmitter,
   Output,
   QueryList,
   ViewChildren,
} from '@angular/core';

import { combineLatest, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';

import { D3, D3Service } from 'd3-ng2-service';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import * as _ from 'lodash';

import { SharedService } from 'src/app/services/shared.service';
import { ModalTableCustomizerComponent } from './modal-table-customizer.component';

interface ITableConfig {
   headersType?: string;
   headersPosition?: string;
   hasGantt?: boolean;
   minRows?: number;
   rowsToShow?: number;
   rowPositionColumn?: boolean;
   caption?: boolean;
   goToCurrent?: boolean;
}

@Component({
   selector: 'custom-table',
   templateUrl: 'custom-table.component.html',
   styleUrls: ['custom-table.component.css'],
})
export class CustomTableComponent implements OnInit, OnChanges, AfterViewInit, DoCheck {

   @Input() columns: any;
   @Input() data: any;
   @Input() config: ITableConfig = {};
   @Input() showFilters: boolean;
   @Input() showStatistics: boolean;
   @Input() filter: any;
   @Input() statistics: any;
   @Input() selectableColumns: any;
   @Input() itemSearched: any;
   @Input() userConfig: any;
   @Output() change = new EventEmitter();
   @Output() columnsEmitter: EventEmitter<any> = new EventEmitter();

   @ViewChild('mainContainer') mainContainer: ElementRef; // Referencia al contenedor de la tabla principal
   @ViewChild('fixedDataContainer') fixedDataContainer: ElementRef; // Referencia al contenedor de los datos del lado fixed
   @ViewChild('scrolleableDataContainer') scrolleableDataContainer: ElementRef; // Referencia al contenedor de los datos del lado scrolleable
   @ViewChild('scrolleableHeadersContainer') scrolleableHeadersContainer: ElementRef; // Referencia a los headers scrolleables
   @ViewChild('fixedHeadersContainer') fixedHeadersContainer: ElementRef; // Referencia a los headers scrolleables
   @ViewChild('headersRowContainer') headersRowContainer: ElementRef; // Referencia al contenedor de todos los headers
   @ViewChild('scrollbarHeader') scrollbarHeader: ElementRef; // Referencia al th sobre el scroll vertical
   @ViewChild('scrolleableStatisticsDataContainer') scrolleableStatisticsDataContainer: ElementRef; // Referencia al contenedor de los datos del lado scrolleable de la tabla de estadisticas
   @ViewChild('reorderModal') reorderModal: ElementRef;


   @ViewChildren('fixedDataRows') fixedDataRows: QueryList<ElementRef>; // Array de referencias a filas de datos del lado fixed
   @ViewChildren('scrolleableDataRows') scrolleableDataRows: QueryList<ElementRef>; // Array de referencias a filas de datos del lado scrolleable

   @ViewChildren('topHeaders') topHeaders: QueryList<ElementRef>; // Array de referencias a los headers de lvl 1
   @ViewChildren('nestedHeaders') nestedHeaders: QueryList<ElementRef>; // Array de referencias a los headers de lvl > 1

   @ViewChildren('dataRows') dataRows: QueryList<ElementRef>; // Array de referencia a los renglones de datos (en simplenotFixed)

   tableType = 'simplefixed';

   showTable = false;
   isIEorEdge = false;

   d3: D3;

   // Columns
   fixedColumns: any;
   scrolleableColumns: any;
   fixedColumnsData: any = [];
   scrolleableColumnsData: any = [];
   originalColumns: any;

   // Rows
   dataCellHeight = 28;
   minCellsToShow = 5;

   // Render and dimensions
   windowHeight: number;
   fixedSideColumnsWidth: number;
   scrolleableSideColumnsWidth: number;
   totalColumnsWidth: number;
   topDistance: number;
   headersRowHeight: number;
   dataContentHeight: number;
   dataContentTotalHeight: number;
   dataContentMinHeight: number;
   rowPositionHeaderHeight: number;
   rowPositionHeaderDynamicHeight: number;
   finalHeadersHeight: number;
   headersWithoutChildsHeight: number;
   maxLvl = 0;
   initialDraw = true;

   // Virtual Scroll
   viewportData: any[] = [];
   initIndex = 0;
   offset = 60;
   buffer = 7;
   lastIndex: number;
   lastVerticalScrollPosition = 0;
   requiresUpdatingViewportData = true;
   hasVerticalScroll: boolean;
   hasHorizontalScroll: boolean;

   // Filters por columnas
   filteredData = [];
   searchObjArray: any[];
   hasFiltersResult = false;

   // Columna de posicion de fila
   showRowPositionColumn: any;
   rowPositionColumnWidth: number;

   // Columnas Visibles
   hasSelectableColumns: boolean;

   // Columnas del usuario
   userConfigColumns: any;

   // Solo en dynamic table mode
   isArray: boolean;
   showGoToCurrentIcon: any;

   // Filtro general de la tabla
   filterTerms = new Subject<string>();
   hasFiltersTableResult = false;
   filteredTableData: any;

   afterViewInitCalled = false;

   constructor(
      public sharedService: SharedService,
      private renderer: Renderer2,
      private modalService: NgbModal,
      d3Service: D3Service
   ) {
      this.d3 = d3Service.getD3();

      this.filterTerms.pipe(debounceTime(500), distinctUntilChanged()).subscribe((terms: string) => this.filterTable(terms));
   }

   customizerTableModalHandler() {

      const ngbModalOptions: NgbModalOptions = {
         backdrop: 'static',
         keyboard: false,
         windowClass: 'modal-dimensions'
      };

      let fixedColumnsModal: any;
      let scrolleableColumnsModal: any;

      // Nuevo objeto de columnas, de esta manera no comparten la referencia
      if (this.config.headersPosition === 'notFixed') {
         scrolleableColumnsModal = _.cloneDeep(this.columns);
      } else {
         fixedColumnsModal = _.cloneDeep(this.fixedColumns);
         scrolleableColumnsModal = _.cloneDeep(this.scrolleableColumns);
      }

      // Inputs que recibe el modal
      const modalRef = this.modalService.open(ModalTableCustomizerComponent, ngbModalOptions);
      modalRef.componentInstance.fixedColumns = fixedColumnsModal;
      modalRef.componentInstance.scrolleableColumns = scrolleableColumnsModal;
      modalRef.componentInstance.idLine = this.userConfig.idLine;
      modalRef.componentInstance.idReport = this.userConfig.idReport;
      modalRef.componentInstance.username = this.userConfig.username;
      modalRef.componentInstance.headersPosition = this.config.headersPosition;
      modalRef.componentInstance.headersType = this.config.headersType;

      // Outputs que emite el modal, los 4 EventEmitter se combinan en un solo observable
      // tslint:disable-next-line: deprecation
      const combinedEmitters = combineLatest(
         modalRef.componentInstance.fixedColumnsEmitter,
         modalRef.componentInstance.scrolleableColumnsEmitter,
         modalRef.componentInstance.columnsEmitter,
         modalRef.componentInstance.resetConfigEmitter,
         (fixedColumns: any, scrolleableColumns: any, columns: any, resetConfig: boolean) => {
            return {
               fixedColumns,
               scrolleableColumns,
               columns,
               resetConfig
            };
         });

      // Pequeño debounce para evitar multiples call en un solo cambio
      const debouncedCombinedEmitters = combinedEmitters.pipe(debounceTime(50));

      // Subscripcion al observable de todos los emitters
      debouncedCombinedEmitters.subscribe(async (dataFromModal: any) => {

         // Las columnas que envia el modal la tabla a su vez se las envia al reporte
         this.columnsEmitter.emit(dataFromModal.columns);

         // Si elige volver a la configuración predeterminada de la tabla
         if (dataFromModal.resetConfig) {

            this.columns = [];
            this.fixedColumns = [];
            this.scrolleableColumns = [];
            this.fixedColumnsData = [];
            this.scrolleableColumnsData = [];

            this.columns = _.cloneDeep(this.originalColumns);

            this.onInitSequence();

            setTimeout(() => {
               if (this.afterViewInitCalled) {
                  this.setRelevantDimensions();
                  this.drawTable();
               }
            }, 0);

         } else {

            if (dataFromModal.fixedColumns) {
               this.fixedColumns = [];
               this.fixedColumns = _.cloneDeep(dataFromModal.fixedColumns);

               this.fixedColumnsData = [];
               this.setColumnsHeaders('fixed');

               setTimeout(() => {
                  if (this.afterViewInitCalled) {
                     this.setRelevantDimensions();
                     this.drawTable();
                  }
               }, 0);
            }

            if (dataFromModal.scrolleableColumns) {

               if (this.config.headersPosition === 'notFixed') {
                  const userColumns = _.cloneDeep(dataFromModal.scrolleableColumns);

                  this.mergeColumnsProperties(userColumns, this.columns);

                  this.columns = userColumns;

                  setTimeout(() => {
                     if (this.afterViewInitCalled) {
                        this.setRelevantDimensions();
                        this.drawTable();
                     }
                  }, 0);

               } else {
                  this.scrolleableColumns = [];
                  this.scrolleableColumns = _.cloneDeep(dataFromModal.scrolleableColumns);

                  this.scrolleableColumnsData = [];
                  this.setColumnsHeaders('scrolleable');

                  setTimeout(() => {
                     if (this.afterViewInitCalled) {
                        this.setRelevantDimensions();
                        this.drawTable();
                     }
                  }, 0);

               }
            }
         }
      });
   }

   /**
    * Mergea las properties faltantes en el objeto de columnas del usuario
    */
   mergeColumnsProperties(userColumns: any[], defaultColumns: any[]) {

      userColumns.forEach((userColumn: any, index: number) => {

         if (userColumn.id_column) {

            const defaultColumn = defaultColumns.find((column: any) => column.id_column === userColumn.id_column);
            userColumns[index] = Object.assign({}, defaultColumn, userColumn);

            if (userColumn.child_columns && userColumn.child_columns.length > 0) {
               this.mergeColumnsProperties(userColumn.child_columns, defaultColumn.child_columns);
            }

         } else {

            const columnResult = defaultColumns.find((column: any) => column.id_header === userColumn.id_header);
            userColumns[index] = Object.assign({}, columnResult, userColumn);

            if (userColumn.child_columns && userColumn.child_columns.length > 0) {
               this.mergeColumnsProperties(userColumn.child_columns, columnResult.child_columns);
            }
         }
      });
   }

   ngOnInit() {

      // if (this.config) console.log('Config', this.config);
      if (this.columns) console.log('Columns', this.columns);
      if (this.data) console.log('Data', this.data);
      // if (this.config.caption) console.log('Caption', this.config.caption);
      // if (this.selectableColumns) console.log('Selectable Columns', this.selectableColumns);
      // if (this.statistics) console.log('Statistics', this.statistics);
      // if (this.showStatistics) console.log('toggle Statistics', this.showStatistics);
      // if (this.userConfig) console.log('UserConfig', this.userConfig);

      this.showTable = false;

      this.isArray = _.isArray(this.data);

      /**
       * Obtiene en que browser se está ejecutando la aplicación
       */
      this.isIEorEdge = this.sharedService.isIEorEdge.getValue();
      /**
       * Detecta el modo que se usa la tabla cuando no se pasa
       * headersType ni headersPosition en el input config
       */
      if (this.config.headersPosition === undefined && this.config.headersType === undefined) {
         this.detectTableType();
      }

      /**
       * Setea la configuración que recibe
       * la tabla, arma tableType y minRows.
       */
      this.setConfig();
      /**
       * Valida si es necesario el virtual scroll
       * de acuerdo a la cantidad de datos que
       * recibe la tabla. Si necesita virtual scroll
       * setea la primera parte de viewportData.
       */
      this.initViewportData();
      /**
       * Copia las columnas originales que le pasa el reporte
       * sin referencia a objeto, por si reestablece la config
       */
      this.originalColumns = _.cloneDeep(this.columns);
      /**
       * Setea las columnas si el usuario tiene una configuración
       * propia de columnas
       */
      if (this.userConfig && this.userConfig.columns && this.userConfig.columns.length > 0) {
         this.userConfigColumns = _.cloneDeep(this.userConfig.columns);
         this.mergeColumnsProperties(this.userConfigColumns, this.columns);
         this.columns = this.userConfigColumns;
      }

      this.onInitSequence();
   }

   onInitSequence() {

      this.showTable = false;
      /**
       * Parsea a int la property width de cada column
       */
      this.setColumnsWidth();

      if (this.config.headersPosition === 'fixed') {
         /**
          * Setea Fixed y Scrolleable columns
          * en distintos arrays
          */
         this.separateColumnsByPosition();
      }

      if (this.config.headersType === 'multi') {
         /**
          * Setea los headers de ultimo nivel y el
          * nivel de cada header en el objeto
          */
         this.setColumnsHeaders('fixed');
         this.setColumnsHeaders('scrolleable');

         this.setHeaderLvl(this.fixedColumns);
         this.setHeaderLvl(this.scrolleableColumns);
      }

      this.setInitialDimesions();

      this.showTable = true;

   }

   statisticsRowHeaderWidthResolver(column: any) {
      const firstFixedColumnWidth = parseInt(column.width);
      if (this.showRowPositionColumn) {
         return firstFixedColumnWidth + 30;
      } else {
         return firstFixedColumnWidth;
      }
   }

   detectTableType() {
      let pinnedBreak = false;
      let childBreak = false;
      let headersType = 'simple';
      let headersPosition = 'notFixed';
      _.forEach(this.columns, (column: any) => {
         if (column.pinned === 'True') {
            pinnedBreak = true;
            headersPosition = 'fixed';
         }
         if (column.child_columns && column.child_columns.length > 0) {
            childBreak = true;
            headersType = 'multi';
         }
         if (pinnedBreak && childBreak) return false;
      });

      this.config.headersType = headersType;
      this.config.headersPosition = headersPosition;
   }

   setConfig() {
      if (this.config.minRows) this.minCellsToShow = this.config.minRows;
      if (this.config.headersType && this.config.headersPosition) this.tableType = this.config.headersType + this.config.headersPosition;
      if (this.config.rowPositionColumn !== undefined) {
         this.showRowPositionColumn = this.config.rowPositionColumn;
         if (!this.config.rowPositionColumn) {
            this.rowPositionColumnWidth = 0;
         } else {
            this.rowPositionColumnWidth = 30;
         }
      } else {
         this.showRowPositionColumn = false;
         this.rowPositionColumnWidth = 0;
      }
      if (this.selectableColumns !== undefined) {
         this.hasSelectableColumns = this.selectableColumns.enable;
      } else {
         this.hasSelectableColumns = false;
      }
   }

   initViewportData() {
      this.lastIndex = this.data.length - 1;

      if (this.lastIndex <= this.offset - 1 || this.config.goToCurrent || !this.isArray) {
         this.requiresUpdatingViewportData = false;
         this.viewportData = this.data;
      } else {
         this.viewportData = this.data.slice(this.initIndex, this.initIndex + this.offset);
      }
   }

   setColumnsWidth() {
      this.columns.forEach((column: any) => {
         column['width'] = parseInt(column['width']);
      });
   }

   separateColumnsByPosition() {
      this.fixedColumns = this.columns.filter((column: any) => {
         return column['pinned'] === 'True';
      });
      this.scrolleableColumns = this.columns.filter((column: any) => {
         return column['pinned'] === 'False';
      });
   }

   setHeaderLvl(columns: any[], lvl?: number) {
      if (columns && columns.length > 0) {
         columns.forEach((column: any) => {
            let currentLvl: number;
            lvl ? currentLvl = lvl + 1 : currentLvl = 1;
            if (currentLvl > this.maxLvl) this.maxLvl = currentLvl;
            column.level = currentLvl;
            if (column.child_columns && column.child_columns.length > 0) {
               this.setHeaderLvl(column.child_columns, currentLvl);
               column.height = 30;
            } else {
               column.height = 50;
            }
         });
      }
   }

   setColumnsHeaders(position?: string, columns?: any) {
      if (!columns) {
         switch (position) {
            case 'fixed':
               columns = this.fixedColumns;
               break;
            case 'scrolleable':
               columns = this.scrolleableColumns;
               break;
         }
      }

      for (const column of columns) {
         if (column.child_columns && column.child_columns.length > 0 && column.to_show) {
            this.setColumnsHeaders(position, column.child_columns);
         } else {
            this.additionalCfgResolverV2(column);
            switch (position) {
               case 'fixed':
                  this.fixedColumnsData.push(column);
                  break;

               case 'scrolleable':
                  this.scrolleableColumnsData.push(column);
                  break;
            }
         }
      }
   }

   additionalCfgResolverV2(column: any) {
      if (column && column.additional_cfg && column.additional_cfg !== '') {
         if (typeof column.additional_cfg === 'string' || column.additional_cfg instanceof String && column.additional_cfg !== '') {
            column.additional_cfg = JSON.parse(column.additional_cfg);
         }
      }
   }

   additionalCfgResolver(column: any) {
      if (column && column.additional_cfg && column.additional_cfg !== '') {
         if (typeof column.additional_cfg === 'string' || column.additional_cfg instanceof String && column.additional_cfg !== '') {
            return JSON.parse(column.additional_cfg);
         }
      } else {
         return false;
      }
   }

   hasHeaderGraph(column: any) {
      if (column.additional_cfg) {
         if (column.additional_cfg.headerGraph) {
            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   setInitialDimesions() {
      if (this.config.headersPosition === 'fixed') {
         this.fixedSideColumnsWidth = _.sumBy(this.fixedColumns, (column: any) => {
            if (column.to_show === 'True') return Number(column.width);
         });
         // Minima cantidad de filas a mostrar
         this.dataContentMinHeight = this.minCellsToShow * this.dataCellHeight + 17; // Tiene en cuenta el height del scroll
         // Total de filas de la tabla
         this.dataContentTotalHeight = this.data.length * this.dataCellHeight + 17; // Tiene en cuenta el height del scroll
      } else {
         if (this.isArray) {
            // Minima cantidad de filas a mostrar
            this.dataContentMinHeight = this.minCellsToShow * this.dataCellHeight;
            // Total de filas de la tabla
            this.dataContentTotalHeight = this.data.length * this.dataCellHeight;
         } else {
            // Minima y total cuando la data no es un array
            let multilvlCells = 0;
            let keys = 0;
            Object.keys(this.data).forEach((key: any) => {
               keys += 1;
               multilvlCells += this.data[key].length;
            });
            this.dataContentTotalHeight = (multilvlCells * 25) + keys;
            this.dataContentMinHeight = this.minCellsToShow * 25;
         }
      }
      if (this.tableType === 'simplenotFixed') {
         this.totalColumnsWidth = _.sumBy(this.columns, 'width');
         if (this.config.goToCurrent) this.showGoToCurrentIcon = this.data.some((item: any) => item.status_description === 'Actual');

         this.fixedSideColumnsWidth = 0;
      }
   }

   ngOnChanges(changes: SimpleChanges) {
      if (changes.showFilters) {
         this.hasFiltersResult = false;
         this.filteredData = [];
         this.searchObjArray = [];
      }
      if (changes.filter) {
         this.filterTerms.next(this.filter);
      }
      // if (changes.data) {
      //    this.initViewportData();
      // }
      if (this.afterViewInitCalled) {
         this.setRelevantDimensions();
         this.drawTable();
      }
   }

   /**
    * Primer dibujado de la tabla, recien aca se setean
    * los viewchild, antes de aqui son undefined
    */
   ngAfterViewInit() {
      setTimeout(() => {
         this.getDataRowHeight();
         this.setRelevantDimensions();
         if (this.config.headersType === 'multi') this.setChildlessTopHeadersHeight();
         this.drawTable();
         this.afterViewInitCalled = true;
      }, 0);
   }

   getDataRowHeight() {
      // if (this.tableType === 'simplenotFixed') {
      //    const dataRows = this.dataRows.toArray();
      //    const dataCellHeights = dataRows.map((dataRow: ElementRef) => dataRow.nativeElement.offsetHeight);
      //    const dataCellHeight = Math.max(...dataCellHeights);

      //    if (this.dataCellHeight !== dataCellHeight) {
      //       // Minima cantidad de filas a mostrar
      //       this.dataContentMinHeight = this.minCellsToShow * dataCellHeight + 1;
      //       // Total de filas de la tabla
      //       this.dataContentTotalHeight = this.data.length * dataCellHeight + 1;
      //    }
      // }

   }

   setChildlessTopHeadersHeight() {
      const topHeaders = this.topHeaders.toArray();
      const headersToSetHeight = topHeaders.filter((header: ElementRef) => header.nativeElement.dataset.childs === '0');
      headersToSetHeight.forEach((header: ElementRef) => {
         this.renderer.setStyle(header.nativeElement, 'height', `${(this.headersRowHeight).toString()}px`);
         this.renderer.setStyle(header.nativeElement, 'min-height', `${(this.headersRowHeight).toString()}px`);
         this.renderer.setStyle(header.nativeElement, 'max-height', `${(this.headersRowHeight).toString()}px`);
      });
   }

   /**
    * Detecta cambios en los tamaños de la UI, cuando se
    * agregan o quitan componentes por fuera de la tabla
    * o las dimensiones de la tabla cambian (activar filtros)
    */
   ngDoCheck() {
      if (this.afterViewInitCalled) {
         this.setRelevantDimensions();
         this.drawTable();
      }
   }

   /**
    * Detecta cambios en el tamaño de la ventana
    */
   @HostListener('window:resize', ['$event']) getWindowSize() {
      if (this.afterViewInitCalled) {
         this.setRelevantDimensions();
         this.drawTable();
      }
   }

   setRelevantDimensions() {

      const mainContainerElementRect = this.mainContainer.nativeElement.getBoundingClientRect();
      const parentContainerElement = this.mainContainer.nativeElement.parentNode.parentNode;
      const documentElement = document.documentElement;

      if (this.showRowPositionColumn && this.initialDraw) {
         this.rowPositionHeaderHeight = this.headersRowContainer.nativeElement.offsetHeight;
      }
      // 32px de mas si se activan los filtros
      if (this.showFilters) this.rowPositionHeaderDynamicHeight = this.rowPositionHeaderHeight + 32;
      if (!this.showFilters && !this.initialDraw) this.rowPositionHeaderDynamicHeight = this.rowPositionHeaderHeight;

      // Alto del Row que contiene los Headers
      if (this.headersRowContainer) {
         if (this.config.caption) {
            this.headersRowHeight = this.headersRowContainer.nativeElement.offsetHeight + 29; // Alto del caption
         } else {
            this.headersRowHeight = this.headersRowContainer.nativeElement.offsetHeight;
         }
      } else if (this.scrolleableHeadersContainer) {
         if (this.config.caption) {
            this.headersRowHeight = this.scrolleableHeadersContainer.nativeElement.offsetHeight + 29; // Alto del caption
         } else {
            this.headersRowHeight = this.scrolleableHeadersContainer.nativeElement.offsetHeight;
         }
      }

      const scrollWidth = this.scrolleableDataContainer.nativeElement.scrollWidth;
      const offsetWidth = this.scrolleableDataContainer.nativeElement.offsetWidth;

      (offsetWidth >= scrollWidth) ? this.hasHorizontalScroll = false : this.hasHorizontalScroll = true;

      // Alto Ventana
      this.windowHeight = window.innerHeight;

      // Desplazamiento vertical de la tabla en la pagina (distancia a la parte superior de la ventana)
      this.topDistance = mainContainerElementRect.top + (window.pageYOffset || documentElement.scrollTop || 0);

      if (this.fixedHeadersContainer) this.fixedSideColumnsWidth = this.fixedHeadersContainer.nativeElement.clientWidth;


      // // Valida que haya scroll horizontal
      // if (this.tableType === 'simplenotFixed') {
      //    if (this.hasVerticalScroll) {
      //       if (this.totalColumnsWidth + 17 > this.scrolleableSideColumnsWidth) {
      //          this.hasHorizontalScroll = true; // Aparece el scroll horizontal
      //       } else {
      //          this.hasHorizontalScroll = false; // Desaparece el scroll horizontal
      //       }
      //    } else {
      //       if (this.totalColumnsWidth > this.scrolleableSideColumnsWidth) {
      //          this.hasHorizontalScroll = true; // Aparece el scroll horizontal
      //       } else {
      //          this.hasHorizontalScroll = false; // Desaparece el scroll horizontal
      //       }
      //    }
      // }

      let currentScrolleableSideWidth: number;
      // Ancho de la parte scrolleable
      if (this.config.headersType === 'multi' && this.config.headersPosition === 'fixed') {
         currentScrolleableSideWidth = _.sumBy(this.scrolleableColumnsData, (column: any) => {
            if (column.to_show === 'True') return Number(column.width);
         });
      } else if (this.config.headersType === 'simple' && this.config.headersPosition === 'fixed') {
         currentScrolleableSideWidth = _.sumBy(this.scrolleableColumns, (column: any) => {
            if (column.to_show === 'True') return Number(column.width);
         });
      }

      if (currentScrolleableSideWidth && currentScrolleableSideWidth < (parentContainerElement.offsetWidth - this.fixedSideColumnsWidth - this.rowPositionColumnWidth)) {
         this.scrolleableSideColumnsWidth = currentScrolleableSideWidth + 18;
      } else {
         this.scrolleableSideColumnsWidth = parentContainerElement.offsetWidth - this.fixedSideColumnsWidth - this.rowPositionColumnWidth;
      }

      this.setDataContentHeight();
   }

   setDataContentHeight() {

      const scrollHeight = this.scrolleableDataContainer.nativeElement.scrollHeight;
      const offsetHeight = this.scrolleableDataContainer.nativeElement.offsetHeight;

      if (this.hasHorizontalScroll) {
         (scrollHeight + 17 > offsetHeight) ? this.hasVerticalScroll = true : this.hasVerticalScroll = false;
      } else {
         (scrollHeight > offsetHeight) ? this.hasVerticalScroll = true : this.hasVerticalScroll = false;
      }

      /**
       * availableDataContentHeight -> Altura DISPONIBLE
       * dataContentMinHeight       -> Altura MINIMA (La cantidad minima de rows a mostrar (28px c/row))
       * dataContentTotalHeight     -> Altura TOTAL (La altura correspondiente a todos los datos)
       */
      let availableDataContentHeight: number;
      if (this.config.rowsToShow) {
         availableDataContentHeight = this.config.rowsToShow * this.dataCellHeight;
      } else {
         if (this.showStatistics) {
            // 15 px de margen inferior, el mismo que el margen derecho
            availableDataContentHeight = this.windowHeight - this.topDistance - this.headersRowHeight - 15 - 110;
            if (this.hasHorizontalScroll) availableDataContentHeight -= 17; // 17px del scroll horizontal
         } else {
            availableDataContentHeight = this.windowHeight - this.topDistance - this.headersRowHeight - 15;
            if (this.hasHorizontalScroll) {
               availableDataContentHeight -= 17; // 17px del scroll horizontal
            }
         }
      }

      if (this.searchObjArray && (this.searchObjArray.length !== 0 && this.showFilters)) {
         const filteredDataContentTotalHeight = this.filteredData.length * this.dataCellHeight + 17;

         if (filteredDataContentTotalHeight <= this.dataContentMinHeight) {
            // Menos datos filtrados que el minimo espacio
            this.dataContentHeight = filteredDataContentTotalHeight + 1;
            // this.hasVerticalScroll = false;
         } else if (availableDataContentHeight <= this.dataContentMinHeight) {
            // Menos espacio disponible que el minimo
            this.dataContentHeight = this.dataContentMinHeight + 1;
            if (availableDataContentHeight === this.dataContentMinHeight) {
               // this.hasVerticalScroll = false;
            } else {
               // this.hasVerticalScroll = true;
            }
         } else if (filteredDataContentTotalHeight >= availableDataContentHeight) {
            // Mas datos filtrados que el espacio disponible
            this.dataContentHeight = availableDataContentHeight;
            if (availableDataContentHeight === this.dataContentTotalHeight) {
               // this.hasVerticalScroll = false;
            } else {
               // this.hasVerticalScroll = true;
            }
         } else if (availableDataContentHeight > filteredDataContentTotalHeight) {
            // Menos datos filtrados que el espacion disponible
            this.dataContentHeight = filteredDataContentTotalHeight + 1;
            // this.hasVerticalScroll = false;
         }
      } else {

         if (this.dataContentTotalHeight <= this.dataContentMinHeight) {
            // Menos datos que el minimo espacio
            this.dataContentHeight = this.dataContentTotalHeight + 1;
            // this.hasVerticalScroll = false;
         } else if (availableDataContentHeight <= this.dataContentMinHeight) {
            // Menos espacio disponible que el minimo
            this.dataContentHeight = this.dataContentMinHeight + 1;
            if (availableDataContentHeight === this.dataContentMinHeight) {
               // this.hasVerticalScroll = false;
            } else {
               // this.hasVerticalScroll = true;
            }
         } else if (this.dataContentTotalHeight >= availableDataContentHeight) {
            // Mas datos que el espacio disponible
            this.dataContentHeight = availableDataContentHeight;
            if (availableDataContentHeight === this.dataContentTotalHeight) {
               // this.hasVerticalScroll = false;
            } else {
               // this.hasVerticalScroll = true;
            }
         } else if (availableDataContentHeight > this.dataContentTotalHeight) {
            // Menos datos que el espacio disponible
            this.dataContentHeight = this.dataContentTotalHeight + 1;
            // this.hasVerticalScroll = false;
         }
      }

      if (this.hasHorizontalScroll && this.tableType === 'simplenotFixed') {
         this.dataContentHeight += 17;  // 17px del scroll horizontal
      }
   }

   drawTable() {

      if (this.mainContainer) {
         const mainContainerRef = this.mainContainer.nativeElement;

         this.renderer.setStyle(mainContainerRef, 'visibility', 'hidden');
      }

      if (this.headersRowContainer) {
         const headersRowContainerRef = this.headersRowContainer.nativeElement;

         this.renderer.setStyle(headersRowContainerRef, 'min-height', `${this.headersRowHeight.toString()}px`);
         this.renderer.setStyle(headersRowContainerRef, 'max-height', `${this.headersRowHeight.toString()}px`);
      }

      if (this.scrolleableHeadersContainer) {
         const scrolleableHeadersContainerRef = this.scrolleableHeadersContainer.nativeElement;

         this.renderer.setStyle(scrolleableHeadersContainerRef, 'width', `${this.scrolleableSideColumnsWidth.toString()}px`);
      }

      if (this.scrolleableDataContainer) {
         const scrolleableDataContainerRef = this.scrolleableDataContainer.nativeElement;

         this.renderer.setStyle(scrolleableDataContainerRef, 'width', `${this.scrolleableSideColumnsWidth.toString()}px`);
      }

      if (this.scrolleableStatisticsDataContainer) {
         const scrolleableStatisticsDataContainerRef = this.scrolleableStatisticsDataContainer.nativeElement;

         this.renderer.setStyle(scrolleableStatisticsDataContainerRef, 'width', `${this.scrolleableSideColumnsWidth.toString()}px`);
      }

      if (this.config.headersPosition === 'fixed' && this.fixedDataContainer && this.scrolleableDataContainer && this.mainContainer && this.dataContentHeight) {
         const mainContainerHeight = this.dataContentHeight + this.headersRowHeight;

         const fixedDataContainerRef = this.fixedDataContainer.nativeElement;
         const scrolleableDataContainerRef = this.scrolleableDataContainer.nativeElement;
         const mainContainerRef = this.mainContainer.nativeElement;

         this.renderer.setStyle(fixedDataContainerRef, 'height', `${this.dataContentHeight.toString()}px`);
         this.renderer.setStyle(fixedDataContainerRef, 'min-height', `${this.dataContentHeight.toString()}px`);
         this.renderer.setStyle(fixedDataContainerRef, 'max-height', `${this.dataContentHeight.toString()}px`);

         this.renderer.setStyle(scrolleableDataContainerRef, 'height', `${this.dataContentHeight.toString()}px`);
         this.renderer.setStyle(scrolleableDataContainerRef, 'min-height', `${this.dataContentHeight.toString()}px`);
         this.renderer.setStyle(scrolleableDataContainerRef, 'max-height', `${this.dataContentHeight.toString()}px`);

         this.renderer.setStyle(mainContainerRef, 'height', `${mainContainerHeight.toString()}px`);
         this.renderer.setStyle(mainContainerRef, 'min-height', `${mainContainerHeight.toString()}px`);
         this.renderer.setStyle(mainContainerRef, 'max-height', `${mainContainerHeight.toString()}px`);
      }

      if (this.config.headersPosition === 'notFixed' && this.scrolleableDataContainer && this.mainContainer && this.dataContentHeight) {
         const mainContainerHeight = this.dataContentHeight + this.headersRowHeight;

         const scrolleableDataContainerRef = this.scrolleableDataContainer.nativeElement;
         const mainContainerRef = this.mainContainer.nativeElement;

         this.renderer.setStyle(scrolleableDataContainerRef, 'height', `${this.dataContentHeight.toString()}px`);
         this.renderer.setStyle(scrolleableDataContainerRef, 'min-height', `${this.dataContentHeight.toString()}px`);
         this.renderer.setStyle(scrolleableDataContainerRef, 'max-height', `${this.dataContentHeight.toString()}px`);

         this.renderer.setStyle(mainContainerRef, 'height', `${mainContainerHeight.toString()}px`);
         this.renderer.setStyle(mainContainerRef, 'min-height', `${mainContainerHeight.toString()}px`);
         this.renderer.setStyle(mainContainerRef, 'max-height', `${mainContainerHeight.toString()}px`);
      }

      if (this.nestedHeaders && this.initialDraw) {
         this.headersWithoutChildsHeight = this.headersRowHeight - 1;
         const nestedHeaders = this.nestedHeaders.toArray();
         this.finalHeadersHeight = this.headersRowHeight - (30 * (this.maxLvl - 1));
         const finalHeaders = nestedHeaders.filter((header: ElementRef) => header.nativeElement.dataset.finalheader === 'true');
         const intermediateHeaders = nestedHeaders.filter((header: ElementRef) => header.nativeElement.dataset.finalheader !== 'true');
         finalHeaders.forEach((header: ElementRef) => {
            const headerRef = header.nativeElement;
            const height = this.headersRowHeight - (30 * (parseInt(headerRef.dataset.lvl) - 1));

            this.renderer.setStyle(headerRef, 'height', `${height.toString()}px`);
            this.renderer.setStyle(headerRef, 'min-height', `${height.toString()}px`);
            this.renderer.setStyle(headerRef, 'max-height', `${height.toString()}px`);
         });
         intermediateHeaders.forEach((header: ElementRef) => {
            const headerRef = header.nativeElement;

            this.renderer.setStyle(headerRef, 'overflow', 'hidden');
            this.renderer.setStyle(headerRef, 'text-overflow', 'ellipsis');
            this.renderer.setStyle(headerRef, 'white-space', 'nowrap');
         });
         this.initialDraw = false;
      }

      if (this.mainContainer) {
         const mainContainerRef = this.mainContainer.nativeElement;

         this.renderer.setStyle(mainContainerRef, 'visibility', 'visible');
      }
   }

   onVerticalScroll(event: any) {

      const tracker: any = event.target;
      const verticalScrollPosition = tracker.scrollTop;
      const updateviewportDataScrollDown = tracker.scrollHeight - tracker.scrollTop <= tracker.clientHeight;
      const updateviewportDataScrollUp = tracker.scrollTop === 0;


      if (this.requiresUpdatingViewportData) {
         if (verticalScrollPosition >= this.lastVerticalScrollPosition) {
            // Scroll hacia abajo
            if (updateviewportDataScrollDown) {
               if (this.lastIndex <= this.initIndex + this.offset + this.buffer) {
                  this.viewportData = this.data.slice(this.lastIndex - this.offset);
                  this.initIndex = this.lastIndex - this.offset;
                  this.lastVerticalScrollPosition = verticalScrollPosition;
               } else {
                  this.viewportData = this.data.slice(this.initIndex + this.buffer, this.initIndex + this.offset + this.buffer);
                  this.initIndex += this.buffer;
                  this.lastVerticalScrollPosition = verticalScrollPosition;
               }
            }

         } else {
            // Scroll hacia arriba
            if (updateviewportDataScrollUp) {
               if (this.initIndex - this.buffer <= 0) {
                  this.viewportData = this.data.slice(0, this.offset);
                  this.initIndex = 0;
                  this.lastVerticalScrollPosition = 0;
               } else {
                  this.viewportData = this.data.slice(this.initIndex - this.buffer, this.initIndex + this.offset - this.buffer);
                  this.initIndex = this.initIndex - this.buffer;

                  this.lastVerticalScrollPosition = this.buffer * this.dataCellHeight;
                  setTimeout(() => {
                     event.target.scrollTop = this.buffer * this.dataCellHeight; // buffer = 7 rows 28px alto
                  }, 0);
               }
            }
         }
      }

      if (this.fixedDataContainer) this.fixedDataContainer.nativeElement.scrollTop = tracker.scrollTop;
   }

   onHorizontalScroll(event: any) {
      this.scrolleableHeadersContainer.nativeElement.scrollLeft = event.target.scrollLeft;
      if (this.scrolleableStatisticsDataContainer) {
         this.scrolleableStatisticsDataContainer.nativeElement.scrollLeft = event.target.scrollLeft;
      }
   }

   filterTable(terms: string) {
      this.filteredTableData = [];
      if (terms === '' || !terms) {
         this.hasFiltersTableResult = false;
         this.dataContentTotalHeight = this.data.length * this.dataCellHeight;
      } else {
         this.filteredTableData = this.data.filter((item: any) => {
            return Object.keys(item).some((key: any) => {
               return item[key].toString().toLowerCase().includes(terms.toLowerCase());
            });
         });

         this.dataContentTotalHeight = this.filteredTableData.length * this.dataCellHeight;
         this.hasFiltersTableResult = true;
      }
   }

   searchTermsReceived(searchTerms: string, column: any) {
      const searchObj = {
         column: column.alias_column,
         searchTerms: searchTerms
      };
      this.setSearchObjArray(searchObj);
   }

   setSearchObjArray(searchObj: any) {
      if (!this.searchObjArray || this.searchObjArray.length === 0) {
         this.searchObjArray = [];
         this.searchObjArray.push(searchObj);
      } else {
         const index = this.searchObjArray.findIndex(obj => obj.column === searchObj.column);
         if (index !== -1) {
            if (searchObj.searchTerms === '') {
               this.searchObjArray.splice(index, 1);
            } else {
               this.searchObjArray[index].searchTerms = searchObj.searchTerms;
            }
         } else {
            this.searchObjArray.push(searchObj);
         }
      }

      this.filterBySearchTerms();
   }

   filterBySearchTerms() {
      this.filteredData = [];
      if (this.searchObjArray.length !== 0) {
         this.searchObjArray.forEach((searchObj: any) => {
            if (this.filteredData.length === 0) {
               this.filteredData = this.data.filter((item: any) => {
                  return item[searchObj.column].toString().toLowerCase().includes(searchObj.searchTerms.toLowerCase());
               });
            } else {
               this.filteredData = this.filteredData.filter((item: any) => {
                  return item[searchObj.column].toString().toLowerCase().includes(searchObj.searchTerms.toLowerCase());
               });
            }
         });
         this.hasFiltersResult = true;
      } else {
         this.hasFiltersResult = false;
      }
   }

   truncateDecimals(value: string) {
      if (value.indexOf('.') > -1) {
         return Number(value).toFixed(2);
      } else {
         return value;
      }
   }

   mouseEnterHandler(i: string) {
      if (this.config.hasGantt) {
         const index = parseInt(i) + this.initIndex;
         const idData = '#gt-svgGantt-' + this.data[index].id_exit;
         const classList = this.d3.select(idData).attr('class') + ' rect-hover';
         this.d3.select(idData).attrs({
            class: classList
         });
      }
      if (this.config.headersPosition === 'fixed') {
         const scrolleableRowEntered = this.scrolleableDataRows.toArray()[i].nativeElement;
         const fixedDataRowEntered = this.fixedDataRows.toArray()[i].nativeElement;
         this.renderer.addClass(scrolleableRowEntered, 'highlight-row');
         this.renderer.addClass(fixedDataRowEntered, 'highlight-row');
      }
   }

   mouseLeaveHandler(i: string) {
      if (this.config.hasGantt) {
         const index = parseInt(i) + this.initIndex;
         const idData = '#gt-svgGantt-' + this.data[index].id_exit;
         const classList = this.d3.select(idData).attr('class').split(' rect-hover').join(' ');
         this.d3.select(idData).attrs({
            class: classList
         });
      }
      if (this.config.headersPosition === 'fixed') {
         const scrolleableRowLeft = this.scrolleableDataRows.toArray()[i].nativeElement;
         const fixedDataRowLeft = this.fixedDataRows.toArray()[i].nativeElement;
         this.renderer.removeClass(scrolleableRowLeft, 'highlight-row');
         this.renderer.removeClass(fixedDataRowLeft, 'highlight-row');
      }
   }

   highlightSearchResultCell(item: any) {
      if (this.itemSearched && this.itemSearched.nroColada && this.itemSearched.nroColada === item.nroColada) {
         return 'search-result-cell';
      }
   }

   cellClickEmiter(column: any, item?: any) {
      this.change.emit({ column: column, data: item });
   }

   columnHandler(column: any, item: any, check?: any) {
      this.change.emit({
         column: column,
         data: item,
         // scroll: this.scrollnumber
      });

      if (column && column.is_selectable && !_.isUndefined(check)) {
         if (!item) {
            _.each(this.viewportData, (o) => {
               o.selected = check;
            });
         } else {
            // item.selected === '0' ? item.selected = true : item.selected = false;
            item.selected = !item.selected;
         }
      }

      // if (!item && this.sort && column && !column.is_selectable) {
      //    _.each(this.columns, (o) => {
      //       if (column.alias_column !== o.alias_column) o.sort = null;
      //    });
      //    if (column.sort == null) {
      //       column.sort = 'asc';
      //    } else if (column.sort === 'asc') {
      //       column.sort = 'desc';
      //    } else {
      //       column.sort = 'asc';
      //    }
      //    let data = this.columnsFilter.length === 0 ? this.data : this.dataPart;
      //    data = _.orderBy(data, [column.alias_column], [column.sort]);
      //    if (this.columnsFilter.length === 0) {
      //       this.data = data;
      //       this.updateList();
      //    } else {
      //       this.dataPart = data;
      //    }
      // }

   }

   sumSubColumnsWidths(column: any) {
      let width = 0;
      column.child_columns.forEach((child: any) => {
         if (child.child_columns && child.child_columns.length > 0) {
            width += this.sumSubColumnsWidths(child);
         } else {
            if (child.to_show === 'True') width += Number(child.width);
         }
      });
      return width;
   }

   headerWidthResolver(column: any) {
      let width = 0;
      if (column.child_columns && column.child_columns.length > 0) {
         width += this.sumSubColumnsWidths(column);
      } else {
         width = column.width;
      }

      // OJO ACA NO HACE EL getValue()
      if (this.sharedService.isIEorEdge) {
         return width - 0.5;
      } else {
         return width;
      }
   }

   colspanResolver(column: any) {
      if (column.child_columns.length > 0) {
         let visiblesChilds = 0;
         column.child_columns.forEach((child: any) => {
            if (child.to_show === 'True') visiblesChilds += 1;
         });

         return visiblesChilds;
      }
   }

   columnHeightResolver(column: any) {
      return (!(column.child_columns && column.child_columns.length > 0)) ? ((this.maxLvl - 1) * 30) + column.height : column.height;
   }

   headerHeightResolver(column: any) {
      if (column.level === this.maxLvl) {
         return this.finalHeadersHeight;
      } else {
         return this.finalHeadersHeight + ((this.maxLvl - column.level) * 30);
      }
   }

   columnConfigChange(event: any) {
      this.columns = event.columnsConfig.filter((column: any) => column.enable);
   }

   goToCurrentItem() {
      const rowHasToGoIndex = this.data.findIndex((item: any) => item.id_status === '2');
      this.scrolleableDataContainer.nativeElement.scrollTo({ top: rowHasToGoIndex * (this.dataCellHeight + 1), behavior: 'smooth' });
   }

   getClassNoTemplate(item: any, column: any) {
      return column.icon_class ? column.icon_class(item, column) : (column.custom_class && item[column.custom_class] ? item[column.custom_class] : (item.add_class && column.add_class ? item.icon_class : ''));
   }

   getClassEditable(item: any, column: any) {
      return column.icon_class ? column.icon_class(item, column) : column.custom_class && item[column.custom_class] ? item[column.custom_class] : '';
   }

   getIcon(item: any, column: any) {
      return column.icon_func ? column.icon_func(item, column) : column.icon;
   }

   getTextClass(item: any, column: any) {
      return column.text_class ? column.text_class(item, column) : column.custom_class && item[column.custom_class] ? item[column.custom_class] : (item.add_class && column.add_class ? item.class : '');
   }

   getTooltip(item: any, column: any) {
      if (item[column.tooltip_item_alias]) {
         return item[column.tooltip_item_alias];
      } else if (column.tooltip_func) {
         return column.tooltip_func(item);
      } else {
         return '';
      }
   }

   getClassColumn(column: any, item: any) {
      if (!item) {
         if (column.column_class) return column.column_class;
         // if (this.sort && column.sort == null) { // padding-sort
         //    return '';
         // } else {
         //    return 'sort-' + column.sort;
         // }
      } else {
         return column.sort != null ? 'bg-light-gray' : '';
      }
   }
}
