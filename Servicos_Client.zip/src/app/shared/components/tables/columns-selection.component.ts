import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as _ from 'lodash';

import { BaseService } from 'src/app/services/base.service';
import { SsiService } from 'src/app/services/ssi.service';
import { SharedService } from 'src/app/services/shared.service';
import { ModalColumnsSelectionComponent } from './modal-columns-selection.component';

@Component({
   selector: 'columns-selection',
   templateUrl: './columns-selection.component.html'
})

export class ColumnsSelectionComponent implements OnInit {
   @Input() icon: any;
   @Input() tooltip: any;
   @Input() reportCode: any;
   @Input() columnsConfig: any[];
   @Input() currentUser: any;
   @Input() reportUserConfig: any;
   @Output() change = new EventEmitter();
   idLine: any;

   constructor(
      private activatedRoute: ActivatedRoute,
      private modalService: NgbModal,
      public sharedService: SharedService,
      private ssiService: SsiService,
      private baseService: BaseService
   ) { }

   ngOnInit() {
      this.idLine = this.activatedRoute.snapshot.paramMap.get('id_line') || '1640001';
   }

   configMaterialView() {
      if (!this.currentUser) {
         this.currentUser = this.sharedService.currentUser;

         if (!this.currentUser) {
            this.ssiService.getCurrentUser().then((usr) => {
               this.currentUser = usr;
               this.sharedService.currentUser = usr;
            }
            );
         }
      }

      const modalRef = this.modalService.open(ModalColumnsSelectionComponent, {
         size: 'sm'
      });

      const firstRow = _.first(this.columnsConfig);

      // TODO: filtrar por los que tienen cabecera o tooltip
      // Ordenar por el mismo orden de produccion

      modalRef.componentInstance.materialInfo = this.columnsConfig;
      modalRef.result
         .then((result: any) => {
            // this.columnsConfig = result;
            const selectedInformation = _.filter(this.columnsConfig, (col: any) => col.enable === true);
            // SAVE USER SELECTION
            const params_info = {
               id_line: this.idLine,
               id_report: firstRow.id_report,
               username: this.currentUser.username,
               columns_config: JSON.stringify(_.map(selectedInformation, function (x) { return parseInt(x.id_column); })),
               report_config: ''
            };

            if (this.reportUserConfig.UserConfig && this.reportUserConfig.UserConfig.length > 0) {
               params_info.report_config = this.reportUserConfig.UserConfig.report_config || '';
            } else {
               if (this.reportUserConfig.DefaultConfig && this.reportUserConfig.DefaultConfig.length > 0) {
                  params_info.report_config = this.reportUserConfig.DefaultConfig.report_config || '';
               }
            }

            console.log(params_info);

            this.baseService.setReportUserConfig(params_info);

            if (this.change) {
               const data = {
                  columnsConfig: result
               };
               this.change.emit(data);
            }
         });
   }

}
