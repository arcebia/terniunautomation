import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

import { Subject } from 'rxjs/internal/Subject';
import { debounceTime } from 'rxjs/operators';

@Component({
   selector: 'column-filter',
   templateUrl: 'column-filter.component.html',
   styleUrls: ['column-filter.component.css']
})
export class ColumnFilterComponent implements OnInit {

   @Input() column: any;
   @Input() margin: any;
   @Output() searchTermsEmitter = new EventEmitter();

   searchTerms = '';
   searchTermsSubject = new Subject();

   constructor() { }

   ngOnInit() {
      this.searchTermsSubject
         .pipe(debounceTime(500))
         .subscribe((searchTerms: string) => {
            this.searchTermsEmitter.emit(searchTerms);
         });
   }

   onKeyUp() {
      this.searchTermsSubject.next(this.searchTerms);
   }

   hasText() {
      return this.searchTerms || this.searchTerms !== '';
   }
}
