import { Component, Input } from '@angular/core';
import * as _ from 'lodash';

@Component({
   selector: 'dynamic-template',
   templateUrl: './dynamic-template.component.html'
})


export class DynamicTemplateComponent {
   @Input() id: string;
   @Input() data: any;

   idTooltip: any;
   constructor() { }

}
