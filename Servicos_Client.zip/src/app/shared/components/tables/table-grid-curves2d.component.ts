import { Component, OnInit, Input, AfterContentInit } from '@angular/core';
import * as _ from 'lodash';

@Component({
   selector: 'table-grid-curves2d',
   templateUrl: './table-grid-curves2d.component.html'
})
export class TableGridCurves2dComponent implements OnInit, AfterContentInit {
   @Input() data: any;
   @Input() config: any;

   selectedAll = false;
   wWindow = 0;
   hWindow = 0;
   wHeader = 0;
   defaultCellWidth = 70;
   hContainer: any;
   valuesInTable: any = [];
   sum: any;
   wLeft: any;
   columns: any;

   tableId: any;

   ngOnInit() {
      const sbHeight = window.innerHeight * (window.innerHeight / document.body.offsetHeight);
      this.sum = (this.data[0].data.length + 1) * this.defaultCellWidth;
      this.tableId = 'table-content-grid-2d-for-' + this.config.id;
   }

   ngAfterContentInit() {
      this.hWindow = window.innerHeight;
      setTimeout(() => {
         this.wWindow = window.innerWidth - 100;
      }, 1110);

      this.setStyles();
   }

   setStyles(): void {
      this.wLeft = this.sum;
   }
   //
   toggleChange($event) {
      this.selectedAll = !this.selectedAll;
      _.each(this.data, (d) => {
         d.selected = this.selectedAll;
      });
   }
   getXAxisLabel(val) {
      if (this.config.xAxis.type === 'datetime') {
         const date = new Date(val);
         return date.getUTCHours() + ':' + date.getUTCMinutes() + ':' + date.getUTCSeconds();
      }
      return val.toFixed(2);
   }
}
