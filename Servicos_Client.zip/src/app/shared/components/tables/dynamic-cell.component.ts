import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { SharedService } from 'src/app/services/shared.service';
import { SemaphoreService } from 'src/app/services/semaphore.service';

@Component({
   selector: 'dynamic-cell',
   templateUrl: './dynamic-cell.component.html',
   encapsulation: ViewEncapsulation.None,
   styleUrls: ['./dynamic-cell.component.css']
})
export class DynamicCellComponent implements OnInit {

   @Input() item: any;
   @Input() column: any;
   @Input() scrollDiv: any;

   idLine: any;

   hasAdditionalCfg = false;
   columnWithAdditionalCfg: string;
   additionalCfg: any;
   additionalCfgClass: string;
   itemValue: any;

   semServiceRes: any;
   tooltipMsg = '';
   tooltipClass: string;

   elementId: string;
   elementToSetClass: any;

   showContextMenu = false;
   contextmenuX = 0;
   contextmenuY = 0;

   elementRef: any;

   images = {
      dictamen_A: 'http://pisodeplantaams.ternium.net/SIO_SHARED/Content/img/dictamen_A.gif',
      dictamen_D: 'http://pisodeplantaams.ternium.net/SIO_SHARED/Content/img/dictamen_D.gif',
      dictamen_P: 'http://pisodeplantaams.ternium.net/SIO_SHARED/Content/img/dictamen_P.gif',
      dictamen_R: 'http://pisodeplantaams.ternium.net/SIO_SHARED/Content/img/dictamen_R.gif',
      dictamen_S: 'http://pisodeplantaams.ternium.net/SIO_SHARED/Content/img/dictamen_S.gif',
      est_verde: 'http://pisodeplantaams.ternium.net/SIO_SHARED/Content/img/est_verde_p.gif',
      est_rojo: 'http://pisodeplantaams.ternium.net/SIO_SHARED/Content/img/est_rojo_p.gif',
   };

   constructor(
      private router: Router,
      private activatedRoute: ActivatedRoute,
      public sharedService: SharedService,
      public semaphoreService: SemaphoreService,
   ) { }

   ngOnInit() {

      if (this.column.additional_cfg && this.column.additional_cfg !== '') {

         this.additionalCfg = this.column.additional_cfg;

         // Tiene semáforo
         if (this.additionalCfg && this.additionalCfg.semaphore) {

            this.hasAdditionalCfg = true;
            this.handleSemaphore();
         }
      }
   }

   setElementId() {
      this.elementId = Math.random().toString(36).substring(7);
   }

   setClass(color: any) {
      setTimeout(() => {
         this.elementToSetClass = document.getElementById(this.elementId).parentElement.parentElement;
         switch (color) {
            case 'red':
               this.elementToSetClass.classList.add('red-info');
               break;

            case 'green':
               this.elementToSetClass.classList.add('green-info');
               break;

            case 'yellow':
               this.elementToSetClass.classList.add('yellow-info');
               break;

            default:
               break;
         }
      }, 0);
   }

   handleDataType(semaphore: any) {

      switch (semaphore.dataType) {
         case 'string':
            this.itemValue = this.item[this.columnWithAdditionalCfg];
            break;

         case 'number':
            this.itemValue = Number(this.item[this.columnWithAdditionalCfg]);
            break;

         case 'time':
            const timeArray = this.item[this.column.alias_column].split(':');
            const min = timeArray[0];
            const sec = timeArray[1];
            if (sec === '00') {
               this.itemValue = Number(min);
            } else {
               const secNumber = Number(sec) / 60;
               const minNumber = Number(min) + secNumber;
               this.itemValue = minNumber;
            }
            break;

         default:
            this.itemValue = Number(this.item[this.columnWithAdditionalCfg]);
            break;
      }
   }

   handleSemaphore() {

      this.columnWithAdditionalCfg = this.column.alias_column;
      this.setElementId();

      const semaphore = this.additionalCfg.semaphore;
      this.handleDataType(semaphore);

      switch (semaphore.type) {
         case '5':
            this.semServiceRes = this.semaphoreService.semaphoreType5(this.itemValue, semaphore.string);
            break;

         case '8':
            this.semServiceRes = this.semaphoreService.semaphoreType8(this.itemValue, this.additionalCfg.semaphore.lower);
            break;

         case '13':
            this.semServiceRes = this.semaphoreService.semaphoreType13(this.itemValue, Number(this.item[this.additionalCfg.semaphore.aliasColumnValue]), this.additionalCfg.semaphore.mode, this.additionalCfg.semaphore.externalLimit, this.additionalCfg.semaphore.internalLimit);
            break;

         default:
            break;
      }

      if (this.semServiceRes && this.semServiceRes.classInfo) this.setClass(this.semServiceRes.classInfo);
      if (this.semServiceRes && this.semServiceRes.tooltipMsg) this.tooltipMsg = this.semServiceRes.tooltipMsg;
      if (this.semServiceRes && this.semServiceRes.tooltipClass) this.tooltipClass = this.semServiceRes.tooltipClass;

      // Si es tipo time convierte los valores de tiempo a numeros para comparar
      // if (this.additionalCfg.limits.type && this.additionalCfg.limits.type === 'time') {
      //    const timeArray = this.item[this.columnWithAdditionalCfg].split(':');
      //    const min = timeArray[0];
      //    const sec = timeArray[1];
      //    if (sec === '00') {
      //       this.itemValue = Number(`${min}.${sec}`);
      //    } else {
      //       const secNumber = Number(sec) / 60;
      //       const minNumber = Number(min) + secNumber;
      //       this.itemValue = minNumber;
      //    }
      // } else {
      //    this.itemValue = Number(this.item[this.columnWithAdditionalCfg]);
      // }

      // /**
      //  * Checkeo de limites, todas las posibilidades
      //  */
      // if (
      //    (this.additionalCfg.limits.lower || this.additionalCfg.limits.lower === 0) ||
      //    (this.additionalCfg.limits.upper || this.additionalCfg.limits.upper === 0)
      // ) {
      //    /**
      //     * Con ambos limites (3 casos)
      //     */
      //    if (
      //       (this.additionalCfg.limits.lower || this.additionalCfg.limits.lower === 0) &&
      //       (this.additionalCfg.limits.upper || this.additionalCfg.limits.upper === 0)
      //    ) {
      //       /**
      //        * Dentro de los limites
      //        */
      //       if (
      //          (this.itemValue >= this.additionalCfg.limits.lower) &&
      //          (this.itemValue <= this.additionalCfg.limits.upper)
      //       ) {
      //          this.tooltipMsg = `Mayor a Límite Inferior: ${this.additionalCfg.limits.lower} Menor a Límite Superior: ${this.additionalCfg.limits.upper}`;
      //          this.tooltipClass = 'within-limits';
      //       }
      //       /**
      //        * Menor que el limite inferior (Fuera de limites)
      //        */
      //       if (this.itemValue < this.additionalCfg.limits.lower) {

      //          this.tooltipMsg = `Menor a Límite Inferior: ${this.additionalCfg.limits.lower} Límite Superior: ${this.additionalCfg.limits.upper}`;
      //          this.tooltipClass = 'out-limits';
      //          this.setClass('red');
      //       }
      //       /**
      //        * Mayor que el limite superior (Fuera de limites)
      //        */
      //       if (this.itemValue > this.additionalCfg.limits.upper) {

      //          this.tooltipMsg = `Mayor a Límite Superior: ${this.additionalCfg.limits.upper} Límite Inferior: ${this.additionalCfg.limits.lower}`;
      //          this.tooltipClass = 'out-limits';
      //          this.setClass('red');
      //       }

      //       return;
      //    }

      //    /**
      //     * Solo limite inferior (2 casos)
      //     */
      //    if (
      //       (this.additionalCfg.limits.lower || this.additionalCfg.limits.lower === 0) &&
      //       (!this.additionalCfg.limits.upper)
      //    ) {
      //       /**
      //        * Menor que el limite inferior (Fuera de limites)
      //        */
      //       if (this.itemValue < this.additionalCfg.limits.lower) {

      //          this.tooltipMsg = `Menor a Límite Inferior: ${this.additionalCfg.limits.lower} Sin Límite Superior`;
      //          this.tooltipClass = 'out-limits';
      //          this.setClass('red');
      //       }
      //       /**
      //        * Mayor que el limite inferior (Dentro de limites)
      //        */
      //       if (this.itemValue >= this.additionalCfg.limits.lower) {

      //          this.tooltipMsg = `Mayor a Límite Inferior: ${this.additionalCfg.limits.lower} Sin Límite Superior`;
      //          this.tooltipClass = 'within-limits';
      //       }

      //       return;
      //    }

      //    /**
      //     * Solo limite superior (2 casos)
      //     */
      //    if (
      //       (this.additionalCfg.limits.upper || this.additionalCfg.limits.upper === 0) &&
      //       (!this.additionalCfg.limits.lower)
      //    ) {
      //       /**
      //        * Mayor que el limite superior (Fuera de limites)
      //        */
      //       if (this.itemValue > this.additionalCfg.limits.upper) {

      //          this.tooltipMsg = `Mayor a Límite Superior: ${this.additionalCfg.limits.upper} Sin Límite Inferior`;
      //          this.tooltipClass = 'out-limits';
      //          this.setClass('red');
      //       }
      //       /**
      //        * Menor que el limite superior (Dentro de limites)
      //        */
      //       if (this.itemValue <= this.additionalCfg.limits.upper) {

      //          this.tooltipMsg = `Menor a Límite Superior: ${this.additionalCfg.limits.upper} Sin Límite Inferior`;
      //          this.tooltipClass = 'within-limits';
      //       }

      //       return;
      //    }
      // }

   }

   openHeatSheet() {
      window.open(`http://pisodeplantaams.ternium.net/SIO_MVC/reports/GanttHojaColada?idLine=${this.sharedService.selectedIdLine.getValue()}&c=${this.item.nroColada}`, '_blank');

   }

   onRightClick(event: any, column: any, item: any) {
      if (event.button === 2 && column.alias_column === 'exit_material') {

         const queryParams = {
            material: item.exit_material
         };
         const url = this.router.createUrlTree(['../material_detail'], { relativeTo: this.activatedRoute, queryParams });
         window.open(`#${this.router.serializeUrl(url)}`, '_blank');
      }

      // this.showContextMenu=true;
      // var extra = this.scrollDiv ?  this.scrollDiv : 0;
      // this.contextmenuX = event.screenX - 20;
      // this.contextmenuY = event.screenY - 300 + extra;
      // console.log(event.screenY);
      // console.log(this.scrollDiv);
      // console.log(this.contextmenuY);
   }

   // onMouseOver(){
   //     this.disableContextMenu();
   // }

   // openLash(event,column,item){
   //     console.log(event);
   //     if(event.button == 2 && column.alias_column == 'exit_material'){
   //         var url = this.$state.href('material', { id_line : item.id_line, material: item.exit_material});
   //         window.open(url);
   //     }
   //     this.disableContextMenu();
   // }

   // disableContextMenu(){
   //     this.showContextMenu = false;
   //  }
}

