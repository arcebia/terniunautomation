import { Component, OnInit, Input, OnDestroy, Output, EventEmitter, ChangeDetectorRef, AfterViewInit, AfterViewChecked, AfterContentInit, AfterContentChecked } from '@angular/core';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { DragulaService } from 'ng2-dragula';
import * as _ from 'lodash';

import { BaseService } from 'src/app/services/base.service';

@Component({
   selector: 'modal-table-customizer',
   templateUrl: 'modal-table-customizer.component.html',
   styleUrls: ['modal-table-customizer.component.css']
})
export class ModalTableCustomizerComponent implements OnInit, OnDestroy, AfterViewInit, AfterViewChecked, AfterContentInit, AfterContentChecked {

   @Input() fixedColumns: any[];
   @Input() scrolleableColumns: any[];
   @Input() idLine: any;
   @Input() idReport: any;
   @Input() username: any;
   @Input() headersPosition: any;
   @Input() headersType: any;
   @Output() fixedColumnsEmitter: EventEmitter<any> = new EventEmitter();
   @Output() scrolleableColumnsEmitter: EventEmitter<any> = new EventEmitter();
   @Output() columnsEmitter: EventEmitter<any> = new EventEmitter();
   @Output() resetConfigEmitter: EventEmitter<any> = new EventEmitter();


   fixedColumnsEditable: any[];
   scrolleableColumnsEditable: any[];
   fixedColumnsUserConfig: any[];
   scrolleableColumnsUserConfig: any[];
   userColumnsConfigObj: any[];

   multiHeadersObjKeys = [
      'id_header',
      'id_column',
      'to_show',
      'child_columns'
   ];

   simpleHeadersObjKeys = [
      'id_column',
      'to_show',
   ];

   collapsedFixedColumns = false;
   collapsedScrolleableColumns = false;

   toShowAllFixedColumns = 'all';
   toShowAllScrolleableColumns = 'all';

   searchTerms: string;
   showContent = false;

   constructor(
      public activeModal: NgbActiveModal,
      public dragulaService: DragulaService,
      private baseService: BaseService,
      private cdRef: ChangeDetectorRef
   ) {
      this.dragulaService.createGroup('fixed', {
         accepts: (_el, target, source, _sibling) => {
            return target === source;
         },

      });
      this.dragulaService.createGroup('scrolleable', {
         accepts: (_el, target, source, _sibling) => {
            return target === source;
         }
      });
   }

   ngAfterViewInit() {
      this.showContent = true;
      // this.cdRef.detectChanges();
   }

   ngAfterViewChecked() {
      this.cdRef.detectChanges();
   }

   ngAfterContentInit() {

   }

   ngAfterContentChecked() {
      // this.cdRef.detectChanges();
   }

   collapsingFixedColumns() {
      this.collapsedFixedColumns = !this.collapsedFixedColumns;
      this.resetAllColumns(this.fixedColumnsEditable);
   }

   collapsingScrolleableColumns() {
      this.collapsedScrolleableColumns = !this.collapsedScrolleableColumns;
      this.resetAllColumns(this.scrolleableColumnsEditable);
   }

   ngOnDestroy() {
      this.dragulaService.destroy('fixed');
      this.dragulaService.destroy('scrolleable');
   }

   ngOnInit() {
      if (this.headersPosition === 'fixed') {
         this.fixedColumnsEditable = _.cloneDeep(this.fixedColumns);
         this.resetAllColumns(this.fixedColumnsEditable);
      }
      this.scrolleableColumnsEditable = _.cloneDeep(this.scrolleableColumns);
      this.resetAllColumns(this.scrolleableColumnsEditable);
   }

   /**
    * Falsea los hijos y los hijos de los hijos de
    * una columna padre que este con to_show en false
    */
   setChildColumnsToShowFalse(column: any, hasParentHidden?: boolean) {
      if (hasParentHidden) {
         column.child_columns.forEach((child: any) => {
            child.to_show = 'False';
            if (child.child_columns && child.child_columns.length > 0) {
               this.setChildColumnsToShowFalse(child, true);
            }
         });
      } else if (column.to_show === 'False') {
         column.child_columns.forEach((child: any) => {
            child.to_show = 'False';
            if (child.child_columns && child.child_columns.length > 0) {
               this.setChildColumnsToShowFalse(child, true);
            }
         });

      } else {
         column.child_columns.forEach((child: any) => {
            if (child.child_columns && child.child_columns.length > 0) {
               this.setChildColumnsToShowFalse(child, false);
            }
         });
      }
   }

   /**
    * Setea al menos 1 hijo en to_show true si el padre tiene to_show true
    * y el caso de que el padre tenga todos los hijos apagados.
    */
   setAtLeastOneChildToShowTrue(column: any) {
      if (column.child_columns && column.child_columns.length > 0) {
         const hasSomeSonToShowTrue = column.child_columns.some((column: any) => column.to_show === 'True');
         if (!hasSomeSonToShowTrue) {
            column.child_columns[0].to_show = 'True';
            if (column.child_columns[0].child_columns && column.child_columns.length > 0) {
               this.setAtLeastOneChildToShowTrue(column.child_columns[0]);
            }
         } else {
            column.child_columns.forEach((child: any) => {
               if (child.to_show === 'True') this.setAtLeastOneChildToShowTrue(child);
            });
         }
      }
   }

   emitColumns() {

      if (this.headersType === 'multi') {
         this.fixedColumnsEditable.forEach((column: any) => {
            if (column.child_columns && column.child_columns.length > 0) {
               this.setChildColumnsToShowFalse(column);
               if (column.to_show === 'True') {
                  this.setAtLeastOneChildToShowTrue(column);
               }
            }
         });

         this.scrolleableColumnsEditable.forEach((column: any) => {
            if (column.child_columns && column.child_columns.length > 0) {
               this.setChildColumnsToShowFalse(column);
               if (column.to_show === 'True') {
                  this.setAtLeastOneChildToShowTrue(column);
               }
            }
         });
      }

      if (this.headersPosition === 'fixed') {

         this.fixedColumnsUserConfig = _.cloneDeep(this.fixedColumnsEditable);
         this.scrolleableColumnsUserConfig = _.cloneDeep(this.scrolleableColumnsEditable);

         this.setUserColumnsConfigObj(this.fixedColumnsUserConfig, this.headersType);
         this.setUserColumnsConfigObj(this.scrolleableColumnsUserConfig, this.headersType);

         this.concatUserColumnsConfigObj(this.fixedColumnsUserConfig, this.scrolleableColumnsUserConfig);
      } else {

         this.scrolleableColumnsUserConfig = _.cloneDeep(this.scrolleableColumnsEditable);

         this.setUserColumnsConfigObj(this.scrolleableColumnsUserConfig, this.headersType);

         this.concatUserColumnsConfigObj([], this.scrolleableColumnsUserConfig);
      }

      const params = {
         id_line: this.idLine,
         id_report: this.idReport,
         username: this.username,
         columns_config: JSON.stringify(this.userColumnsConfigObj),
         report_config: ''
      };
      this.baseService.setReportUserConfig(params)
         .then(() => {
            if (this.headersPosition === 'fixed') {
               this.fixedColumnsEmitter.emit(this.fixedColumnsEditable);
            } else {
               this.fixedColumnsEmitter.emit(null);
            }
            this.scrolleableColumnsEmitter.emit(this.scrolleableColumnsEditable);
            this.columnsEmitter.emit(this.userColumnsConfigObj);
            this.resetConfigEmitter.emit(false);
            this.activeModal.dismiss();
         });
   }


   concatUserColumnsConfigObj(array1: any[], array2: any[]) {
      this.userColumnsConfigObj = array1.concat(array2);
   }

   setUserColumnsConfigObj(columns: any, headersType: string) {

      let objKeys: string[];

      switch (headersType) {
         case 'multi':
            objKeys = this.multiHeadersObjKeys;
            break;
         case 'simple':
            objKeys = this.simpleHeadersObjKeys;
            break;
         default:
            break;
      }

      columns.forEach((column: any) => {
         Object.keys(column).forEach((key: any) => {
            if (!objKeys.includes(key)) {
               delete column[key];
            }
            if (column.child_columns && column.child_columns.length > 0) {
               this.setUserColumnsConfigObj(column.child_columns, headersType);
            }
         });
      });
   }

   cancelEdition() {
      if (this.headersPosition === 'fixed') this.fixedColumnsEditable = _.cloneDeep(this.fixedColumns);
      this.scrolleableColumnsEditable = _.cloneDeep(this.scrolleableColumns);
      this.activeModal.dismiss();
   }

   resetConfig() {
      const params = {
         id_line: this.idLine,
         id_report: this.idReport,
         username: this.username,
         columns_config: '',
         report_config: ''
      };
      this.baseService.setReportUserConfig(params)
         .then(() => {
            this.fixedColumnsEmitter.emit(null);
            this.scrolleableColumnsEmitter.emit(null);
            this.columnsEmitter.emit(null);
            this.resetConfigEmitter.emit(true);
            this.activeModal.dismiss();
         });
   }

   showSubcolumns(column: any) {
      if (column.show_subcolumns === undefined) {
         column.show_subcolumns = false;
      } else if (column.show_subcolumns) {
         if (this.hasChildrenResolver(column)) this.resetAllColumns(column.child_columns);
         column.show_subcolumns = !column.show_subcolumns;
      } else {
         column.show_subcolumns = !column.show_subcolumns;
      }
   }

   /**
    * Setea en True o False la to_show property de la columna
    * y la de sus hijos y los hijos de los hijos de acuerdo
    * a la condicion que se le pase.
    */
   setToShowAllChilds(column: any, condition: string) {
      if (this.hasChildrenResolver(column)) {
         column.to_show = condition;
         column.child_columns.forEach((column: any) => {
            this.setToShowAllChilds(column, condition);
         });
      } else {
         column.to_show = condition;
      }
   }

   toggleToShowColumns(column: any) {
      if (this.hasChildrenResolver(column)) {
         if (column.state === 'all') {
            this.setToShowAllChilds(column, 'False');
            // column.show_subcolumns = false;
         } else if (column.state === 'none') {
            this.setToShowAllChilds(column, 'True');
            // column.show_subcolumns = true;
         } else {
            this.setToShowAllChilds(column, 'True');
         }
      } else {
         if (column.to_show === 'True') {
            this.setToShowAllChilds(column, 'False');
            // column.show_subcolumns = false;
         } else {
            this.setToShowAllChilds(column, 'True');
         }
      }
   }


   toggleToShowAllFixedColumns() {
      if (!this.toShowAllFixedColumns) {
         this.toShowAllFixedColumns = 'all';
         this.fixedColumnsEditable.forEach((column: any) => {
            this.setToShowAllChilds(column, 'True');
         });
      } else if (this.toShowAllFixedColumns !== 'all') {
         this.toShowAllFixedColumns = 'all';
         this.fixedColumnsEditable.forEach((column: any) => {
            this.setToShowAllChilds(column, 'True');
         });
      } else if (this.toShowAllFixedColumns === 'all') {
         this.toShowAllFixedColumns = 'none';
         this.fixedColumnsEditable.forEach((column: any) => {
            this.setToShowAllChilds(column, 'False');
         });
      }
      this.cdRef.detectChanges();
   }

   toggleToShowAllScrolleableColumns() {
      if (!this.toShowAllScrolleableColumns) {
         this.toShowAllScrolleableColumns = 'all';
         this.scrolleableColumnsEditable.forEach((column: any) => {
            this.setToShowAllChilds(column, 'True');
         });
      } else if (this.toShowAllScrolleableColumns !== 'all') {
         this.toShowAllScrolleableColumns = 'all';
         this.scrolleableColumnsEditable.forEach((column: any) => {
            this.setToShowAllChilds(column, 'True');
         });
      } else if (this.toShowAllScrolleableColumns === 'all') {
         this.toShowAllScrolleableColumns = 'none';
         this.scrolleableColumnsEditable.forEach((column: any) => {
            this.setToShowAllChilds(column, 'False');
         });
      } this.cdRef.detectChanges();

   }

   checkColumnStateAll(column: any) {
      if (column.state) {
         if (column.state === 'all') return true;
      } else if (column.to_show === 'True') return true;
   }

   checkColumnStateNone(column: any) {
      if (column.state) {
         if (column.state === 'none') return true;
      } else if (column.to_show === 'False') return true;
   }

   columnStateResolver(column: any) {
      if (column.child_columns.every((column: any) => this.checkColumnStateAll(column))) {
         column.state = 'all';
         return 'all';
      } else if (column.child_columns.every((column: any) => this.checkColumnStateNone(column))) {
         column.state = 'none';
         return 'none';
      } else {
         column.state = 'some';
         return 'some';
      }
   }

   // setStateAllColumns(columns) {
   //    columns.forEach((column: any) => {

   //    });
   // }

   fixedColumnsStateResolver() {
      if (this.fixedColumnsEditable.every((column: any) => this.checkColumnStateAll(column))) {
         this.toShowAllFixedColumns = 'all';
         return 'all';
      } else if (this.fixedColumnsEditable.every((column: any) => this.checkColumnStateNone(column))) {
         this.toShowAllFixedColumns = 'none';
         return 'none';
      } else {
         this.toShowAllFixedColumns = 'some';
         return 'some';
      }
   }

   scrolleableColumnsStateResolver() {
      if (this.scrolleableColumnsEditable.every((column: any) => this.checkColumnStateAll(column))) {
         this.toShowAllScrolleableColumns = 'all';
         return 'all';
      } else if (this.scrolleableColumnsEditable.every((column: any) => this.checkColumnStateNone(column))) {
         this.toShowAllScrolleableColumns = 'none';
         return 'none';
      } else {
         this.toShowAllScrolleableColumns = 'some';
         return 'some';
      }
   }

   resetAllColumns(columns: any) {
      columns.forEach((column: any) => {
         if (column.show_subcolumns) column.show_subcolumns = false;
         if (column.searched) column.searched = false;
         if (this.hasChildrenResolver(column)) this.resetAllColumns(column.child_columns);
      });
   }

   searchColumn() {
      if (this.headersPosition === 'fixed') {
         this.resetAllColumns(this.fixedColumnsEditable);
         this.fixedColumnsEditable.forEach((column: any) => {
            if (column.display_name.toString().toLowerCase().includes(this.searchTerms.toString().toLowerCase())) {
               column.searched = true;
            } else if (column.searched) {
               column.searched = false;
            }
            if (this.hasChildrenResolver(column)) this.searchColumnDeep(column);
         });
      }

      this.resetAllColumns(this.scrolleableColumnsEditable);
      this.scrolleableColumnsEditable.forEach((column: any) => {
         if (column.display_name.toString().toLowerCase().includes(this.searchTerms.toString().toLowerCase())) {
            column.searched = true;
         } else if (column.searched) {
            column.searched = false;
         }
         if (this.hasChildrenResolver(column)) this.searchColumnDeep(column);
      });
   }

   searchColumnDeep(parentColumn: any, grandParentColumn?: any) {
      parentColumn.child_columns.forEach((column: any) => {
         if (column.display_name.toString().toLowerCase().includes(this.searchTerms.toString().toLowerCase())) {
            column.searched = true;
            parentColumn.show_subcolumns = true;
            if (grandParentColumn) grandParentColumn.show_subcolumns = true;
         } else if (column.searched) {
            column.searched = false;
            parentColumn.show_subcolumns = false;
            if (grandParentColumn) grandParentColumn.show_subcolumns = false;

         }
         if (this.hasChildrenResolver(column)) this.searchColumnDeep(column, parentColumn);
      });
   }

   hasChildrenResolver(column: any) {
      return (column.child_columns && column.child_columns.length > 0);
   }

   marginLeftRowResolver(iteration: number) {
      return iteration * 15;
   }

}
