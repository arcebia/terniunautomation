import { Component, OnInit, Input } from '@angular/core';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import * as $ from 'jquery';

@Component({
   selector: '/modal-columns-selection',
   templateUrl: './modal-columns-selection.component.html'
})
export class ModalColumnsSelectionComponent implements OnInit {

   @Input() materialInfo: any[];
   windowHeight: any;
   result: any;

   constructor(
      public activeModal: NgbActiveModal
   ) {
      this.windowHeight = $(window).height() - 0.3 * $(window).height();
   }

   ngOnInit() { }

   changeItem(item) {
      item.enable = !item.enable;
   }

   confirm() {
      this.activeModal.close(this.materialInfo);
   }
}
