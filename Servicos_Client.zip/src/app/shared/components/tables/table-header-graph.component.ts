import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';

import * as _ from 'lodash';

@Component({
   selector: 'table-header-graph',
   templateUrl: 'table-header-graph.component.html',
   styleUrls: ['table-header-graph.component.css'],
   encapsulation: ViewEncapsulation.None,
})
export class TableHeaderGraphComponent implements OnInit {

   @Input() data: any;
   @Input() column: any;
   @Input() headerHeight: number;

   chartConfig: any;

   values = [];
   xAxisCategories: any;

   loadedGraph = false;
   graph: any;

   delayTooltipTimeout: NodeJS.Timer;
   showTooltip = false;

   alias_column: any;

   marginLeft: number;

   constructor() { }

   ngOnInit() {

      this.chartConfig = this.column.additional_cfg.headerGraph;

      this.chartConfig.marginLeft ? this.marginLeft = this.chartConfig.marginLeft : this.marginLeft = 0;

      this.createGraph();
   }

   delayShowTooltip() {
      this.delayTooltipTimeout = setTimeout(() => {
         this.showTooltip = true;
      }, 1000);
   }

   resetDelayShowTooltip() {
      this.showTooltip = false;
      clearTimeout(this.delayTooltipTimeout);
   }

   createGraph() {
      this.loadedGraph = false;

      // Los labels del eje X
      this.xAxisCategories = this.data.map((item: any) => item[this.chartConfig.xAxis.categoriesFrom]).reverse();
      if (this.chartConfig.xAxis.reverse) this.xAxisCategories.reverse();

      this.graph = {
         config: {},
         series: [],
      };

      this.graph.config = {
         chart: {
            borderColor: '#666',
            borderWidth: 2,
            height: 215,
            width: 600,
         },
         legend: {
            enabled: false
         },
         id: this.chartConfig.id,
         title: {
            text: this.chartConfig.title,
            useHTML: true
         },
         subtitle: {
            text: this.chartConfig.subtitle,
            useHTML: true
         },
         xAxis: {
            categories: this.xAxisCategories,
            title: {
               text: this.chartConfig.xAxis.title
            },
         },
         yAxis: this.chartConfig.yAxis
         // yAxis: {
         //    title: {
         //       text: this.chartConfig.yAxis.title
         //    },
         //    plotLines: []
         // },
      };

      // Setea plotLine si tiene, lineas constantes
      // if (this.chartConfig.yAxis.plotLines && this.chartConfig.yAxis.plotLines.length > 0) {
      //    this.chartConfig.yAxis.plotLines.forEach((plotLine: any) => {
      //       this.graph.config.yAxis.plotLines.push(plotLine);
      //    });
      // }

      // Configuración de las series y su data
      this.chartConfig.series.forEach((serie: any, index: number) => {

         const serieToPush: any = {};

         if (serie.type) serieToPush.type = serie.type;
         if (serie.lineWidth || serie.lineWidth === 0) serieToPush.lineWidth = serie.lineWidth;
         if (serie.color) serieToPush.color = serie.color;
         if (serie.dataLabels) serieToPush.dataLabels = serie.dataLabels;
         if (serie.yAxis) serieToPush.yAxis = serie.yAxis;
         if (serie.marker) serieToPush.marker = serie.marker;

         this.setSerieData(serie, index);

         if (this.chartConfig.xAxis.reverse) {
            serieToPush.data = this.values[index].reverse();
         } else {
            serieToPush.data = this.values[index];
         }

         this.graph.series.push(serieToPush);


      });

      this.loadedGraph = true;
   }

   setSerieData(serie: any, index: number) {
      if (serie.alias_column) {
         this.alias_column = serie.alias_column;
      } else {
         this.alias_column = this.column.alias_column;
      }
      this.values[index] = this.data.map((item: any) => {
         if (item[this.alias_column] === '') {
            return null;
         } else {
            if (serie.dataType && serie.dataType === 'time') {
               const timeArray = item[this.alias_column].split(':');
               const min = timeArray[0];
               const sec = timeArray[1];
               if (sec === '00') {
                  return Number(`${min}.${sec}`);
               } else {
                  const secNumber = Number(sec) / 60;
                  const minNumber = Number(min) + secNumber;
                  return minNumber;
               }
            } else {
               return Number(item[this.alias_column]);
            }
         }
      }).reverse();
   }

}
