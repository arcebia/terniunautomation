import { Component, OnInit, Input } from '@angular/core';

@Component({
   selector: 'material-icon',
   templateUrl: './material-icon.component.html'
})

export class MaterialIconComponent implements OnInit {
   @Input() public icon: string;
   @Input() classes: string;
   @Input() tooltip: string;
   @Input() tooltip_placement: string;

   ngOnInit(): void {

   }

}
