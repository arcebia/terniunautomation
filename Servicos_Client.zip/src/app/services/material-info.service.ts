import { Injectable } from '@angular/core';

import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';

@Injectable({ providedIn: 'root' })
export class MaterialInfoService {
   private materialInfo$: BehaviorSubject<any> = new BehaviorSubject(undefined);

   constructor() { }

   getMaterialInfo() {
      return this.materialInfo$;
   }

   updateMaterialInfo(materialInfo) {
      this.materialInfo$.next(materialInfo);
   }
}
