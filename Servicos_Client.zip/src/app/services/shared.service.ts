import { Injectable } from '@angular/core';

import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { Subject } from 'rxjs/internal/Subject';

import { environment } from '../../environments/environment';
// import { BaseService } from './base.service';

@Injectable({ providedIn: 'root' })
export class SharedService {

   dateShift = new BehaviorSubject<any>(undefined);
   selectedIdLine = new BehaviorSubject<any>(undefined);
   selectedIdPlant = new BehaviorSubject<any>(undefined);
   selectedIdProcess = new BehaviorSubject<any>(undefined);
   selectedIdUpper = new BehaviorSubject<any>(undefined);
   selectedReport = new BehaviorSubject<any>(undefined);
   user = new BehaviorSubject<any>(undefined);
   isIEorEdge = new BehaviorSubject<boolean>(false);

   updateLastLineVisited = new Subject<any>();

   hideMenu = new BehaviorSubject<boolean>(false);
   hideHeaders = new BehaviorSubject<boolean>(false);

   isOpenSideBar = new BehaviorSubject<boolean>(false);

   toastSubject = new Subject<any>();

   BaseURL = environment.BaseURL;
   SSIURL = environment.SSIURL;
   MVPURL = environment.MVPURL;
   ALARMSURL = environment.ALARMSURL;
   SioShared = environment.SioShared;
   IndustryURL = environment.IndustryURL;
   TrendURL = environment.TrendURL;

   ALARMSLOCAL: string;

   RolProgrammingProcessProgram = environment.RolProgrammingProcessProgram;
   RolProgrammingProcessProduction = environment.RolProgrammingProcessProduction;
   RolOvenGasRelation = environment.RolOvenGasRelation;
   RolAnomaliesManagement = environment.RolAnomaliesManagement;
   RolWeldingBreaks = environment.RolWeldingBreaks;

   lastIdLine: any;

   selectedMaterial: any;
   selectedProcess: any;
   selectedPlant: any;
   selectedLine: any;
   selectedUpper: any;
   sideBarValue: boolean;
   currentState: any;
   customParams = [];
   currentUpperMenu: number;
   currentUser: any;
   fromNCA: boolean;
   fromN2A = false;
   // hideMenu = false;
   currentUpperMenuItem: any;

   IdSuperiorDefault = environment.IdSuperiorDefault;
   IdIzquierdoDefault = environment.IdIzquierdoDefault;


   private customParamsSource = new Subject<any>();
   customParams$ = this.customParamsSource.asObservable();

   genericFilterType = { Text: 'Text', Date: 'Date', DateShift: 'DateShift', DoubleDate: 'DoubleDate', DropDown: 'Select', Empty: 'Empty' };
   colorsHighcharts2 = ['rgb(54,111,167)', '#16A085', '#C0392B', '#2C3E50', '#8E44AD', '#2980B9', '#27AE60', '#D35400', '#F39C12'];
   colorsHighcharts = ['#16A085', '#C0392B', '#2C3E50', '#8E44AD', '#2980B9', '#27AE60', '#D35400', '#F39C12'];
   colorsPlotBands = ['rgba(47, 128, 231, 0.1)', ' rgba(43, 149, 122, 0.1)', 'rgba(244, 67, 54, 0.1)', 'rgba(247, 118, 0, 0.1)', 'rgba(255, 192, 231, 0.1)'];
   colorsPlotBands2 = ['rgba(47, 128, 231, 0.4)', ' rgba(43, 149, 122, 0.4)', 'rgba(244, 67, 54, 0.4)', 'rgba(247, 118, 0, 0.4)', 'rgba(255, 192, 231, 0.4)'];
   colorFontHighchart = '#666';
   semTEStatus = ['blue', 'green', 'yellow', 'red', 'unknown'];
   img_root = 'assets/images/';
   images = {
      rightarrow: this.img_root + 'rightarrow.png',
      leftarrow: this.img_root + 'leftarrow.png',
      rev: this.img_root + 'trans1.svg',
      'estado_linea_9': this.img_root + 'not_available.png',
      'estado_linea_8': this.img_root + 'not_available.png',
      'estado_linea_0': this.img_root + 'available.png',
      'estado_linea_1': this.img_root + 'delay.png',
      'estado_linea_2': this.img_root + 'low_rate.png',
      'Acería': this.img_root + 'aceria.png',
      'HRD': this.img_root + 'hrd.svg',
      'Laminación en Caliente': this.img_root + 'lam.png',
      'Laminación en Frío': this.img_root + 'lam.png',
      'Mineral': this.img_root + 'mina.png',
      'Pellas': this.img_root + 'pella.png',
      'Revestidos': this.img_root + 'rev.png',
      'Transformados': this.img_root + 'trans.png',
      dictamen_A: this.SioShared + 'Content/img/dictamen_A.gif',
      dictamen_D: this.SioShared + 'Content/img/dictamen_D.gif',
      dictamen_P: this.SioShared + 'Content/img/dictamen_P.gif',
      dictamen_R: this.SioShared + 'Content/img/dictamen_R.gif',
      dictamen_S: this.SioShared + 'Content/img/dictamen_S.gif',
      dictamen_ND: this.SioShared + 'Content/img/dictamen_ND.gif',
      est_verde: this.SioShared + 'Content/img/est_verde_p.gif',
      est_rojo: this.SioShared + 'Content/img/est_rojo_p.gif'
   };
   monthsNames = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];


   constructor(
      // private baseService: BaseService
   ) {
      this.selectedIdUpper.subscribe(v => console.log('upper change service', v));
      // this.selectedIdLine.subscribe(v => console.log('line change service', v));
      // this.selectedIdPlant.subscribe(v => console.log('plant change service', v));
      // this.selectedIdProcess.subscribe(v => console.log('process change service', v));
      // this.selectedReport.subscribe(v => console.log('report change service', v));
      // this.dateShift.subscribe(v => console.log('date change service', v));
   }

   updateCustomParam(reportCode: string, paramName: string, paramValue: any) {
      const reportParams = this.customParams[reportCode];
      if (reportParams) {
         this.customParams[reportCode][paramName] = paramValue;
      } else {
         this.updateCustomParams(reportCode, { paramName: paramValue });
      }

      this.customParamsSource.next(this.customParams);
   }

   updateCustomParams(reportCode: string, customParams: any) {
      this.customParams[reportCode] = customParams;
      this.customParamsSource.next(this.customParams);
   }

   updateIdLine(idLine) {
      if (!this.selectedIdLine.getValue()) {
         this.selectedIdLine.next(idLine);
      } else if (idLine !== this.selectedIdLine.getValue()) {
         this.selectedIdLine.next(idLine);
         this.updateLastLineVisited.next(idLine);
      }
   }

   updateIdPlant(idPlant) {
      if (idPlant !== this.selectedIdPlant.getValue()) this.selectedIdPlant.next(idPlant);
   }

   updateIdProcess(idProcess) {
      if (idProcess !== this.selectedIdProcess.getValue()) this.selectedIdProcess.next(idProcess);
   }

   updateIdUpper(idUpper) {
      if (idUpper !== this.selectedIdUpper.getValue()) this.selectedIdUpper.next(idUpper);
   }

   updateReport(report) {
      if (report !== this.selectedReport.getValue()) this.selectedReport.next(report);
   }

   showToast(options) {
      this.toastSubject.next(options);
   }

   getDateISOFormat(date: string) {
      return new Date(date);
   }

   toggleSideBar() {
      this.isOpenSideBar.next(!this.isOpenSideBar.getValue());
   }

   // async idLineChangeHandler(idLine: any) {
   //    localStorage.clear();
   //    const userPreferences = {
   //       username: this.user.getValue().username,
   //       lastLineVisited: idLine,
   //       favorites: []
   //    };
   //    const userPreferencesParams = {
   //       id_line: 0,
   //       id_report: 0,
   //       columns_config: '',
   //       report_config: JSON.stringify(userPreferences),
   //    };
   //    // await this.baseService.setReportUserConfig(userPreferencesParams);
   //    // localStorage.setItem('user_preferences', JSON.stringify(userPreferencesParams));
   // }


}
