import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SharedService } from './shared.service';

@Injectable({ providedIn: 'root' })
export class ProgramService {

   BaseURL = this.sharedService.BaseURL + 'program/';

   constructor(
      private http: HttpClient,
      public sharedService: SharedService
   ) { }

   getAvailableMaterials(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'available_materials', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   availableMaterialExportExcel(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'export_available_materials_excel', { params: params })
         .toPromise()
         .then((response: any) => {
            window.open(response.url);
         })
         .catch(this.handleError);
   }

   getAvailablePrograms(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'available_programs', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getProgramDetail(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'program_detail', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getMaterialDefects(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'material_defects', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   programmDetailExportExcel(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'export_program_detail_excel', { params: params })
         .toPromise()
         .then((response: any) => {
            window.open(response.url);
         })
         .catch(this.handleError);
   }

   sequeceProgramExportPdf(parameters): Promise<any[]> {
      return this.http.get(this.BaseURL + 'export_program_pdf', { params: parameters })
         .toPromise()
         .then((response: any) => {
            window.open(response.url, '_blank');
         })
         .catch(this.handleError);
   }

   sequeceProgramExportExcel(parameters): Promise<any[]> {
      return this.http.get(this.BaseURL + 'export_program_excel', { params: parameters })
         .toPromise()
         .then((response: any) => {
            window.open(response.url);
         })
         .catch(this.handleError);
   }

   programmingProcessExportExcel(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'export_programming_process_excel', { params: params })
         .toPromise()
         .then((response: any) => {
            window.open(response.url);
         })
         .catch(this.handleError);
   }

   getTechnicalSpecification(params): Promise<any> {
      return this.http.get(this.BaseURL + 'technical_specifications', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getProgrammingProcessComments(param): Promise<any[]> {
      return this.http.post(this.BaseURL + 'get_programming_process_comments', param)
         .toPromise()
         .catch(this.handleError);
   }

   postProgrammingProcessComments(params): Promise<any[]> {
      return this.http.post(this.BaseURL + 'programming_process_comments', params)
         .toPromise()
         .catch(this.handleError);
   }

   updateProgrammingProcessComments(params): Promise<any[]> {
      return this.http.put(this.BaseURL + 'programming_process_comments', params)
         .toPromise()
         .catch(this.handleError);
   }

   getProgrammingProcess(params): Promise<any> {
      return this.http.get(this.BaseURL + 'programming_process', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   private handleError(error: any): Promise<any> {
      return Promise.reject(error.message || error);
   }

}
