import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { SharedService } from './shared.service';

@Injectable({ providedIn: 'root' })
export class ProductionService {

   BaseURL = this.sharedService.BaseURL + 'production/';

   constructor(
      private http: HttpClient,
      public sharedService: SharedService
   ) { }

   getReportDataSteelWorks(params): Promise<any> {
      return this.http.get(this.BaseURL + 'get_report_data_steelworks', { params })
         .toPromise()
         .catch(this.handleError);
   }

   exportExcelSteelworkProduction(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'export_steelwork_production_excel', { params: params, observe: 'response', responseType: 'blob' })
         .toPromise()
         .then((res: any) => {
            window.open(res.url);
         })
         .catch(this.handleError);
   }

   getGanttFlowGeneral(params): Promise<any> {
      return this.http.get(this.BaseURL + 'get_gantt_flow_general', { params })
         .toPromise()
         .catch(this.handleError);
   }

   getWebAceProductionSummary(params): Promise<any> {
      return this.http.get(this.BaseURL + 'get_web_ace_production_summary', { params })
         .toPromise()
         .catch(this.handleError);
   }

   getProductionColumns(params): Promise<any[]> {
      const param = {
         id_line: params.id_line
      };
      return this.http.get(this.BaseURL + 'production_columns', { params: param })
         .toPromise()
         .catch(this.handleError);
   }


   getLineStatus(idLine?): Promise<any> {
      return this.http.get(this.BaseURL + 'line_status/' + idLine)
         .toPromise()
         .catch(this.handleError);
   }

   getEfficiency(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'get_sgl_indicators', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getProductionSearch(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'search', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   steelworkSearchByMaterial(params): Promise<any> {
      return this.http.get(this.BaseURL + 'search_material', { params })
         .toPromise()
         .catch(this.handleError);
   }

   getProductionCoils(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'production_coils', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getProductionSummary(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'production_summary', { params: params })
         .toPromise()
         .then(response => response[0])
         .catch(this.handleError);
   }

   getProductionGantt(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'production_gantt', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   exportExcelProduction(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'export_production_excel', { params: params })
         .toPromise()
         .then((response: any) => {
            window.open(response.url);
         })
         .catch(this.handleError);
   }

   getCoilDefects(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'coil_defects', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getDefectsGeneric(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'defects_generic', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getSuppliesReport(params): Promise<any> {
      return this.http.get(this.BaseURL + 'get_supplies', { params })
         .toPromise()
         .catch(this.handleError);
   }

   private handleError(error: any): Promise<any> {
      return Promise.reject(error.message || error);
   }
}
