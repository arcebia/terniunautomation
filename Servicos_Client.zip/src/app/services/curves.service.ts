import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import * as _ from 'lodash';

import { DatepickerService } from './datepicker.service';
import { SharedService } from './shared.service';

@Injectable({ providedIn: 'root' })
export class CurvesService {

   BaseURL = this.sharedService.BaseURL + 'curves/';

   constructor(
      private http: HttpClient,
      public sharedService: SharedService,
      public dateService: DatepickerService
   ) { }

   getNextPreviousCoil(params): Promise<any> {
      params.id_line = this.sharedService.selectedIdLine.getValue();
      return this.http.get(this.BaseURL + 'get_coil', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getCurveConfig(params): Promise<any> {
      return this.http.get(this.BaseURL + 'config', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getCurveConfigLength(params): Promise<any> {
      return this.http.get(this.BaseURL + 'config_length', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getYAxis(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'y_axis', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getCurveData(body): Promise<any> {
      return this.http.post(this.BaseURL + 'curve_data', body)
         .toPromise()
         .catch(this.handleError);
   }

   getTrendingSections(params): Promise<any> {
      return this.http.get(this.BaseURL + 'trending_sections', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getCurves3D(params): Promise<any> {
      return this.http.get(this.BaseURL + 'curve_data_planeza_3d', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getBasicConfig(resp, height, id?): any {
      return {
         id: id || 'chartCurves',
         chart: {
            zoomType: 'x',
            plotBorderWidth: 1,
            plotBorderColor: '#e6e6e6',
            height: height,
            margin: [25, 20, 20, 20]
         },
         lang: {
            noData: 'No hay datos disponibles'
         },
         noData: {
            style: {
               fontWeight: 'bold',
               fontSize: '15px',
               color: '#303030'
            }
         },
         legend: {
            align: 'center',
            verticalAlign: 'top',
            itemMarginTop: -25,
            itemStyle: {
               fontSize: '11px'
            },
            useHTML: true
         },
         title: {
            text: ''
         },
         xAxis: {
            min: 0,
            gridLineWidth: 1,
            gridLineDashStyle: 'dash',
            lineColor: '#e6e6e6',
            tickColor: '#e6e6e6',
            tickWidth: 0,
            title: {
               useHTML: true,
               text: ''
            },
            labels: {
               y: 10,
               style: {
                  fontSize: '10px'
               }
            }
         },
         yAxis: [],
         tooltip: {
            useHTML: true,
            shared: true
         },
         plotOptions: {
            series: {
               marker: {
                  enabled: false
               }
            },
            line: {
               lineWidth: 1
            }
         }
      };
   }

   getSIOBasicConfig(selectedX, height, id?): any {
      const isTime = ((selectedX.name && selectedX.name.toUpperCase() === 'TIEMPO') || selectedX.description.toUpperCase() === 'TIEMPO');
      return {
         id: id || 'chartCurves',
         gridHide: true,
         chart: {
            backgroundColor: 'rgba(255, 255, 255, 0.1)',
            plotBackgroundColor: '#FFFFFF',
            title: {},
            type: 'line',
            height: height,
            zoomType: 'x'
         },
         legend: {
            enabled: false
         },
         exporting: {
            enabled: false
         },
         title: {
            text: '',
            margin: 10,
            style: {
               fontSize: '11px'
            }
         },
         credits: {
            enabled: false
         },
         xAxis: {
            type: isTime ? 'datetime' : 'linear',
            gridLineWidth: 1,
            title: {
               useHTML: true,
               text: '<b>' + selectedX.description + (selectedX.unit !== 'VOID' ? ' (' + selectedX.unit + ') ' : '') + '</b>'
            },
         },
         yAxis: [],
         tooltip: {
            dateTimeLabelFormats: {
               day: '%e of %b'
            },
            headerFormat: isTime ? '<b>{point.x:%H:%M:%S}</b></br>' : '<b>{point.x:0.2f}</b></br>',
            pointFormat: '<span style="color:{point.color}">\u25CF</span> {series.name}: <b>{point.y:0.2f}</b></br>'
         },
         plotOptions: {
            series: {
               marker: {
                  enabled: false
               }
            },
            line: {
               lineWidth: 1
            }
         }
      };
   }

   getCustomScaleColorForCurve3d(_data) {
      const obj: any = {};
      const _percent = (Number(_data[_data.length - 1].min_limit) - Number(_data[0].max_limit)) * 0.02;
      const _min = Number(_data[0].max_limit) - 4;
      const _max = Number(_data[_data.length - 1].min_limit) + 4;
      const _diff = _max - _min;
      const _colorScale = [];
      let _index = 0;
      const max_value = 0;

      for (const item of _data) {
         let _item = [];
         let _max_limit = item.max_limit;
         let _min_limit = item.min_limit;
         let _perValue;

         if (_min_limit.length > 0) {
            _min_limit = Number(_min_limit);
            if (_min_limit < _max) {
               _perValue = ((_min_limit + 0.1) - _min) / _diff;
            } else {
               if (_index === _data[_data.length - 1]) {
                  _min_limit = _min_limit - 0.1;
               }
               _perValue = (_min_limit - _min) / _diff;
            }

            _item.push(_perValue, item.color);
            _colorScale.push(_item);
            _item = [];

         }

         if (_max_limit.length > 0) {
            _max_limit = Number(_max_limit);

            _perValue = (_max_limit - _min) / _diff;
            _item.push(_perValue, item.color);
            _colorScale.push(_item);

         }


         _index++;
      }

      // prevent gradiente colors in bar color
      _colorScale[0] = [0, _colorScale[0][1]];
      _colorScale[_colorScale.length - 1] = [1, _colorScale[_colorScale.length - 1][1]];

      const item = _colorScale[1];
      const last_item = _colorScale[_colorScale.length - 1];
      _colorScale.splice(1, 0, [item[0] - 0.01, _colorScale[0][1]]);
      _colorScale.splice(_colorScale.length - 1, 0, [(Number(_colorScale[_colorScale.length - 2][0]) + 0.01), last_item[1]]);

      obj.colors = _colorScale;
      obj.zMax = _max;
      obj.zMin = _min;
      return obj;


   }

   getSioBasicConfigCurved3d(resp, divID, title) {
      const _configPlotly: any = {
         options: {},
         data: [],
         layout: {},
         label: resp.description
      };
      let zmin = -30;
      let zmax = 30;
      let colorScale = [
         [0, 'rgba(0, 0, 132, 1)'], // 0
         [0.166, 'rgba(0, 0, 255, 1)'], // -10
         [0.502, 'rgba(0, 255, 255, 1)'], // -10 - 0  Azul
         [0.502, 'rgba(0, 255, 0, 1)'], // -10 - 0 Azul
         [0.6665, 'rgba(0, 255, 0, 1)'], // 0-10 Verde
         [0.6665, 'rgba(255, 255, 0, 1)'], // 10 - 15 amarillo claro
         [0.8346456693, 'rgba(255, 199, 0, 1)'], // 15 - 29 amarillo Oscuro
         [0.8346456693, 'rgba(255, 0, 0, 1)'], // 20 - 30 Rojo
         [1, 'rgba(255, 0, 0, 1)']
      ];

      if (resp.scale_colors.length > 0) {
         const _scale = this.getCustomScaleColorForCurve3d(resp.scale_colors);
         colorScale = _scale.colors;

         zmin = _scale.zMin;
         zmax = _scale.zMax;

      }

      const data = {
         z: resp.series,
         y: resp.y_axis,
         x: resp.x_axis,
         type: 'surface',
         colorbar: {
            // ticklen: 2,
            // title: ''
         },
         colorscale: colorScale, // 20 - 30 Rojo
         showscale: true,
         zauto: false,
         zmin: zmin,
         zmax: zmax,
         contours: {
            x: {
               show: true,
               usecolormap: true,
               width: 1
            },
            y: {
               show: true,
               usecolormap: true,
               width: 1
            }
         }
      };
      _configPlotly.options = {
         id: divID,
         gridHide: true,
         tick_text_z: resp.x_axis_tick_text,
         id_variable: resp.id_variable
      };

      _configPlotly.data = [data];

      _configPlotly.layout = {
         title: '',
         height: 600,
         showlegend: true,
         autosize: true,
         scene: {
            xaxis: {
               title: '',
               dtick: resp.tick_series,
               backgroundcolor: 'rgb(224, 224, 224)',
               gridcolor: 'rgb(192, 192, 192)',
               showbackground: true,
               zerolinecolor: 'rgb(224, 224, 224)'
            },
            yaxis: {
               title: '',
               dtick: 2,
               backgroundcolor: 'rgb(255, 255, 255)',
               gridcolor: 'rgb(192, 192, 192)',
               showbackground: true,
               zerolinecolor: 'rgb(224, 224, 224)',
               ticktext: resp.x_axis_tick_text,
               tickvals: this.getTickZonevals(resp.x_axis_tick_text)
            },
            zaxis: {
               title: '',
               dtick: 4,
               backgroundcolor: 'rgb(224, 224, 224)',
               gridcolor: 'rgb(192, 192, 192)',
               showbackground: true,
               zerolinecolor: 'rgb(224, 224, 224)',
               // range: [this.getValueRangeY(resp.min), this.getValueRangeY(resp.max)]
            },
            // aspectmode: "manual",
            aspectratio: {
               // x: 11.2, y: 3.6, z: 1.6
               x: 6.5, y: 1.5, z: 1
            },
            // scrollZoom: true,`
            camera: {
               center: { x: 0, y: 0, z: -.25 },
               // eye: { x: .4, y: -5, z: 3.6 },
               // up: { x: 0, y: 10, z: 0 },
               // center: { x: 0, y: 1.5, z: -0.1 },
               eye: { x: .2, y: -3.76, z: 1.25 },
               // up: { x: 0, y: 0, z: 0 }
            },
         },
         margin: {
            l: 0,
            r: 0,
            b: 0,
            t: 40
         },
      };
      return _configPlotly;
   }

   getTickZonevals(zone_tick_text) {
      const _labels_values = [];
      const salto = false;

      for (let i = 0; i < zone_tick_text.length; i++) {
         const _item = zone_tick_text[i].split('Z');
         _labels_values.push(Number(_item[1]));
      }
      return _labels_values;
   }

   getValueRangeY(val) {
      if (val > 0) {
         return val + 10;
      } else {
         return val - 10;
      }
   }

   getYAxi(y, i?) {
      return {
         name: y ? y.description.toUpperCase() : '',
         data: [],
         yAxis: i || 0,
         color: this.sharedService.colorsHighcharts[i || 0]
      };
   }

   setSeriesData(x, y, axi) {
      const isArray = _.isArray(y);
      _.each(x, (c, i) => {
         if (axi.data) {
            axi.data.push([+c, (isArray ? +y[i] : +y[c])]);
         } else {
            axi.push([+c, (isArray ? +y[i] : +y[c])]);
         }
      });
   }

   getYAxisConfig(yList, xList, o, i): any {
      return {
         labels: {
            enabled: false
         },
         title: {
            text: '', // xList.length > 1 || yList.length > 1 ? o.description : "",
            style: {
               color: this.sharedService.colorsHighcharts[i]
            }
         },
         plotLines: [],
         plotBands: []
      };
   }

   getYAxisSIOConfig(o, i): any {
      return {
         minorTickInterval: 'auto',
         labels: {
            format: '{value}',
            style: {
               color: this.sharedService.colorsHighcharts[i]
            }
         },
         title: {
            text: '<b>' + o.description + (o.unit && o.unit !== 'VOID' ? ' (' + o.unit + ') ' : '') + '</b>',
            style: {
               color: this.sharedService.colorsHighcharts[i]
            }
         },
         plotLines: [],
         plotBands: []
      };
   }

   convertToDateTime(xValues, selectedX, origin?) {
      let xValuesTime = null;
      // tslint:disable-next-line:triple-equals
      if ((selectedX.unit && selectedX.unit.toUpperCase() == 'TIEMPO') || selectedX.description.toUpperCase() == 'TIEMPO') {
         xValuesTime = [];
         _.each(xValues, (d) => {
            // tslint:disable-next-line:triple-equals
            if (!origin || origin == 'T') {
               xValuesTime.push(this.dateService.getUnixToUTCDate(d));
            } else {
               xValuesTime.push(this.dateService.getLocalToUTCDate(d));
            }
         });

         return xValuesTime;
      } else {
         return xValues;
      }
   }

   getPlotLineBands(yAxis, o) {
      const target = o.TargetLimit || o.objValue || o.TargetValue;
      const max = o.MaximumLimit || o.maxValue || o.MaximumBand;
      const min = o.MinimumLimit || o.minValue || o.MinimumBand;
      yAxis.plotLines = [{
         color: '#FF0000',
         value: max,
         width: 1,
         zIndex: 5
      }, {
         color: '#FF0000',
         value: target,
         width: 1,
         zIndex: 5
      }, {
         color: '#FF0000',
         value: min,
         width: 1,
         zIndex: 5
      }];
      yAxis.plotBands = [{
         color: '#eefdec',
         to: target || max,
         from: min,
         width: 1
      }, {
         color: '#eefdec',
         to: max,
         from: target || min,
         width: 1
      }];
      return yAxis;
   }

   getLimitsMaxMin(yAxis, max, min, values) {
      let maxValue = _.max(values);
      let minValue = _.min(values);
      maxValue = _.max([maxValue, max]) * 1.001;
      minValue = _.min([minValue, min]) * 0.999;
      yAxis.max = _.round(+maxValue, 3);
      yAxis.softMax = _.round(+maxValue, 3);
      yAxis.min = _.round(+minValue, 3);
      yAxis.softMin = _.round(+minValue, 3);
      return yAxis;
   }

   getRelationSection(sectionsCurvesOutput, value, inverted) {
      const section = _.find(sectionsCurvesOutput, (o) => {
         return +o.meters_start <= value && value <= +o.meters_end;
      });
      if (!section) return;
      let relationSectionValue = (value - +section.meters_start) / (+section.meters_end - +section.meters_start);
      if (inverted) {
         relationSectionValue = (+section.meters_end - value) / (+section.meters_end - +section.meters_start);
      }
      const relationSectionID = section.id_section_item;
      return {
         relationValue: relationSectionValue,
         idSection: relationSectionID
      };
   }


   getRelationValues(m, materialMoved, processedXData, plotIndex, sectionsCurvesOutput, currentMaterial?) {
      const maxCurrentX = +_.last(m);
      const maxFirstCursorX = +_.last(processedXData);
      let valueLeftPlot = m[plotIndex];
      let valueRightPlot = m[plotIndex];
      if (materialMoved.leftPlotLine && materialMoved.leftPlotLine.length >= plotIndex) {
         valueLeftPlot = materialMoved.leftPlotLine[plotIndex].value.x;
      }
      if (materialMoved.rightPlotLine && materialMoved.rightPlotLine.length >= plotIndex) {
         valueRightPlot = materialMoved.rightPlotLine[plotIndex].value.x;
      }
      // //Se calcula la relacion
      const sectionLeft = this.getRelationSection(sectionsCurvesOutput[materialMoved.id_exit], valueLeftPlot, materialMoved.inverted);
      const sectionRight = this.getRelationSection(sectionsCurvesOutput[materialMoved.id_exit], valueRightPlot, materialMoved.inverted);
      let valueCurrentPlotLeft = maxCurrentX * valueLeftPlot / maxFirstCursorX;
      let valueCurrentPlotRight = maxCurrentX * valueRightPlot / maxFirstCursorX;

      if (currentMaterial) {
         valueCurrentPlotLeft = this.getCurrentValuePlot(sectionsCurvesOutput[currentMaterial.id_exit], currentMaterial.inverted, sectionLeft);
         valueCurrentPlotRight = this.getCurrentValuePlot(sectionsCurvesOutput[currentMaterial.id_exit], currentMaterial.inverted, sectionRight);
      }

      let indexLeft = -1;
      let indexRight = -1;
      for (let index = 0; index < m.length; index++) {
         const element = m[index];
         if (element >= valueCurrentPlotRight && indexRight === -1) {
            indexRight = index;
         }
         if (element >= valueCurrentPlotLeft && indexLeft === -1) {
            indexLeft = index;
         }
         if (indexLeft !== -1 && indexRight !== -1) {
            break;
         }
      }
      return {
         indexLeft: valueCurrentPlotLeft > -1 ? indexLeft : valueCurrentPlotLeft,
         indexRight: valueCurrentPlotRight > -1 ? indexRight : valueCurrentPlotRight,
         valueCurrentPlotLeft: valueCurrentPlotLeft
      };
   }

   getCurrentValuePlot(sectionsCurvesOutput, inverted, section) {
      const currentSection: any = _.find(sectionsCurvesOutput, { id_section_item: section.idSection });
      let value = -1;
      if (currentSection) {
         const diff = (+currentSection.meters_end - +currentSection.meters_start);
         value = diff * section.relationValue + +currentSection.meters_start;
         if (inverted) {
            value = +currentSection.meters_end - (diff * section.relationValue);
         }
      }
      return value;
   }

   getSectionDescription(currentSection, tooltip, tooltipInfo) {
      if (currentSection.section_step !== 'B') {
         tooltip += '<span class="font-xs">';
         if (currentSection.section_step === 'O') {
            const material = currentSection.final_description.split(' ');
            tooltip += '</br>Sección de Otro Material (' + _.last(material) + ')';
         } else {
            tooltip += '</br>Tipo Sección: ' + currentSection.section_type_description;
         }

         const description = currentSection.final_description ? currentSection.final_description.split('->') : [];
         _.each(description, (d) => {
            const splitPipe = d.split('|');
            if (splitPipe.length > 1) {
               _.each(splitPipe, (s, i: number) => {
                  if (s.length > 1) {
                     if (i === 0) {
                        tooltip += '</br>';
                     }
                     const keyValue = s.split(':');
                     const index = tooltipInfo.indexOf(keyValue[0]);
                     if (keyValue.length > 1 && index > -1) {
                        if (index > 0) {
                           tooltip += ' (' + _.trim(keyValue[1]) + ')';
                        } else {
                           tooltip += _.trim(keyValue[1]);
                        }
                     }
                  }
               });
            } else {
               // if (d.length > 1) {
               //     tooltip += '</br>' + d;
               // }
            }
         });
         if (currentSection.section_type === 'DCT') {
            tooltip += '</br>Mts Inicio: ' + _.round(currentSection.meters_start, 3);
            tooltip += ' - Mts Fin: ' + _.round(currentSection.meters_end, 3);
         }
         tooltip += '</span>';
      }
      return tooltip;
   }

   getCurvesTypes(params) {
      return this.http.get(this.BaseURL + 'curves_types', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getAlarmsChart(config) {
      return {
         id: 'chartAlarms-' + config.id_exit,
         chart: {
            height: config.heightAlarms,
            plotBorderWidth: 1,
            plotBorderColor: '#e6e6e6',
            margin: [25, 20, 20, 20]
         },
         title: {
            text: '<b>ALARMAS</b>',
            margin: 0,
            useHTML: true,
            style: {
               fontSize: '11px'
            }
         },
         xAxis: {
            type: 'linear',
            min: 0,
            gridLineWidth: 1,
            gridLineDashStyle: 'dash',
            lineColor: '#e6e6e6',
            tickColor: '#e6e6e6',
            tickWidth: 0,
            max: config.length,
            labels: {
               style: {
                  fontSize: '10px'
               }
            }
         },
         yAxis: {
            title: {
               text: ''
            },
            categories: config.categoriesAlarms,
            reversed: true,
            labels: {
               enabled: false
            }
         },
         legend: {
            enabled: false
         },
         tooltip: {
            style: {
               fontSize: '11px'
            },
            useHTML: true
         },
         series: [{
            type: 'xrange',
            pointWidth: 8,
            data: config.alarmsSeries,
            tooltip: {
               headerFormat: '',
               pointFormatter: function (o) {
                  return '<b>[' + this.options.idAlarm + '] ' + this.yCategory + '</b><br>' +
                     '<span>On: ' + this.options.datetimeOn + '</span><br>' +
                     '<span>Off: ' + this.options.datetimeOff + '</span><br>' +
                     (this.options.datetimeAcknowledge ? '<span>Ack: ' + this.options.datetimeAcknowledge + '</span><br>' : '') +
                     '<span>Duración: ' + this.options.diff + ' seg</span>';
               }
            }
         }, {
            type: 'scatter',
            data: config.alarmsAckSeries,
            color: 'rgba(0, 0, 0, 0.5)',
            marker: {
               symbol: 'diamond'
            },
            tooltip: {
               headerFormat: '',
               pointFormatter: function (o) {
                  return '<span>Ack: ' + this.options.datetimeAcknowledge + '</span>';
               }
            }
         }],
         dataLabels: {
            enabled: true
         }
      };
   }

   getCommandsChart(config) {
      return {
         id: 'chartCommands-' + config.id_exit,
         chart: {
            type: 'scatter',
            height: config.heightCommands,
            plotBorderWidth: 1,
            plotBorderColor: '#e6e6e6',
            margin: [25, 20, 20, 20]
         },
         title: {
            text: '<b>COMANDOS</b>',
            margin: 0,
            useHTML: true,
            style: {
               fontSize: '11px'
            }
         },
         xAxis: {
            type: 'linear',
            min: 0,
            gridLineWidth: 1,
            gridLineDashStyle: 'dash',
            lineColor: '#e6e6e6',
            tickColor: '#e6e6e6',
            tickWidth: 0,
            max: config.length,
            labels: {
               style: {
                  fontSize: '10px'
               }
            }
         },
         yAxis: {
            title: {
               text: ''
            },
            labels: {
               enabled: false
            },
            reversed: true,
            tickAmount: config.commandsSeries.length + 1
         },
         legend: {
            enabled: false
         },
         tooltip: {
            formatter: function (o) {
               return '<b>' + this.series.name + '</b><br>' +
                  '<span>' + this.series.userOptions.sendDatetime + '</span><br>' +
                  '<span>' + this.series.userOptions.userName + '</span><br>' +
                  '<span>' + this.series.userOptions.application + '</span><br>';
            },
            style: {
               fontSize: '11px'
            },
            useHTML: true
         },
         plotOptions: {
            scatter: {
               marker: {
                  radius: 5,
                  states: {
                     hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                     }
                  }
               },
               states: {
                  hover: {
                     marker: {
                        enabled: false
                     }
                  }
               },
               tooltip: {
                  headerFormat: '<b>{series.name}</b><br>',
                  pointFormat: '{point.x}'
               }
            }
         },
         series: config.commandsSeries
      };
   }
   private handleError(error: any): Promise<any> {
      return Promise.reject(error.message || error);
   }
}
