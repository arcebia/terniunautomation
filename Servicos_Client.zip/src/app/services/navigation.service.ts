import { Injectable } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';

import { SharedService } from './shared.service';
import { BaseService } from './base.service';
import * as _ from 'lodash';
import { SsiService } from './ssi.service';

@Injectable({ providedIn: 'root' })
export class NavigationService {

   private currentUrl: string;
   private previousUrl: string;

   lastIdLine: any;
   reportUserConfig: any;
   userPreferencesParams = {
      id_line: 0,
      id_report: 0,
      report_config: '',
      columns_config: ''
   };
   userPreferences: any;
   username: any;

   constructor(
      private router: Router,
      private activatedRoute: ActivatedRoute,
      private sharedService: SharedService,
      private baseService: BaseService,
      private ssiService: SsiService,
   ) {
      this.currentUrl = this.router.url;
      router.events.subscribe(event => {
         if (event instanceof NavigationEnd) {
            this.previousUrl = this.currentUrl;
            this.currentUrl = event.url;
         }
      });

      this.sharedService.updateLastLineVisited.subscribe((idLine) => {
         if (idLine) {
            this.idLineChangeHandler(idLine);
         }
      });
   }

   public getPreviousUrl() {
      return this.previousUrl;
   }

   async idLineChangeHandler(idLine: any) {
      localStorage.clear();
      const userPreferences = {
         username: this.sharedService.user.getValue().username,
         lastLineVisited: idLine,
         favorites: []
      };
      const userPreferencesParams = {
         id_line: 0,
         id_report: 0,
         columns_config: '',
         report_config: JSON.stringify(userPreferences),
         username: this.sharedService.user.getValue().username
      };
      await this.baseService.setReportUserConfig(userPreferencesParams);
      localStorage.setItem('user_preferences', JSON.stringify(userPreferences));
   }

   navigationResolver(menuItem: any, mode: number, params?: any) {

      switch (mode) {
         case 1:
            /**
             * Reporte angular
             */
            if (params) {
               const urlToGo = `${params['module']}/${params['id_line']}/${menuItem.state}`; // ej: coating/1640001/production

               const queryParams = _.omit(params, ['module', 'id_line']);

               this.router.navigate([urlToGo], { queryParams });
            } else if (menuItem.state === 'under_construction') {
               this.router.navigate([menuItem.state]);
            }
            break;
         case 2:
            /**
             * Reporte iframe
             */
            let urlIframe: string;
            if (menuItem.url.includes('http')) {
               urlIframe = menuItem.url;
            } else {
               if (window.location.origin.includes('localhost')) {
                  urlIframe = `http://10.210.20.120/${menuItem.url}`;
               } else {
                  urlIframe = `${window.location.origin}/${menuItem.url}`;
               }
            }
            this.router.navigate([menuItem.state], {
               queryParams: {
                  id_line: params.id_line,
                  id_upper: params.id_upper,
                  url_iframe: urlIframe
               }
            });
            break;
         case 3:
            /**
             * LIN_SERVER ALARMS_SERVER
             */
            window.open(menuItem.url, '_blank');
            break;
         case 4:
            /**
             * Navega sio viejo
             */
            window.open(menuItem.url, '_self');
            break;
         default:
            break;
      }
   }

   navigationHandler() {
      /**
       * Detecta la navegacion (cambió la URL), si la navegación finalizó con éxito busca
       * el id_line como parametro de la ruta. Esto es necesario para poder conseguir parametros
       * de ruta para los componentes del layout que estan fuera del router-outlet, por ej el
       * sub-header que necesita la linea para armar el upper_menu
       */
      this.router.events.subscribe(navigationEvent => {
         if (navigationEvent instanceof NavigationEnd) {
            /**
             * La 3ra seccion de la url es el reporte, se almacena y actualiza en un Subject
             * para que cuando en el sidebar se selecciona una linea vaya al ultimo reporte.
             * Esto es para setear el selectedIdUpper en el caso de que se navegue directamente
             * desde una url sin usar sidebar y/o uppermenu
             */
            const urlReportSection = navigationEvent.url.split('/')[3];
            if (urlReportSection) {
               const report = urlReportSection.split('?')[0];
               if (report) this.sharedService.updateReport(report);
            }

            this.activatedRoute.firstChild.paramMap.subscribe(params => {
               const currentIdLine = params.get('id_line');
               /**
                * Válida que la linea haya cambiado, en el caso que se navegue entre reportes
                * de una misma linea evita enviar un nuevo valor al observable, de esta manera
                * los componentes que estan subscriptos evitan generar request a la api innecesarios
                * como por ej el subheader para armar el upper_menu y la info de linea, esto no cambia
                * mientras el usuario se mantenga en la misma linea
                */
               /**
                * Setea selectedIdLine cuando se navega desde una URL directamente, para el caso que
                * se navegue por el sidebar, es dicho sidebar quien se encarga de actualizar el
                * selectedIdLine subject
                */
               if (currentIdLine && currentIdLine !== this.lastIdLine) {
                  this.lastIdLine = currentIdLine;
                  this.sharedService.updateIdLine(currentIdLine);
               }
            });
         }
      });
   }

   initialRedirectionHandler() {
      // Redirecciona cuando no se especifica url
      if (this.router.routerState.snapshot.url === '/') {
         if (localStorage.getItem('user_preferences')) {
            this.userPreferences = JSON.parse(localStorage.getItem('user_preferences'));
            this.redirectUserByLocalStorage();
         } else {
            this.redirectUserByService();
         }
      }
   }

   async redirectUserByLocalStorage() {
      const upperMenu = await this.ssiService.getUpperMenuLine(this.userPreferences.lastLineVisited);
      const reditectInfo = await this.redirectInfoByUpperMenu(upperMenu);
      this.redirectionHandler(reditectInfo);
   }

   async redirectUserByService() {
      this.username = this.sharedService.user.getValue().username;
      this.userPreferencesParams = _.merge(this.userPreferencesParams, { username: this.username });
      this.reportUserConfig = await this.baseService.getReportUserConfig(this.userPreferencesParams);
      this.userPreferencesHandler();
   }

   async userPreferencesHandler() {
      if (this.reportUserConfig.userConfig.userPreferences) {
         this.userPreferences = this.reportUserConfig.userConfig.userPreferences;
         const upperMenu = await this.ssiService.getUpperMenuLine(this.userPreferences.lastLineVisited);
         const reditectInfo = await this.redirectInfoByUpperMenu(upperMenu);
         localStorage.setItem('user_preferences', JSON.stringify(this.userPreferences));
         this.redirectionHandler(reditectInfo);
      } else {
         // Setea la linea default como ultíma visitada
         await this.setInitialLastLineVisited();
         this.redirectUserByLocalStorage();
      }

   }

   async setInitialLastLineVisited() {
      localStorage.clear();
      const initialUserPreferences = {
         username: this.username,
         lastLineVisited: this.sharedService.IdIzquierdoDefault,
         favorites: []
      };
      const defaultUserPreferencesParams = _.merge(
         this.userPreferencesParams,
         {
            username: this.username,
            report_config: JSON.stringify(initialUserPreferences),
         }
      );

      await this.baseService.setReportUserConfig(defaultUserPreferencesParams);
      this.userPreferences = initialUserPreferences;
      localStorage.setItem('user_preferences', JSON.stringify(initialUserPreferences));
   }

   async redirectInfoByUpperMenu(upperMenuLine: any) {
      let redirectInfo = await _.find(
         upperMenuLine,
         (item: any) => item.id_superior === this.sharedService.IdSuperiorDefault
      );
      if (!redirectInfo) redirectInfo = await _.find(
         upperMenuLine,
         (item: any) => item.state && item.is_angular
      );
      if (!redirectInfo) redirectInfo = await _.find(
         upperMenuLine,
         (item: any) => item.url_target && item.url_target !== ''
      );

      return redirectInfo;
   }

   redirectionHandler(redirectItem: any) {

      if (redirectItem.state === 'reports') {
         const reportParams = {
            id_line: this.userPreferences.lastLineVisited,
            id_upper: redirectItem.id_superior,
            urlIframe: redirectItem.url
         };
         this.router.navigate(['./report'], { queryParams: reportParams });
      } else {
         let params;
         if (redirectItem.parameters && redirectItem.parameters !== '') {
            params = JSON.parse(this.JSONize(redirectItem.parameters));
         }
         this.navigationResolver(redirectItem, 1, params);
      }
   }

   JSONize(str) {
      return str
         // wrap keys without quote with valid double quote
         .replace(/([\$\w]+)\s*:/g, function (_, $1) { return '"' + $1 + '":'; })
         // replacing single quote wrapped ones to double quote
         .replace(/'([^']+)'/g, function (_, $1) { return '"' + $1 + '"'; });
   }

}





