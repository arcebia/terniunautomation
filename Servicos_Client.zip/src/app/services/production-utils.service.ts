import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { SharedService } from '../services/shared.service';

@Injectable({ providedIn: 'root' })
export class ProductionUtilsService {

   // private BaseURL = 'production-utils/';
   BaseURL = this.sharedService.BaseURL + 'production-utils/'; // URL to web api

   constructor(
      private http: HttpClient,
      public sharedService: SharedService
   ) { }

   getTreeTrace(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'tree_trace', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getTreeTraceDetail(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'tree_trace_detail', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getRollersMaterial(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'rollers_material', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   GetEssaysReport(params?): Promise<any> {
      return this.http.get(this.BaseURL + 'essay_report', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   private handleError(error: any): Promise<any> {
      return Promise.reject(error.message || error);
   }
}
