import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

import { SharedService } from './shared.service';

@Injectable({ providedIn: 'root' })
export class SsiService {

   SSIURL = this.sharedService.SSIURL;
   SSIBaseURL = this.sharedService.SSIURL + 'base/';
   SecurityURL = this.sharedService.SSIURL + 'security/';
   BaseURL = this.sharedService.BaseURL + 'base/';

   constructor(
      private http: HttpClient,
      public sharedService: SharedService
   ) { }

   getCurrentUser(): Promise<any> {
      return this.http.get(this.SSIURL + 'security/current_user', { withCredentials: true })
         .toPromise()
         .catch(this.handleError);
   }

   getApplications(): Promise<any[]> {
      return this.http.get(this.SSIBaseURL + 'applications', { withCredentials: true })
         .toPromise()
         .catch(this.handleError);
   }

   getLeftMenu(): Promise<any[]> {
      const params = new HttpParams({
         fromObject: {
            id_app: '2',
            id_left: '0'
         }
      });
      return this.http.get(this.SSIBaseURL + 'left_menu', { params: params, withCredentials: true })
         .toPromise()
         .catch(this.handleError);
   }

   getUpperMenuLine(id_left): Promise<any[]> {
      const params = new HttpParams({
         fromObject: {
            id_app: '2',
            id_left: id_left,
            id_upper_parent: '0'
         }
      });
      return this.http.get(this.SSIBaseURL + 'upper_menu', { params: params, withCredentials: true })
         .toPromise()
         .catch(this.handleError);
   }

   getInfoFromIdLine(id_line): Promise<any> {
      return this.http.get(this.BaseURL + 'line_info/' + id_line)
         .toPromise()
         .catch(this.handleError);
   }

   getPermissions(id_line, id_rols): Promise<any> {
      const params = {
         id_line: id_line,
         id_rols: id_rols
      };

      return this.http.get(this.SecurityURL + 'permissions', { params: params, withCredentials: true })
         .toPromise()
         .catch(this.handleError);
   }

   // getApplications(): Promise<any[]> {
   //    return this.http.get(this.BaseURL + 'applications', { withCredentials: true })
   //       .toPromise()
   //       .then(response => response.json())
   //       .catch(this.handleError);
   // }

   private handleError(error: any): Promise<any> {
      return Promise.reject(error.message || error);
   }

}
