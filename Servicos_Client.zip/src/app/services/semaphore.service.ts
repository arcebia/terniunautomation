import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class SemaphoreService {

   constructor() { }

   semaphoreType5(value: any, descRed: any) {
      if (value.toString().toLowerCase() === descRed.toString().toLowerCase()) {
         return {
            classInfo: 'red'
         };
      }
   }

   // MENOR al INFERIOR -> ROJO
   semaphoreType8(value: number, lowerLimit: number) {
      if (value < lowerLimit) {
         return {
            classInfo: 'red',
            tooltipClass: 'red',
            tooltipMsg: `Menor a Límite Inferior: ${lowerLimit} Sin Límite Superior`
         };
      } else {
         return {
            tooltipClass: 'green',
            tooltipMsg: `Mayor a Límite Inferior: ${lowerLimit} Sin Límite Superior`
         };
      }
   }

   // MENOR al INFERIOR -> ROJO
   // MAYOR al SUPERIOR -> ROJO
   // Medio en el rango -> AMARILLO
   semaphoreType13(diference: number, value: number, mode: string, externalLimit: number, internalLimit?: number) {
      if (internalLimit) {
         if (diference >= (internalLimit * -1) && diference <= internalLimit) {
            return {
               tooltipClass: 'green',
               tooltipMsg: `Dentro del Rango: ±${externalLimit} con respecto ${mode}: ${value}`
            };
         } else if (diference >= (externalLimit * -1) && diference <= externalLimit) {
            return {
               classInfo: 'yellow',
               tooltipClass: 'yellow',
               tooltipMsg: `Dentro del rango de especificación: ±${internalLimit} y ±${externalLimit} con respecto ${mode}: ${value}`
            };
         } else {
            return {
               classInfo: 'red',
               tooltipClass: 'red',
               tooltipMsg: `Fuera del rango de especificación: ±${externalLimit} con respecto ${mode}: ${value}`
            };
         }
      } else {
         if (diference >= (externalLimit * -1) && diference <= externalLimit) {
            return {
               tooltipClass: 'green',
               tooltipMsg: `Dentro del Rango: ±${externalLimit} con respecto ${mode}: ${value}`
            };
         } else {
            return {
               classInfo: 'red',
               tooltipClass: 'red',
               tooltipMsg: `Fuera del rango de especificación: ±${externalLimit} con respecto ${mode}: ${value}`
            };
         }
      }
   }



}
