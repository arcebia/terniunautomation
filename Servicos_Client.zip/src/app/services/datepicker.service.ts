import { Injectable } from '@angular/core';

import * as _ from 'lodash';
import * as moment from 'moment';

@Injectable({ providedIn: 'root' })
export class DatepickerService {

   constructor() { }

   dateConfig = {
      autoApply: true,
      timePicker24Hour: true,
      showDropdowns: true,
      locale: {
         format: 'DD/MM/YYYY',
         daysOfWeek: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sa'],
         monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
         cancelLabel: 'Cancelar',
         applyLabel: 'Aplicar'
      },
      timePickerIncrement: 30
   };

   formatHttp = 'YYYY-MM-DDTHH:mm:ss';
   formatDate = 'DD/MM/YYYY';
   formatDatetime = 'DD/MM/YYYY HH:mm';
   formatDatetimeseconds = 'DD/MM/YYYY HH:mm:ss';

   getConfig(config: any) {
      let options = _.clone(this.dateConfig);
      options = _.merge(options, config);

      options.timePickerIncrement = config.timePickerIncrement || 30;
      options.locale.format = config.timePicker ? this.formatDatetime : this.formatDate;
      options.locale.format = config.timePickerSeconds ? this.formatDatetimeseconds : options.locale.format;
      options.locale.cancelLabel = 'Cancelar';
      options.locale.applyLabel = 'Aplicar';

      return options;
   }

   getLocalDate(x, format) {
      // var t = Highcharts.dateFormat('%Y-%m-%d %H:%M:%S.%L', x);
      // var m = moment(t).toArray();
      // var u = new Date(m[0], m[1], m[2], m[3], m[4], m[5], m[6]);
      // var d = moment.unix(u.valueOf());
      return moment.unix(x).format(format);
   }

   getUTCDate(x) {
      const m = moment.unix(x).toArray();
      return Date.UTC(m[0], m[1], m[2], m[3], m[4], m[5], m[6]);
   }

   getUnixToUTCDate(x) {
      const m = moment.unix(x).toArray();
      return Date.UTC(m[0], m[1], m[2], m[3], m[4], m[5], m[6]);
   }

   getLocalToUTCDate(x) {
      const m = moment(x).toArray();
      return Date.UTC(m[0], m[1], m[2], m[3], m[4], m[5], m[6]);
   }

}
