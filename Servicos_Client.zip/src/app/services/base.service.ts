import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import * as _ from 'lodash';

import { SharedService } from './shared.service';

@Injectable({ providedIn: 'root' })
export class BaseService {

   BaseURL = this.sharedService.BaseURL + 'base/';

   constructor(
      private http: HttpClient,
      public sharedService: SharedService
   ) { }

   getDomainUser(): Promise<any> {
      return this.http.get(this.BaseURL + 'current_domain_user/')
         .toPromise()
         .catch(this.handleError);
   }

   getMultiHeaders(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'get_multiheader_columns', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getShifts(idLine): Promise<any> {
      return this.http.get(this.BaseURL + 'shifts/' + idLine)
         .toPromise()
         .catch(this.handleError);
   }

   getCurrentShift(idLine): Promise<any> {
      return this.http.get(this.BaseURL + 'shift/' + idLine.toString())
         .toPromise()
         .catch(this.handleError);
   }

   getReportColumns(params): Promise<any> {
      return this.http.get(this.BaseURL + 'report_columns', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getReportConfig(params): Promise<any> {
      return this.http.get(this.BaseURL + 'report_config', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getGenericReportConfig(params): Promise<any> {
      return this.http.get(this.BaseURL + 'generic_report_config', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getReportUserConfig(params): Promise<any> {
      return this.http.get(this.BaseURL + 'report_user_config', { params: params })
         .toPromise()
         .then((res: any) => {
            const config: any = {
               defaultConfig: {},
               userConfig: {},
            };
            if (Array.isArray(res.DefaultConfig) && res.DefaultConfig.length > 0) {
               const defaultConfig: any = res.DefaultConfig[0];
               if (defaultConfig.id_line && defaultConfig.id_line !== '') config.defaultConfig.idLine = defaultConfig.id_line;
               if (defaultConfig.id_report && defaultConfig.id_report !== '') config.defaultConfig.idReport = defaultConfig.id_report;
               if (defaultConfig.report_config && defaultConfig.report_config !== '') config.defaultConfig.reportConfig = JSON.parse(defaultConfig.report_config);
            }
            if (Array.isArray(res.UserConfig) && res.UserConfig.length > 0) {
               const userConfig: any = res.UserConfig[0];
               if (userConfig.username && userConfig.username !== '') config.userConfig.username = userConfig.username;
               if (userConfig.columns_config) {
                  if (Array.isArray(userConfig.columns_config)) {
                     if (userConfig.columns_config.length > 0) config.userConfig.columnsConfig = userConfig.columns_config;
                  } else if (userConfig.username !== '') {
                     config.userConfig.columnsConfig = JSON.parse(userConfig.columns_config);
                  }
               }
            }
            return config;
         })
         .catch(this.handleError);
   }

   getReportUserConfigOriginal(params): Promise<any> {
      return this.http.get(this.BaseURL + 'report_user_config', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   // getReportUserConfigLari(params): Promise<any> {
   //    return this.http.get(this.BaseURL + 'report_user_config', { params: params })
   //       .toPromise()
   //       .then((resp: any) => {
   //          const config = {
   //             DefaultConfig: {},
   //             UserConfig: {},
   //             columnsConfig: []
   //          };
   //          if (resp.DefaultConfig.length > 0) {
   //             if (!_.isEmpty(resp.DefaultConfig[0].report_config)) {
   //                config.DefaultConfig = JSON.parse(resp.DefaultConfig[0].report_config);
   //             }
   //             if (!_.isEmpty(resp.DefaultConfig[0].columns_config)) {
   //                config.columnsConfig = JSON.parse(resp.DefaultConfig[0].columns_config);
   //             }
   //          }
   //          if (resp.UserConfig.length > 0) {
   //             if (!_.isEmpty(resp.UserConfig[0].report_config)) {
   //                config.UserConfig = JSON.parse(resp.UserConfig[0].report_config);
   //             }

   //             if (!_.isEmpty(resp.UserConfig[0].columns_config)) {
   //                config.columnsConfig = JSON.parse(resp.UserConfig[0].columns_config);
   //             }
   //          }
   //          return config;
   //       })
   //       .catch(this.handleError);
   // }

   setReportUserConfig(body): Promise<any> {
      return this.http.post(this.BaseURL + 'report_user_config', body)
         .toPromise()
         .catch(this.handleError);
   }

   getSquadType(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'squad', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getGenericReportData(body): Promise<any> {
      return this.http.post(this.BaseURL + 'generic_report_data', body)
         .toPromise()
         .catch(this.handleError);
   }

   getGenericProgramExportExcel(params): Promise<any> {
      return this.http.get(this.BaseURL + 'export_generic_report', { params: params })
         .toPromise()
         .then((response: any) => {
            window.open(response.url);
         })
         .catch(this.handleError);
   }

   getGenericFiltersConfig(params): Promise<any> {
      return this.http.get(this.BaseURL + 'generic_report_filters', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getGenericReportFilterData(params): Promise<any> {

      return this.http.get(this.BaseURL + 'generic_report_filters_data', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   filterColumnsConfig(columnsConfigReport, columnsUser, considerTemplate = true) {
      _.each(columnsConfigReport, (o) => {
         const selected = _.isEmpty(columnsUser) || !_.isEmpty(_.find(columnsUser, { id_column: o.id_column }));
         // tslint:disable-next-line:triple-equals
         o.enable = o.to_show == 'True' && selected;
         if (!considerTemplate) {
            // tslint:disable-next-line:triple-equals
            o.enable = o.enable && o.has_template != 'True';
         }
      });
      return _.filter(columnsConfigReport, { enable: true });
   }

   private handleError(error: any): Promise<any> {
      return Promise.reject(error.message || error);
   }
}
