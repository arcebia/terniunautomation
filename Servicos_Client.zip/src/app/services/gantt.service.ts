import { Injectable }    from '@angular/core';
import * as moment from 'moment';
import 'rxjs/add/operator/toPromise';
import * as _ from "lodash";

@Injectable()
export class GanttService {
    // For Canvas steelworks
    CanvasSteelWork = {
        width: 1000,
        height: 100
    };

    yAxisBottomFactor: number = 0.64;
    MultilineStatus: number = 0;
    Type = {
        production: "PROD",
        programmation: "PROG",
        scheVsReal: "PVsR",
        continuesCasting: "ConC",
        flowProcess: "flowProc",
        workShopRollers: "WRollers",

    };
    Margin = {
        top: 0,
        right: 0,
        bottom: 0,
        left: 0
    };
    Canvas = {
        width: 1000,
        height: 150
    };
    DateFormat = {
        yearMonthDayHourMinuteSecond: "%Y-%m-%d %H:%M:%S"
    };
    TimeFormat = {
        hourMinuteSecond: "%H:%M:%S",
        hourMinute: "%H:%M",
        hour: "%H",
        minutes: "%M"
    };
    DataNames = {
        BarTopDataName: "Schedules",
        GanttDataName: "SteelCoils",
        BarBottomDataName: "Delays",
        XMarkDataName: "Defects"
    };
    Measures = {
        "PROD": {
            xOffsetPercent: 0.1,
            yOffset: 14,
            topLabelXOffset: 8,
            timeLabelXOffset: 8,
            yLabelAlignment: "start",
            chartWidthPercent: 0.825,
            minTimeTextWidthPercent: 0.04
        },
        "PROG": {
            xOffsetPercent: 0.1,
            yOffset: 14,
            topLabelXOffset: 8,
            timeLabelXOffset: 8,
            yLabelAlignment: "start",
            chartWidthPercent: 0.8,
            minTimeTextWidthPercent: 0.04
        },
        "PVsR": {
            xOffsetPercent: 0.1,
            yOffset: 14,
            topLabelXOffset: 8,
            timeLabelXOffset: 8,
            yLabelAlignment: "start",
            chartWidthPercent: 0.825,
            minTimeTextWidthPercent: 0.04
        },
        "ConC":{
          xOffsetPercent: 0.1,
          yOffset: 14,
          topLabelXOffset: 8,
          timeLabelXOffset: 8,
          yLabelAlignment: "start",
          chartWidthPercent: 0.825,
          minTimeTextWidthPercent: 0.035
        },
        "flowProc":{
          xOffsetPercent: 0.1,
          yOffset: 8,
          topLabelXOffset: 8,
          timeLabelXOffset: 8,
          yLabelAlignment: "start",
          chartWidthPercent: 0.825,
          minTimeTextWidthPercent: 0.04,
          yAxisLabelsOffset: 40
        },
        "WRollers":{
          xOffsetPercent: 0.1,
          yOffset: 8,
          topLabelXOffset: 8,
          timeLabelXOffset: 8,
          yLabelAlignment: "start",
          chartWidthPercent: 0.825,
          minTimeTextWidthPercent: 0.02,
          yAxisLabelsOffset: 40
        }

    };

    // constructor(private http: Http) { }

    getMeasure(config, size?): Object {
        var m = this.Measures[config.type];

        return {
            xOffset: config.width * (size ? 0.045 : m.xOffsetPercent),
            yOffset: m.yOffset,
            topLabelXOffset: m.topLabelXOffset,
            timeLabelXOffset: m.timeLabelXOffset,
            yLabelAlignment: m.yLabelAlignment,
            yAxisLabelsOffset: m.yAxisLabelsOffset ? m.yAxisLabelsOffset : "",
            // Width for the chart area (X Axis' width)
            chartWidth: config.width * m.chartWidthPercent,

            // Minimum width to show time arrows/labels (available space)
            minTimeTextWidth: config.width * m.minTimeTextWidthPercent
        }
    }

    parametersOk(config, data): boolean {
        if (config === undefined || config === null) {
            alert("Error: No configuration was provided.");
            return false;
        }

        if (data === undefined || data === null) {
            alert("Error: No data was provided.");
            return false;
        }

        return true;
    }

    narrowValue(minValue, maxValue, originalValue): any {
        if (originalValue >= minValue && originalValue <= maxValue) {
            return originalValue;
        } else {
            return originalValue < minValue ? minValue : maxValue;
        }
    }

    getYAxisSize(height): number {
        return height * 0.24;
    }

    escapeSpecialCharacters(s): string {
        if (s) {
            s = s.toString();
            return s.replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;");
        }

        return "";
    }

    drawArrow(xCoord, yCoord, start, up): string {
        var lengthY = up ? 15 : 8;
        var lengthX = xCoord + (start ? 8 : -8);
        var path = "M" + xCoord + "," + yCoord +
            " L" + xCoord + "," + (yCoord - lengthY) +
            " M" + xCoord + "," + (yCoord - lengthY) +
            " L" + lengthX + "," + (yCoord - lengthY);
        return path;
    }

    drawXMark(xCoord, yCoord): string {
        var xCoord2 = xCoord + 5;
        var yCoord2 = yCoord + 5;

        var path = "M" + xCoord + "," + yCoord +
            " L" + xCoord2 + "," + yCoord2 +
            " M" + xCoord + "," + yCoord2 +
            " L" + xCoord2 + "," + yCoord;
        return path;
    }

    getGanttTopClass(chartType, d): string {
        var className = "gt" + d.RowId;
        if (chartType === this.Type.production ) {
            className += " ganttTopType" + chartType + " " + (d.Status > 0 ? "fillColor" + d.RowGroupId : "fillColorStatus" + d.Status);
        } else if (chartType === this.Type.programmation) {
            className += " ganttTopType" + chartType + " fillColorCategory" + d.Category;
        } else if (chartType === this.Type.scheVsReal) {
            className += " ganttTopType" + chartType + " fillColor" + d.RowGroupId;
        }else if(chartType === this.Type.continuesCasting){
          className += " ganttTopType" + chartType + " " + "fillColor" + d.group_id ;
        }

        return className;
    }

    getTooltip(rows: any[]): string {
        if (rows && rows.length > 0) {
            var template = '<table class="tooltip-table">';
            template += '<tr><td colspan="2" nowrap class="header">' + this.escapeSpecialCharacters(rows[0].Key + " " + rows[0].Value) + '</td></tr>';
            var showTooltip = false;
            rows.forEach((d, r) => {

                if (r > 0 && d.Tooltip && d.Key && d.Value) {
                    showTooltip = true;
                    template += '<tr><td class="content-title">' + this.escapeSpecialCharacters(d.Key) +
                        '</td><td class="content-value">' + this.escapeSpecialCharacters(d.Value) + '</td></tr>';
                }
            })

            template += '</table>';
            if (showTooltip) {
                return template;
            }
        }
    }

    setTooltipOverAditionalData(d3, svgGanttId, data){
      // var x = 0;
      // var y = 0;
      this.setTooltipOver(d3, svgGanttId, data );

    }
    // Determines the position where the tooltip will be displayed when the mouse pointer is over
    // Mouse pointer coordinates are the default position
    setTooltipOver(d3, svgGanttId, data, position? , isProgVsReal? ) {
        var x = 0;
        var y = 0;

        var tooltipDiv = d3.select("#tooltip-" + svgGanttId);
        tooltipDiv.html(this.getTooltip(data));

        if (position) {
            var tooltipRect = tooltipDiv[0][0].getBoundingClientRect();

            x = position.x - (tooltipRect.width / 2);
            y = position.y - tooltipRect.height * position.vOffsetPercentage;
        } else {
            x = d3.event.pageX - 50;
           if(window.innerHeight - d3.event.pageY < 240 )
                y = d3.event.pageY - 150;
            else
                y = d3.event.pageY + 25
        }

        let ToolTipWidth = 0;
        let ToolTipHeight = 0;

        if ( tooltipDiv && tooltipDiv._groups && tooltipDiv._groups.length > 0 && tooltipDiv._groups[0].length > 0 ) {
            ToolTipWidth = (tooltipDiv._groups[0][0].getBoundingClientRect()).width ;
            ToolTipHeight = (tooltipDiv._groups[0][0].getBoundingClientRect()).height ;
        }

        if ( isProgVsReal && svgGanttId.indexOf("Prog") > 0 ) {
            x = x + ToolTipWidth / 3 ;
            y = y - 2 * ToolTipHeight / 3 ;
            if ( window && window.innerWidth && ( 15 + x + ToolTipWidth >= window.innerWidth ) ) {
                x = x - ToolTipWidth - ToolTipWidth / 4 ;
            }
        }

        if ( window && window.innerWidth && ( 15 + x + ToolTipWidth >= window.innerWidth ) ) {
            x = window.innerWidth - ToolTipWidth - 25 ;
        }

        tooltipDiv.style("left", x + "px").style("top", y + "px");
        tooltipDiv.transition().duration(200).style("opacity", 1);

    }

    // Hides the tooltip when the mouse is out
    setTooltipOut(d3, svgGanttId) {
        var tooltipDiv = d3.select("#tooltip-" + svgGanttId);
        tooltipDiv.transition().duration(500).style("opacity", 0);
    }

    // Contains the logic to associate tooltips between two charts
    // when the mouse pointer is over any top/bottom rectangle
    // Also, associates bottom gantt mouseover event to the top gantt one
    ganttOver(d3, config, data) {

        /* Show Related Items Prog vs Real */
        if ( config.type == this.Type.scheVsReal ) {

            if ( data.IdInputMaterial && data.IdInputMaterial != 0 ) {
                let item = document.querySelectorAll("rect[input_material=\"" + data.IdInputMaterial + "\"]");
                let show_all = 0 ;
                if ( config.svgGanttId && config.svgGanttId.indexOf ("Prog") > 0  )
                {
                    show_all = 1 ;
                }

            _.forEach(item,d => {
                    if (d.id.indexOf ("gt") >= 0 )
                    {
                        if ( show_all || d.id.indexOf ("Prog") > 0 ) {
                            d.setAttribute("style","fill: #FFFF00");
                        }
                    }
                });
            }
        }



        var topBars = d3.selectAll(".ganttTopType" + config.type)
            .each(function(d) {
                var topBar = d3.select(this);
                topBar.attr("class", topBar.attr("class").replace(/ ganttTopHover/g, ""));
            });
        var element = d3.selectAll("#gt-" + config.svgGanttId + "-" + data.RowId);


        if (config.relatedSvgGanttId) {
            var svgCanvasRect = d3.select("#div-" + config.svgGanttId)[0][0].getBoundingClientRect();
            var relatedSvgCanvasRect = d3.select("#div-" + config.relatedSvgGanttId)[0][0].getBoundingClientRect();
            var isOnTop = svgCanvasRect.top < relatedSvgCanvasRect.top;

            this.setTooltipOver(
                d3,
                config.svgGanttId,
                data.Details, {
                    x: svgCanvasRect.left + parseInt(element.attr("x")),
                    y: svgCanvasRect.top + (isOnTop ? 0.4 : 0.88) * config.height ,
                    vOffsetPercentage: isOnTop ? 1 : 0
                });

            var relatedElement = d3.selectAll("#gt-" + config.relatedSvgGanttId + "-" + data.RowId);
            relatedElement.attr("class", relatedElement.attr("class") + " ganttTopHover");

            this.setTooltipOver(
                d3,
                config.relatedSvgGanttId,
                relatedElement.data()[0].Details, {
                    x: relatedSvgCanvasRect.left + parseInt(relatedElement.attr("x")),
                    y: relatedSvgCanvasRect.top + (isOnTop ? 0.88 : 0.4) * config.height,
                    vOffsetPercentage: isOnTop ? 0 : 1
                });
        } else {
            if ( config.type == this.Type.scheVsReal ) {
                this.setTooltipOver(d3, config.svgGanttId, data.Details, null , 1);
            }
            else {
                this.setTooltipOver(d3, config.svgGanttId, data.Details );
            }

        }

        // Executes function specified as a hover action
        this.onHoverAction("Gantt", config.hoverActions, data, "over");
    }

    // Hides the tooltip when the mouse is out of top/bottom gantt
    ganttOut(d3, config, data) {
        var element;
        if(data.RowId){
          element = d3.selectAll("#gt-" + config.svgGanttId + "-" + data.RowId );
        }else{
          element = d3.selectAll("#gt-" + config.svgGanttId);
        }
        element.attr("class", element.attr("class").replace(/ ganttTopHover/g, ""));
        this.setTooltipOut(d3, config.svgGanttId);

        if (config.relatedSvgGanttId) {
            element = d3.selectAll("#gt-" + config.relatedSvgGanttId + "-" + data.RowId);
            element.attr("class", element.attr("class").replace(/ ganttTopHover/g, ""));
            this.setTooltipOut(d3, config.relatedSvgGanttId);
        }

        // Executes function specified as a hover action
        this.onHoverAction("Gantt", config.hoverActions, data, "out");


        if (config.type == this.Type.scheVsReal && data.IdInputMaterial && data.IdInputMaterial && data.IdInputMaterial != 0 ) {
           let item = document.querySelectorAll("rect[input_material=\"" + data.IdInputMaterial + "\"]");

            _.forEach(item, d => {
                if (d.id.indexOf ("gt") >= 0 )
                    d["style"].fill="";
            });
        }

    }

    // You can set up two javascript functions to be executed
    // when an event "mouseover" and/or "mouseout" is triggered
    // service custom JS functions will receive one parameter: the item data (d)
    onHoverAction(position, actions, d, event) {
        if (actions && position) {
            var action = actions[position];
            if (action) {
                if ("over" === event && action.overAction) {
                    action.overAction(d);
                }

                if ("out" === event && action.outAction) {
                    action.outAction(d);
                }
            }
        }
    }

    fixValueToLimits(d, config) {
        var start = moment(config.timeStart);
        var end = moment(config.timeEnd);

        var s = moment(d.StartTime)
        var e = moment(d.EndTime)

        if (s.isBefore(start)) {
            s = start;
        }

        if (e.isAfter(end)) {
            e = end;
        }
        d.durationMs = e.diff(s);
    }
}
