import { Injectable } from '@angular/core';

import { Subject } from 'rxjs/internal/Subject';

import * as _ from 'lodash';
import * as $ from 'jquery';
const Highcharts = require('highcharts');

import { CurvesService } from './curves.service';

@Injectable({ providedIn: 'root' })
export class ChartService {

   clickX = 0;
   plotLines: any[] = [];
   private dragPlotLine = new Subject<any>();
   dragPlotLine$ = this.dragPlotLine.asObservable();

   constructor(
      private curvesService: CurvesService
   ) { }

   destroyCursors(chart_object, rightPlotLine, leftPlotLine) {
      if (!chart_object || !chart_object.xAxis) return;
      const xAxis = chart_object.xAxis[0];
      xAxis.removePlotLine(rightPlotLine.id);
      xAxis.removePlotLine(leftPlotLine.id);
      rightPlotLine.hasPlotLine = false;
      leftPlotLine.hasPlotLine = false;
      rightPlotLine.value = {};
      leftPlotLine.value = {};
   }

   updateExtremes($event, charts) {
      const thisChart = $event.chart;
      /**
       * INSTALAR HIGHCHARTS
       */
      Highcharts.each(charts, function (chart) {
         if (chart !== thisChart) {
            if (chart.xAxis[0].setExtremes) { // It is null while updating
               chart.xAxis[0].setExtremes(
                  $event.e.min,
                  $event.e.max,
                  undefined,
                  false,
                  { trigger: 'syncExtremes' }
               );
            }
         }
      });
   }

   syncCursorLine(charts, e, allCharts?, sectionsCurvesOutput?) {
      let listCharts = [];
      if (allCharts) {
         _.each(allCharts, (o) => {
            _.each(o, (d) => {
               listCharts = _.concat(listCharts, d.chart);
            });
         });
      } else {
         listCharts = charts;
      }
      let chart, point, i, event, pointMoved, chartMoved, materialMoved = null, material;
      const id = e.currentTarget.id;

      _.each(allCharts, (o) => {
         if (!materialMoved) {
            materialMoved = this.findMaterial(allCharts, id);
         } else if (!pointMoved) {
            chartMoved = materialMoved.chart[0];
            event = chartMoved.pointer.normalize(e.originalEvent);
            pointMoved = chartMoved.series[0].searchPoint(event, true);
         }
      });
      for (i = 0; i < listCharts.length; i = i + 1) {
         chart = listCharts[i];
         event = chart.pointer.normalize(e.originalEvent);
         // Get the hovered point
         point = chart.series[0].searchPoint(event, true);
         if (allCharts) {
            const isSameMaterial = e.currentTarget.id.indexOf(chart.userOptions.material) > -1;
            material = this.findMaterial(allCharts, chart.userOptions.material);
            if (!isSameMaterial) {
               if (pointMoved) {
                  point = null;
                  const relation = this.curvesService.getRelationValues(chartMoved.series[0].processedXData, materialMoved, chart.series[0].processedXData, pointMoved.index, sectionsCurvesOutput, material);
                  let indexData = -1;
                  for (let index = 0; index < chart.series[0].processedXData.length; index++) {
                     const element = chart.series[0].processedXData[index];
                     if (element >= relation.valueCurrentPlotLeft) {
                        indexData = index;
                        break;
                     }
                  }
                  if (indexData > -1 && relation.valueCurrentPlotLeft > -1 && !_.isNaN(chart.series[0].points[indexData].y)) {
                     chart.series[0].points[indexData].highlight(e);
                  }
               }
            } else if (point) {
               point.highlight(e);
            }
         } else if (point) {
            point.highlight(e);
         }
      }
   }

   findMaterial(allCharts, id) {
      let material = null;
      _.each(allCharts, (o) => {
         if (!material) {
            material = _.find(o, (d) => {
               return id.indexOf(d.id_exit) > -1;
            });
         }
      });
      return material;
   }

   managePlotLine(plotLine, axis, value, chart) {
      if (plotLine.hasPlotLine) {
         axis.removePlotLine(plotLine.id);
      } else {
         plotLine.hasPlotLine = !plotLine.hasPlotLine;
      }
      const newPlotLine = axis.addPlotLine({
         value: value,
         width: 3,
         color: plotLine.color,
         id: plotLine.id,
         zIndex: 5
      });

      if (!newPlotLine || !newPlotLine.svgElem) return;
      newPlotLine.svgElem.attr({
         id: plotLine.id
      })
         .css({
            'cursor': 'pointer'
         })
         .translate(0, 0)
         .on('mousedown', (e) => {
            $(document).bind({
               'mousemove.line': (e) => {
                  const newTranslation = e.pageX - this.clickX;
                  newPlotLine['svgElem'].translate(newTranslation, 0);
               },
               'mouseup.line': (e) => {
                  const xData = chart.series[0].xData;
                  const valueX = newPlotLine['options'].value;
                  const newTranslation = newPlotLine['svgElem'].translateX;
                  let newValue = axis.toValue(newTranslation) - axis.toValue(0) + valueX;
                  let index = 0;
                  for (let i = 1; i < xData.length - 1; i++) {
                     if (xData[i] >= newValue && xData[i - 1] <= newValue) {
                        if (xData[i] - newValue >= xData[i - 1] - newValue) {
                           newValue = xData[i - 1];
                           index = i - 1;
                           break;
                        } else {
                           newValue = xData[i];
                           index = i;
                           break;
                        }
                     }
                  }
                  _.each(chart.series, (d) => {
                     if (d.data[index] != null) {
                        const name = d.name;
                        plotLine.value.list[name] = d.data[index].y;
                     }
                  });
                  plotLine.value.x = newValue;
                  this.updateDragPlotLine(plotLine);
                  $(document).unbind('.line');
               }
            });
            this.clickX = e.pageX - newPlotLine['svgElem'].translateX;
         });
   }

   updateDragPlotLine(event: any) {
      this.dragPlotLine.next(event);
   }
}
