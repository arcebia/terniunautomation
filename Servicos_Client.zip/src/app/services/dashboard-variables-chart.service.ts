import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

import * as _ from 'lodash';
import * as moment from 'moment';

@Injectable({ providedIn: 'root' })
export class DashboardVariablesChartService {
   private boardIdGroup: any;
   private boardDataTime: any;
   private dataType$: BehaviorSubject<any> = new BehaviorSubject('M');

   private curveInfoSource = new Subject<any>();
   curveInfo$ = this.curveInfoSource.asObservable();

   private boardSource = new Subject<any>();
   board$ = this.curveInfoSource.asObservable();

   private rangeList: any;
   private selectedRange: any;
   private dataType: any = 'M';

   constructor() { }

   // BS with data

   // Board Data
   updateBoardDataTime() {
      this.boardDataTime = moment();
   }

   updateBoard(value) {
      this.boardSource.next(value);
      this.boardIdGroup = value.summary.id_group;
   }

   updateCurveInfo(value) {
      this.curveInfoSource.next(value);
   }

   getDataType() {
      return this.dataType$;
   }

   updateDataType(dataType) {
      this.dataType = dataType;
      this.dataType$.next(dataType);
   }

   getRangeList() {
      return this.rangeList;
   }

   updateRangeList(range_list) {
      this.rangeList = range_list;
   }

   getSelectedRange() {
      return this.selectedRange;
   }

   updateSelectedRange(selected_range) {
      this.selectedRange = selected_range;
   }

   // Process Dashboard
   isCurrentGroup(id_group) {
      const duration = moment
         .duration(moment().diff(this.boardDataTime))
         .asMinutes();
      const isValidData = _.isEqual(duration, 0) ? false : duration < 5;

      return _.isEqual(this.boardIdGroup, id_group) && isValidData;
   }

   // BoardData

   processBoardData(data, parent_id) {
      data = _.filter(data, item => {
         return !_.isEqual(parent_id, _.get(item, 'id_parent'));
      });
      _.forEach(data, item => {
         _.set(item, 'status', this.getStatusLabel(_.get(item, 'semaphore_1')));
      });
      return data;
   }

   // DatailData

   processDashboardDetailDefects(defects) {
      if (defects) {
         const def = [];
         _.forEach(defects, defect => {
            def.push({
               value: _.toNumber(_.get(defect, 'quantity')),
               series: {
                  color: '#f58549',
                  y: _.toNumber(_.get(defect, 'quantity'))
               },
               description: _.get(defect, 'defect')
            });
         });
         return def;
      } else {
         return;
      }
   }

   // CurvesData
   chartConfig(data) {
      this.rangeList = _.get(data, 'listRange', []);

      const decimals = _.isEmpty(_.get(data, 'settingConfig.config.decimals'))
         ? undefined
         : _.toNumber(_.get(data, 'settingConfig.config.decimals'));

      const graphOutput: any = {
         status: this.getStatusLabel(_.get(data, 'semaphore', 4)),
         withOptions: true,
         config: {
            start_date: _.get(data, 'start_date'),
            end_date: _.get(data, 'end_date'),
            data_type: this.dataType,
            id: _.get(data, 'id'),
            id_line: _.get(data, 'data[0].id_line')
         },
         graphData: {
            series: [],
            tooltip: {
               useHTML: true,
               formatter: function () {
                  const point = this.points[0].point;
                  if (!point.material_in) return false;
                  const aditional_info = point.aditional_info;
                  const production_date = moment(_.get(point, 'production_date')).format('DD/MM/YYYY HH:mm');
                  const limits = point.min_limit ? (point.min_limit + ' - ' + point.max_limit) : 'Sin Límites';
                  let tooltip = _.get(point, 'material_out') + '<br/><small>' + production_date + '</small><br/> <table class="full-width">';
                  _.each(aditional_info, (o) => {
                     tooltip += '<tr><td>' + o.name + '</td><td class="text-right">' + o.value + '</td></tr>';
                  });
                  tooltip += '<tr><td>Valor:</td> <td class="text-right"><b>' + this.y.toFixed(2) + '</b> (' + limits + ')</td></tr>';
                  if (this.points.length === 3)
                     tooltip += '<tr><td>Laboratorio:</td> <td class="text-right"><b>' + (this.points[2].y || '').toFixed(2) + '</b></td></tr>';
                  tooltip += '</table>';
                  return tooltip;
               },
               shared: true
            }
         }
      };

      graphOutput.title = data.title;
      graphOutput.config.hasRangeOptions = data.hasRangeOptions;
      graphOutput.config.withShifts = !!data.withShifts;
      graphOutput.config.withSettings = !!data.withSettings;

      let dataOutput: any = _.map(_.get(data, 'data'), (item: any) => {
         // if (item.value != "") {
         return {
            y: _.isEmpty(_.get(item, 'value')) ? null : _.toNumber(_.get(item, 'value')),
            material_in: _.get(item, 'material_in'),
            material_out: _.get(item, 'material_out'),
            production_date: _.get(item, 'date_production'),
            max_limit: _.get(item, 'max_limit'),
            min_limit: _.get(item, 'min_limit'),
            aditional_info: _.get(item, 'aditional_info') ? JSON.parse(_.get(item, 'aditional_info')) : []
         };
         // }
      });
      let xLabel: any = _.map(_.get(data, 'data'), 'material_out');
      let plotOptions = {};

      if (_.isEqual(this.dataType, 'T') && data.hasTag) {
         plotOptions = {
            series: {
               lineWidth: 1,
               marker: {
                  enabled: true,
                  symbol: 'circle',
                  radius: 1.5
               },
               turboThreshold: 0
            }
         };
         dataOutput = _.get(data, 'data');
         xLabel = _.get(data, 'xLabel');
         _.set(graphOutput, 'config.chartType', 'scatter');
         const tFormatter = {
            formatter: function () {
               const ret = (!_.isNaN(_.toNumber(this.x)) ? this.x.toFixed(decimals) : '') + '<br/> <b>' + this.y.toFixed(decimals) + '</b>';
               return ret;
            }
         };
         _.set(graphOutput, 'graphData.tooltip', tFormatter);
      } else {
         plotOptions = {
            series: {
               marker: {
                  enabled: true,
                  symbol: 'circle',
                  radius: 2
               },
               lineWidth: 1,
               turboThreshold: 0
            }
         };
         graphOutput.graphData.limits = this.getLimits(data.data);
      }
      graphOutput.config.plotOptions = plotOptions;
      if (_.get(data, 'settingConfig')) {
         _.set(graphOutput, 'settingConfig', _.get(data, 'settingConfig'));
      }

      graphOutput.graphData.series.push({
         type: 'line',
         data: dataOutput,
         showInLegend: false,
         color: 'rgb(54,111,167)',
         zIndex: 1
      });
      graphOutput.graphData.series.push({
         name: 'Range',
         id: 'limits',
         data: this.getRange(_.get(data, 'data')),
         type: 'arearange',
         lineColor: '#d9534f',
         linkedTo: ':previous',
         color: '#E0F1D4',
         fillOpacity: 0.3,
         zIndex: 0,
         marker: {
            enabled: false,
            states: {
               hover: {
                  enabled: false
               }
            }
         }
      });
      _.set(graphOutput, 'graphData.xLabel', xLabel);

      if (_.get(data, 'originalDates')) {
         _.set(graphOutput, 'config.originalDates', _.get(data, 'originalDates'));
      }

      return graphOutput;
   }

   private getRange(data) {
      const ranges = [];
      _.forEach(data, item => {
         const min_limit = _.isEmpty(_.get(item, 'min_limit'))
            ? null
            : _.toNumber(_.get(item, 'min_limit'));
         const max_limit = _.isEmpty(_.get(item, 'max_limit'))
            ? null
            : _.toNumber(_.get(item, 'max_limit'));

         ranges.push([min_limit, max_limit]);
      });
      return ranges;
   }

   private getLimits(data) {
      let limits;
      const max_limits = _.map(_.map(data, 'max_limit'), _.toNumber);
      const min_limits = _.map(_.map(data, 'min_limit'), _.toNumber);

      if (!_.isEmpty(max_limits) || !_.isEmpty(min_limits)) {
         limits = {
            min: _.min(min_limits),
            max: _.min(max_limits)
         };
      }

      return limits;
   }

   private getStatusLabel(status) {
      switch (status) {
         case '1':
            return 'good';
         case '2':
            return 'warning';
         case '3':
            return 'danger';
         default:
            return status;
      }
   }
}
