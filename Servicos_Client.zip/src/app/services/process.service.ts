import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import * as _ from 'lodash';

import { SharedService } from './shared.service';

@Injectable({ providedIn: 'root' })
export class ProcessService {

   BaseURL = this.sharedService.BaseURL + 'process/';

   constructor(
      private http: HttpClient,
      public sharedService: SharedService
   ) { }

   getCoverTypes(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'cover_types', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   getSubstratumObjetive(params): Promise<any[]> {
      return this.http.get(this.BaseURL + 'sustratum_objective', { params: params })
         .toPromise()
         .catch(this.handleError);
   }

   private handleError(error: any): Promise<any> {
      return Promise.reject(error.message || error);
   }

}
