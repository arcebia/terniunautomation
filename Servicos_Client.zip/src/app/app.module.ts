// Angular Modules
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
// Routing Module
import { AppRoutingModule } from './app-routing.module';
// 3° Party Modules
import { ToastyModule } from 'ng2-toasty';
// Root Component
import { AppComponent } from './app.component';
// Custom Modules
import { LayoutModule } from './layout/layout.module';


@NgModule({
   declarations: [
      AppComponent
   ],
   imports: [
      BrowserModule,
      HttpClientModule,
      AppRoutingModule,
      LayoutModule,
      ToastyModule.forRoot()
   ],
   exports: [],
   providers: [],
   bootstrap: [AppComponent]
})
export class AppModule { }



