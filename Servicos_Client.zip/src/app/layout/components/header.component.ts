import { Component, OnInit } from '@angular/core';

import { environment } from 'src/environments/environment';

import { SsiService } from 'src/app/services/ssi.service';
import { SharedService } from 'src/app/services/shared.service';

@Component({
   selector: 'header',
   templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit {

   userName: any;
   location = environment.Location;
   applications;
   fromN2A = this.sharedService.fromN2A;

   constructor(
      private ssiService: SsiService,
      public sharedService: SharedService,
   ) { }

   ngOnInit() {
      this.ssiService.getCurrentUser()
         .then((res: any) => {
            // this.userFetched.emit(resp);
            this.userName = res.name;
            this.sharedService.user.next(res);
         });

      this.ssiService.getApplications()
         .then((resp) => {
            this.applications = resp;
         });
   }


   selectApp(app) {
      let url = app.url.split('IIII').join(this.sharedService.selectedIdLine.getValue());
      url = url.replace('SSSS', '2');
      window.open(url, '_blank');
   }

}
