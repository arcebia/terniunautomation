import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import * as _ from 'lodash';

import { SsiService } from 'src/app/services/ssi.service';
import { SharedService } from 'src/app/services/shared.service';
import { NavigationService } from 'src/app/services/navigation.service';

@Component({
   selector: 'sub-header',
   templateUrl: './sub-header.component.html',
   styles: []
})
export class SubHeaderComponent implements OnInit {

   selectedProcess: any;
   selectedPlant: any;
   selectedLine: any;

   infoLineFetched = false;
   lastReport;

   idLine: number;
   idUpper: number;
   parent: any[];
   isOpenSideBar = false;
   reportsAngular: string[];
   isCollapsed = true;
   isSummaryState: boolean;
   isLocalhost: boolean;
   isDev: boolean;
   currentUpperMenuItem: any;
   hideMenu = false;

   constructor(
      private router: Router,
      private ssiService: SsiService,
      private navigationService: NavigationService,
      public sharedService: SharedService
   ) { }

   ngOnInit() {
      this.sharedService.isOpenSideBar.subscribe(isOpen => {
         this.isOpenSideBar = isOpen;
      });

      this.sharedService.selectedIdLine.subscribe(idLine => {
         if (idLine) {
            this.getUpperMenu(idLine);
            this.getLineInfo(idLine);
         }
      });
   }

   toggleSideBar() {
      this.sharedService.toggleSideBar();
   }

   getUpperMenu(idLine) {
      this.ssiService.getUpperMenuLine(idLine)
         .then((resp) => {
            /**
             * Se encarga de setear el selectedIdUpper en el caso de que se navegue directamente desde
             * una URL, sin usar sidebar y/o uppermenu, matcheando el reporte actual con el state
             */
            if (!this.sharedService.selectedIdUpper.getValue()) {
               const upper = _.find(resp, (report: any) => {
                  return this.sharedService.selectedReport.getValue() === report.state && report.id_superior_padre !== 0;
               });
               if (upper) {
                  this.sharedService.updateIdUpper(upper.id_superior.toString());
               }
            }
            this.parent = resp;
            _.each(this.parent, (item) => {
               item.childs = _.filter(resp, { id_superior_padre: item.id_superior });
            });
            this.parent = _.filter(this.parent, (parent: any) => parent.id_superior_padre === 0);

            _.each(this.parent, (o) => {
               let list = [];
               o.childs = _.sortBy(o.childs, [function (o) { return o.orden; }]);
               _.each(o.childs, (i: any) => {
                  i.level_menu = 1;
                  list = _.concat(list, i);

                  if (i.childs.length > 0) {
                     i.childs = _.sortBy(i.childs, [function (o) { return i.orden; }]);
                     _.each(i.childs, (j: any) => {
                        j.level_menu = 2;
                        list = _.concat(list, j);

                        if (j.childs.length > 0) {
                           j.childs = _.sortBy(j.childs, [function (o) { return j.orden; }]);
                           _.each(j.childs, (k: any) => {
                              k.level_menu = 3;
                              list = _.concat(list, k);

                              if (k.childs.length > 0) {
                                 list = _.concat(list, k.childs);
                                 k.childs = _.sortBy(k.childs, [function (o) { return k.orden; }]);
                                 _.each(k.childs, (l: any) => {
                                    l.level_menu = 4;
                                 });
                              }
                           });
                        }
                     });
                  }
               });
               o.list = list;
            });

         });
   }

   getLineInfo(idLine) {
      this.ssiService.getInfoFromIdLine(idLine)
         .then((res) => {
            this.selectedLine = res;
            this.selectedPlant = res.plant;
            this.selectedProcess = res.process;
            if (res.id_line === '1544002') {
               this.sharedService.updateIdProcess('14');
            } else {
               this.sharedService.updateIdProcess(res.id_process);
            }
            this.infoLineFetched = true;
         });
   }

   selectUpper(menuItem) {
      if (_.isEmpty(menuItem)) return;

      console.log(menuItem);

      let params: any;
      if (menuItem.parameters) {
         params = JSON.parse(this.JSONize(menuItem.parameters));
      }

      if (menuItem.is_angular) {

         if (menuItem.state) {
            /**
             * Reporte angular
             */
            let mode: number;
            menuItem.state === 'reports' ? mode = 2 : mode = 1;
            this.navigationService.navigationResolver(menuItem, mode, params);
            this.sharedService.updateIdUpper(menuItem.id_superior.toString());
         } else {
            this.navigationService.navigationResolver(menuItem, 3);
         }
      } else {
         let mode: number;
         menuItem.state === 'reports' ? mode = 2 : mode = 4;
         this.navigationService.navigationResolver(menuItem, mode, params);
         this.sharedService.updateIdUpper(menuItem.id_superior.toString());
      }

      // if (menuItem.url_target) {

      //    this.router.navigateByUrl(menuItem.url_target);

      // } else {
      //    console.log(menuItem);
      //    if (menuItem.parameters && menuItem.state) {

      //       const queryParams = JSON.parse(this.JSONize(menuItem.parameters));
      //       this.router.navigate(
      //          ['/report'],
      //          {
      //             queryParams: {
      //                id_line: queryParams.id_line,
      //                id_upper: queryParams.id_upper,
      //                url_iframe: menuItem.url
      //             }
      //          }
      //       );
      //    } else {

      //       window.open(menuItem.url, '_blank');
      //    }
      // }
      // else {
      //    if (item.is_angular) {
      //       window.open(item.url, '_blank');
      //    } else {
      //       if (this.isDev || this.isLocalhost || item.url.indexOf('SIO_MOBILE') > -1) {
      //          this.goToCurrentProject(item);
      //       } else {
      //          this.goToMVP(item.id_superior);
      //       }
      //    }
      // }
   }

   JSONize(str) {
      return str
         // wrap keys without quote with valid double quote
         .replace(/([\$\w]+)\s*:/g, function (_, $1) { return '"' + $1 + '":'; })
         // replacing single quote wrapped ones to double quote
         .replace(/'([^']+)'/g, function (_, $1) { return '"' + $1 + '"'; });
   }




}
