import { Component, OnInit, ElementRef, Input } from '@angular/core';
import { Router } from '@angular/router';

import * as _ from 'lodash';

import { SsiService } from 'src/app/services/ssi.service';
import { SharedService } from 'src/app/services/shared.service';
import { NavigationService } from 'src/app/services/navigation.service';

@Component({
   selector: 'side-bar',
   templateUrl: './side-bar.component.html',
   host: { '(document:click)': 'clickOutside($event)', }
})
export class SideBarComponent implements OnInit {

   id_process: number;
   id_plant: number;
   id_line: number;

   // plant: string = null;
   // process: string = null;

   // search: string;
   isOpenSideBar: boolean;
   // currentState: any;

   leftMenuData: any = {};

   @Input() userFromApp: any;
   user: any;
   username: string;
   userPreferences: any;
   userConfigDefaultParams = {
      id_line: 0,
      id_report: 0,
      report_config: '',
      columns_config: ''
   };

   redirecTo: any;

   lastReport;

   img_root = 'assets/images/';
   processInfo = {
      'Mineral': { img: this.img_root + 'mineral.svg', path: 'mineral' },
      'Pellas': { img: this.img_root + 'pellets.svg', path: 'pellets' },
      'HRD': { img: this.img_root + 'hrd.svg', path: 'hrd' },
      'Reducción': { img: this.img_root + 'hrd.svg', path: 'hrd' },
      'Acería': { img: this.img_root + 'aceria.svg', path: 'steelworks' },
      'Laminación en Caliente': { img: this.img_root + 'lac.svg', path: 'hot_rolling_mill' },
      'Laminación en Frío': { img: this.img_root + 'laf.svg', path: 'cold_rolling_mill' },
      'Revestidos': { img: this.img_root + 'rev.svg', path: 'coating' },
      'Transformados': { img: this.img_root + 'trans1.svg', path: 'transformed' },
      'Embalaje': { img: this.img_root + 'embalaje.svg', path: 'packaging' },
      'Servicios': { img: this.img_root + 'serv.svg', path: 'services' },
      'Servicios y Energéticos': { img: this.img_root + 'serv.svg', path: 'services_energetics' },
      'Consolidado X Planta': { img: this.img_root + 'consolidado.svg', path: 'consolidated' },
      'Taller Rodillos': { img: this.img_root + 'taller1.svg', path: 'roller_workshop' },
      'Taller Cilindros': { img: this.img_root + 'taller1.svg', path: 'cylinder_workshop' },
      /**
       * BRASIL
       */
      'Redução': { img: this.img_root + 'hrd.svg', path: 'hrd' },
      'Aciaria': { img: this.img_root + 'aceria.svg', path: 'steelworks' },
      'Utilidades': { img: this.img_root + 'serv.svg', path: 'services' },
   };

   constructor(
      private router: Router,
      private _el: ElementRef,
      private ssiService: SsiService,
      private navigationService: NavigationService,
      public sharedService: SharedService,
   ) { }

   // Cierra el sidebar cuando detecta el evento click por fuera
   clickOutside(event) {
      if (this.sharedService.isIEorEdge.getValue()) {
         if ((event.clientY <= 50 || event.clientX >= 222) &&
            event.target.className !== 'material-icons' &&
            this.isOpenSideBar === true) {
            this.toggleSideBar();
         }
      } else {
         if (!_.includes(event.path, this._el.nativeElement) &&
            event.target.className !== 'material-icons' &&
            this.isOpenSideBar === true) {
            this.toggleSideBar();
         }
      }
   }

   // ngOnChanges(changes: SimpleChanges) {
   //    if (changes.userFromApp.currentValue) {
   //       this.user = changes.userFromApp.currentValue;
   //       this.username = this.user.username.toLowerCase();
   //       if (!this.$state.params.id_line) {
   //          this.redirectUserByPreferences();
   //       } else {
   //          this.userPreferences = {
   //             username: this.username,
   //             favorites: []
   //          };
   //          this.selectLine(this.$state.params.id_line);
   //       }
   //    }
   // }

   ngOnInit() {

      this.sharedService.selectedIdProcess.subscribe(idProcess => {
         this.id_process = idProcess;
      });

      this.sharedService.selectedIdPlant.subscribe(idPlant => {
         this.id_plant = idPlant;
      });

      this.sharedService.selectedIdLine.subscribe(idLine => {
         this.id_line = idLine;
      });

      this.sharedService.isOpenSideBar.subscribe(isOpen => {
         this.isOpenSideBar = isOpen;
      });

      this.getLeftMenu();
   }

   // async redirectUserByPreferences() {
   //    // Obtiene report_config del usuario
   //    const reportUserConfig: any = await this.baseService
   //       .getReportUserConfig(_.merge(this.userConfigDefaultParams, { username: this.username }));

   //    // Si el usuario no está en la DB
   //    if (!Array.isArray(reportUserConfig.UserConfig) ||
   //       !reportUserConfig.UserConfig.length ||
   //       !reportUserConfig.UserConfig[0].report_config) {

   //       // Obtiene upperMenu para la linea default
   //       const upperMenuDefaultLine = await this.ssiService.getUpperMenuLine(this.sharedService.IdIzquierdoDefault);

   //       // Obtiene la informacion para redireccionar
   //       const reditectInfo: any = await this.redirectInfoByLine(upperMenuDefaultLine);
   //       const params = JSON.parse(this.JSONize(reditectInfo.parameters));

   //       // Setea la linea default como ultíma visitada
   //       await this.setInitialLastLineVisited();

   //       // Redirecciona
   //       this.$state.go(reditectInfo.state, params);

   //    } else {
   //       // El usuario está en la DB
   //       this.userPreferences = JSON.parse(reportUserConfig.UserConfig[0].report_config);

   //       // Obtiene upperMenu para la linea
   //       const upperMenuLine = await this.ssiService.getUpperMenuLine(this.userPreferences.lastLineVisited);

   //       // Obtiene la informacion para redireccionar
   //       const reditectInfo: any = await this.redirectInfoByLine(upperMenuLine);

   //       localStorage.setItem('user_preferences', JSON.stringify(this.userPreferences));

   //       if (reditectInfo.parameters) {
   //          const params = JSON.parse(this.JSONize(reditectInfo.parameters));
   //          // Redirecciona
   //          this.$state.go(reditectInfo.state, params);
   //       } else {
   //          window.open(reditectInfo.url.trim(), '_blank');
   //       }


   //    }
   // }

   // async redirectInfoByLine(upperMenuLine: any) {
   //    let redirectInfo = await _.find(upperMenuLine, (item: any) => item.id_superior === this.sharedService.IdSuperiorDefault);
   //    if (!redirectInfo) redirectInfo = await _.find(upperMenuLine, (item: any) => (item.is_angular === 1 && item.parameters));
   //    if (!redirectInfo) redirectInfo = await _.find(upperMenuLine, (item: any) => item.url !== '');

   //    return redirectInfo;
   // }

   // async setInitialLastLineVisited() {
   //    localStorage.clear();
   //    const initialUserPreferences = {
   //       username: this.username,
   //       lastLineVisited: this.sharedService.IdIzquierdoDefault,
   //       favorites: []
   //    };
   //    await this.baseService.setReportUserConfig(_.merge(
   //       this.userConfigDefaultParams,
   //       {
   //          username: this.username,
   //          report_config: JSON.stringify(initialUserPreferences),
   //       }
   //    ));
   //    this.userPreferences = initialUserPreferences;
   //    localStorage.setItem('user_preferences', JSON.stringify(initialUserPreferences));
   // }

   // async setLastLineVisited(line) {
   //    const newUserPreference = await _.merge(
   //       this.userPreferences,
   //       { lastLineVisited: line }
   //    );
   //    const setReportUserConfigParams = await _.merge(
   //       this.userConfigDefaultParams,
   //       {
   //          username: this.username,
   //          report_config: JSON.stringify(newUserPreference)
   //       }
   //    );
   //    await this.baseService.setReportUserConfig(setReportUserConfigParams);
   //    localStorage.setItem('user_preferences', JSON.stringify(newUserPreference));
   // }

   // /**
   //  * Agregada las sublineas por linea
   //  */
   async getLeftMenu() {
      const leftMenuData: any = await this.ssiService.getLeftMenu();

      // Los procesos
      this.leftMenuData.processes = await _.filter(leftMenuData, { id_izquierdo_padre: null });

      _.each(this.leftMenuData.processes, (process: any) => {

         // Las plantas por cada proceso
         process.plants = _.filter(leftMenuData, { id_izquierdo_padre: process.id_izquierdo });

         // Las lineas por cada planta
         _.each(process.plants, (plant: any) => {
            if (plant.has_children) {
               plant.toggle = false;
               plant['lines'] = _.filter(leftMenuData, { id_izquierdo_padre: plant['id_izquierdo'] });
            }

            // Las sublineas por cada linea (si las tiene)
            _.each(plant.lines, (line: any) => {
               if (line.has_children) {
                  line.toggle = false;
                  line['sublines'] = leftMenuData.filter(subline => subline.id_izquierdo_padre === line.id_izquierdo && subline.has_url);
               }
            });
         });
      });
   }

   searchIconClick() {
      this.toggleSideBar();
   }

   toggleSideBar() {
      this.sharedService.toggleSideBar();
   }

   togglePlant(idProcess, idPlant) {
      const processIndex = _.findIndex(this.leftMenuData.processes, { id_izquierdo: idProcess });
      const plantIndex = _.findIndex(this.leftMenuData.processes[processIndex].plants, { id_izquierdo: idPlant });

      if (this.leftMenuData.processes[processIndex].plants[plantIndex].toggle === true) {
         this.leftMenuData.processes[processIndex].plants[plantIndex].toggle = false;
      } else {
         _.forEach(this.leftMenuData.processes[processIndex].plants, (plant) => {
            plant.toggle = false;
         });

         this.leftMenuData.processes[processIndex].plants[plantIndex].toggle = true;
      }
   }

   toggleLine(idProcess, idPlant, idLine) {
      const processIndex = _.findIndex(this.leftMenuData.processes, { id_izquierdo: idProcess });
      const plantIndex = _.findIndex(this.leftMenuData.processes[processIndex].plants, { id_izquierdo: idPlant });
      const lineIndex = _.findIndex(this.leftMenuData.processes[processIndex].plants[plantIndex].lines, { id_izquierdo: idLine });

      if (this.leftMenuData.processes[processIndex].plants[plantIndex].lines[lineIndex].toggle === true) {
         this.leftMenuData.processes[processIndex].plants[plantIndex].lines[lineIndex].toggle = false;
      } else {
         _.forEach(this.leftMenuData.processes[processIndex].plants[plantIndex].lines, (line) => {
            line.toggle = false;
         });

         this.leftMenuData.processes[processIndex].plants[plantIndex].lines[lineIndex].toggle = true;
      }
   }

   selectProcess(item) {
      this.id_process = item.id_izquierdo;
      if (!this.isOpenSideBar) { this.toggleSideBar(); }
   }

   async selectLine(item: any, plant: any, process: any) {
      /**
       * Actualiza los selectedId Subjects cuando se navega por el sidebar, siempre y cuando cambien
       */
      const selectedIdPlant = plant.id_izquierdo.toString();
      this.sharedService.updateIdPlant(selectedIdPlant);

      const selectedIdProcess = process.id_izquierdo.toString();
      this.sharedService.updateIdProcess(selectedIdProcess);

      const selectedIdLine = item.id_izquierdo.toString();

      if (this.sharedService.selectedIdLine.getValue() !== selectedIdLine) {
         this.sharedService.updateIdLine(selectedIdLine);
         /**
          * Si la linea cambia, busca el uppermenu de dicha linea y comienza a evaluar condiciones
          */
         const upperByLine = await this.ssiService.getUpperMenuLine(item.id_izquierdo);
         console.log(upperByLine);

         if (this.sharedService.selectedIdUpper.getValue()) {

            const sameUpperReport = _.find(upperByLine, (report: any) => {
               return report.id_superior.toString() === this.sharedService.selectedIdUpper.getValue();
            });

            if (sameUpperReport) {
               /**
                * Se encontró reporte con el mismo upper
                */
               let params: any;
               if (sameUpperReport.parameters) {
                  params = JSON.parse(this.JSONize(sameUpperReport.parameters));
               }

               if (sameUpperReport.is_angular) {
                  /**
                   * Es angular
                   */
                  if (sameUpperReport.state) {
                     /**
                      * Tiene state <REPORTE DE ANGULAR> Navega o iframe
                      */
                     let mode: number;
                     sameUpperReport.state === 'reports' ? mode = 2 : mode = 1;
                     this.navigationService.navigationResolver(sameUpperReport, mode, params);
                     this.sharedService.updateIdUpper(sameUpperReport.id_superior.toString());
                  } else {
                     /**
                      * Sin state <LIN_CLIENT || ALARMS_CLIENT> Abre otra tab por la url
                      */
                     this.navigationService.navigationResolver(sameUpperReport, 3);
                  }
               } else {
                  /**
                   * No es angular <IFRAME u OTRO> Navega
                   */
                  let mode: number;
                  sameUpperReport.state === 'reports' ? mode = 2 : mode = 4;
                  this.navigationService.navigationResolver(sameUpperReport, mode, params);
                  this.sharedService.updateIdUpper(sameUpperReport.id_superior.toString());
               }

            } else {
               /**
                * La linea no tiene el tipo de reporte de la linea anterior,
                * navega al reporte de producción
                */
               const productionReport = _.find(upperByLine, (report: any) => {
                  return report.id_superior.toString() == 401;
               });

               if (productionReport) {
                  /**
                   * Se encontró reporte de producción
                   */
                  let params: any;
                  if (productionReport.parameters) {
                     params = JSON.parse(this.JSONize(productionReport.parameters));
                  }

                  if (productionReport.is_angular) {
                     /**
                      * Reporte de producción en angular
                      */
                     this.navigationService.navigationResolver(productionReport, 1, params);
                     this.sharedService.updateIdUpper(productionReport.id_superior.toString());
                  } else {
                     /**
                      * Reporte de producción en iframe
                      */
                     this.navigationService.navigationResolver(productionReport, 2, params);
                     this.sharedService.updateIdUpper(productionReport.id_superior.toString());
                  }

               } else {
                  /**
                   * No tiene reporte de producción
                   */
                  const reportToGo = _.find(upperByLine, (report: any) => {
                     return report.is_angular && report.state;
                  });
                  if (reportToGo) {
                     let params: any;
                     if (productionReport.parameters) {
                        params = JSON.parse(this.JSONize(productionReport.parameters));
                     }
                     /**
                      * Navega al primer reporte con angular
                      */
                     this.navigationService.navigationResolver(reportToGo, 1, params);
                  } else {
                     console.log('caso mas malo');
                  }
               }
            }
         }
      }

      this.toggleSideBar();
   }


   // checkSuperior(id_left) {
   //    this.ssiService.getUpperMenuLine(id_left)
   //       .then((resp) => {
   //          if (this.sharedService.currentUpperMenuItem) {
   //             var same_upper = _.find(resp, { id_superior: this.sharedService.currentUpperMenuItem.id_superior });
   //             if (same_upper) {
   //                if (same_upper.state) {
   //                   this.sharedService.currentUpperMenuItem = same_upper;
   //                   var params = JSON.parse(this.JSONize(same_upper.parameters));
   //                   this.sharedService.updateIdLine(id_left);
   //                   this.$state.go(same_upper.state, params);
   //                }
   //                else {
   //                   var matches = _.filter(resp, (o: any) => {
   //                      return o.url != undefined && o.url != null && o.url != '';
   //                   });

   //                   var new_item = _.first(matches);
   //                   this.goToMVP(id_left, new_item.id_superior);
   //                }
   //                return;
   //             }
   //          }
   //          var currentItemState = _.find(resp, { state: this.currentState });
   //          if (currentItemState) {
   //             this.sharedService.currentUpperMenuItem = currentItemState;
   //             this.sharedService.updateIdLine(id_left);
   //             this.$state.go(this.currentState, { id_line: id_left });
   //          }
   //          else {
   //             var matches_state = _.filter(resp, (o: any) => {
   //                return o.state != undefined && o.state != null && o.state != '';
   //             });

   //             if (matches_state.length > 0) {
   //                var new_item_state = _.first(matches_state);
   //                this.sharedService.currentUpperMenuItem = new_item_state;
   //                this.sharedService.updateIdLine(id_left);
   //                var params = JSON.parse(this.JSONize(new_item_state.parameters));
   //                this.$state.go(new_item_state.state, params);
   //             }
   //             else {
   //                var matches = _.filter(resp, (o: any) => {
   //                   return o.url != undefined && o.url != null && o.url != '';
   //                });

   //                var new_item = _.first(matches);
   //                this.goToMVP(id_left, new_item.id_superior);
   //             }
   //          }
   //       });
   // }

   JSONize(str) {
      return str
         // wrap keys without quote with valid double quote
         .replace(/([\$\w]+)\s*:/g, function (_, $1) { return '"' + $1 + '":'; })
         // replacing single quote wrapped ones to double quote
         .replace(/'([^']+)'/g, function (_, $1) { return '"' + $1 + '"'; });
   }

   // goToMVP(id_left, id_upper) {
   //    var url = this.sharedService.MVPURL;
   //    url = url.replace('LLL', id_left.toString()).replace('III', id_upper.toString());
   //    window.open(url, '_self');
   // }

   // ngOnDestroy() {
   //    // prevent memory leak when component is destroyed
   //    // this.subscription.unsubscribe();
   //    // this.subscriptionLine.unsubscribe();
   // }
}
