// Angular Modules
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

/**
 * Traemos solo los modules de los elementos de Ngb que usemos,
 * no traer el NgbModule, salvo en lazy loading (ej. ProgramModule)
 */
// 3° party Modules
import { NgbDropdownModule, NgbCollapseModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';

// Custom Modules
import { SharedModule } from '../shared/shared.module';
import { PipesModule } from '../pipes/pipes.module';

// Custom Components
import { HeaderComponent } from './components/header.component';
import { SubHeaderComponent } from './components/sub-header.component';
import { SideBarComponent } from './components/side-bar.component';
@NgModule({
   imports: [
      CommonModule,
      FormsModule,
      NgbDropdownModule,
      NgbCollapseModule,
      SharedModule,
      PipesModule,
      NgbTooltipModule
   ],
   exports: [
      HeaderComponent,
      SubHeaderComponent,
      SideBarComponent
   ],
   declarations: [
      HeaderComponent,
      SubHeaderComponent,
      SideBarComponent,
   ]
})
export class LayoutModule { }
