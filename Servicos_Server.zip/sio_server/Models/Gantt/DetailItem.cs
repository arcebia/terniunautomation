﻿namespace Ternium.Sio_Server.Models.Gantt
{
    /// <summary>
    /// 
    /// </summary>
    public class DetailItem
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <param name="tooltip"></param>
        public DetailItem(string key, string value = "", bool tooltip = true)
        {
            this.Key = key;
            this.Value = value;
            this.Tooltip = tooltip;
        }

        /// <summary>
        /// Gets and sets Key
        /// </summary>
        public string Key { get; set; }
        /// <summary>
        /// Gets and sets Value
        /// </summary>
        public string Value { get; set; }
        /// <summary>
        /// Gets and sets ToolTip
        /// </summary>
        public bool Tooltip { get; set; }
    }
}