﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ternium.Sio_Server.Models.Gantt
{
    /// <summary>
    /// Class
    /// </summary>
    public class FulfillmentItem
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public FulfillmentItem(DateTime _start_date, DateTime _end_date, string _material_in, string _material_out, string _program, int _sequence, string _need)
        {
            this.StartDate = _start_date;
            this.EndDate = _end_date;
            this.MaterialIn = _material_in;
            this.MaterialOut = _material_out;
            this.Program = _program;
            this.Sequence = _sequence;
        }
        /// <summary>
        /// Gets and sets Date
        /// </summary>
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Gets and sets Shift
        /// </summary>
        public DateTime EndDate { get; set; }

        /// <summary>
        /// Gets and sets MaterialIn
        /// </summary>
        public string MaterialIn { get; set; }

        /// <summary>
        /// Gets and sets MaterialOut
        /// </summary>
        public string MaterialOut { get; set; }

        /// <summary>
        /// Gets and sets Program
        /// </summary>
        public string Program { get; set; }

        /// <summary>
        /// Gets and sets Sequence
        /// </summary>
        public int Sequence { get; set; }

    }
}