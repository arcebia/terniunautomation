﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ternium.Sio_Server.Models.Gantt
{
    public class MetricItem
    {
        public MetricItem(string id, string metric)
        {
            this.Id         = Int32.Parse(id); ;
            var gant_met_1  = metric.Split('|');
            this.Name       = gant_met_1[0];
        }
        /// <summary>
        /// Gets and sets Id
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// Gets and sets Name
        /// </summary>
        public string Name { get; set; }

        public int Checked  { get; set; }
    }
}