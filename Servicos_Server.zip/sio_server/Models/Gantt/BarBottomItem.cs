﻿using System;
using System.Collections.Generic;
using Ternium.Sio_Server.Language;

namespace Ternium.Sio_Server.Models.Gantt
{
    /// <summary>
    /// 
    /// </summary>
    public class BarBottomItem
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="type"></param>
        /// <param name="level1"></param>
        /// <param name="level2"></param>
        /// <param name="level3"></param>
        /// <param name="concept"></param>
        /// <param name="subconcept"></param>
        /// <param name="comments"></param>
        public BarBottomItem(
            DateTime startDate,
            DateTime endDate,
            int type,
            string level1,
            string level2,
            string level3,
            string concept,
            string subconcept,
            string comments)
        {
            this.StartTime = GanttUtils.GetGanttDateFormatted(startDate);
            this.EndTime = GanttUtils.GetGanttDateFormatted(endDate);
            this.Duration = GanttUtils.GetGanttTimeFormatted(endDate.Subtract(startDate));
            this.Type = type;
            this.Details = new List<DetailItem>();
            this.Details.Add(new DetailItem(Resources.Duration, this.Duration));
            this.Details.Add(new DetailItem(Resources.Start,  this.StartTime));
            this.Details.Add(new DetailItem(Resources.End, this.EndTime));
            this.Details.Add(new DetailItem(Resources.Level1, level1));
            this.Details.Add(new DetailItem(Resources.Level2, level2));
            this.Details.Add(new DetailItem(Resources.Level3, level3));
            this.Details.Add(new DetailItem(Resources.Concept, concept));
            this.Details.Add(new DetailItem(Resources.Subconcept, subconcept));
            this.Details.Add(new DetailItem(Resources.Comments, comments));
        }

        /// <summary>
        /// Gets or Sets StartTime
        /// </summary>
        public string StartTime { get; set; }
        /// <summary>
        /// Gets or Sets EndTime
        /// </summary>
        public string EndTime { get; set; }
        /// <summary>
        /// Gets or Sets Duration
        /// </summary>
        public string Duration { get; set; }
        /// <summary>
        /// Gets or Sets Type
        /// </summary>
        public int Type { get; set; }
        /// <summary>
        /// Gets or Sets Details
        /// </summary>
        public List<DetailItem> Details { get; set; }
    }
}