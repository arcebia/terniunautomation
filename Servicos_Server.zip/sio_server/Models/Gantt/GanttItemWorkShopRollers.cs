﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Reflection;

namespace Ternium.Sio_Server.Models.Gantt
{
    public class GanttItemWorkShopRollers
    {
        public GanttItemWorkShopRollers(Dictionary<string, string> item)
        {

            var properties = this.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);


            foreach (var property in properties)
            {
                if (item.ContainsKey(property.Name))
                {
                    property.SetValue(this, item[property.Name]);
                    
                }
                else if (property.Name == "RowId") {
                    property.SetValue(this, item["id_exit"]);
                }
                
               

            }

        }


        public string RowId { get; set; }
        public string id_line { get; set; }
        public string id_entrance { get; set; }
        public string id_exit { get; set; }
        public string id_program { get; set; }
        public string program_type { get; set; }
        public string id_material { get; set; }
        public string gantt_top_value { get; set; }
        public string gantt_bottom_value { get; set; }
        public string start_date { get; set; }
        public string end_date { get; set; }
        public string shift { get; set; }
        public string production_status { get; set; }
        public string programmed_material_quantity { get; set; }
        public string program_sequence { get; set; }
        public string material_sequence { get; set; }
        public string sampling { get; set; }
        public string id_exit_line { get; set; }
        public string exit_line { get; set; }
        public string defect_quantity { get; set; }
        public string id_exit_quality { get; set; }
        public string stratix_status { get; set; }
        public string exit_material { get; set; }
        public string maquina_descripcion { get; set; }
        public string tipo_rodillo { get; set; }
        public string material_salida { get; set; }
        public string fecha_dmy { get; set; }
        public string hora_inicio { get; set; }
        public string hora_fin { get; set; }
        public string duracion { get; set; }
        public string posicion_salida { get; set; }
        public string jaula { get; set; }
        public string diametro_entrada_inicial { get; set; }
        public string diametro_inicio_salida { get; set; }
        public string diametro_salida { get; set; }
        public string desbaste_salida { get; set; }
        public string desgaste { get; set; }
        public string consumo { get; set; }
        public string causa_rectificado_salida { get; set; }
        public string proveedor { get; set; }
        public string observaciones_salida { get; set; }
        public string usuario { get; set; }
        public string tipo_producto_descripion { get; set; }
        public string program { get; set; }
        public List<DetailItem> Details { get; set; }
    }
}