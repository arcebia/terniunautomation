﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ternium.Sio_Server.Models.Gantt
{
    /// <summary>
    /// Gantt Config
    /// To Parametric Titles Top an Bottom Metrics
    /// </summary>



    public class GanttConfig
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="metric_1"></param>
        /// <param name="metric_2"></param>
        public GanttConfig(string metric_1, string metric_2)
        {
            string[] split_metric_1 = metric_1.Split('|');
            string[] split_metric_2 = metric_2.Split('|');

            if (split_metric_1.Length != 4)
            {
                metric_1 = "Ancho [mm]|A [mm]|ancho_salida|Ancho";
                split_metric_1 = metric_1.Split('|');
            }
            if (split_metric_2.Length != 4)
            {
                metric_2 = "Espesor [mm]|E [mm]|espesor_salida|Espesor";
                split_metric_2 = metric_2.Split('|');
            }

            this.ganttTopLabel = split_metric_1[0];
            this.ganttTopShortLabel = split_metric_1[1];
            this.metric1_field = split_metric_1[2];
            this.metric1_tooltip = split_metric_1[3];
            this.ganttBottomLabel = split_metric_2[0];
            this.ganttBottomShortLabel = split_metric_2[1];
            this.metric2_field = split_metric_2[2];
            this.metric2_tooltip = split_metric_2[3];
            this.barBottomLabel = "DEMORAS";
            this.type = "PROD";
        }

        /// <summary>
        /// Public Properties
        /// </summary>
        public GanttConfig()
        {
            /*Nothing to do*/
        }
        /// <summary>
        /// Public Properties
        /// </summary>
        public string ganttTopLabel;

        /// <summary>
        /// Public Properties
        /// </summary>
        public string ganttTopShortLabel;

        /// <summary>
        /// Public Properties
        /// </summary>
        public string ganttBottomLabel;

        /// <summary>
        /// Public Properties
        /// </summary>
        public string ganttBottomShortLabel;

        /// <summary>
        /// Public Properties
        /// </summary>
        public string barBottomLabel;

        /// <summary>
        /// Public Properties
        /// </summary>
        public string metric1_field;

        /// <summary>
        /// Public Properties
        /// </summary>
        public string metric2_field;

        /// <summary>
        /// Public Properties
        /// </summary>
        public string metric1_tooltip;

        /// <summary>
        /// Public Properties
        /// </summary>
        public string metric2_tooltip;

        /// <summary>
        /// Public Properties
        /// </summary>
        public string title;

        /// <summary>
        /// Public Properties
        /// </summary>
        public string type;

        /// <summary>
        /// Public Properties
        /// </summary>
        public string isMultiline;

        /// <summary>
        /// Public Properties
        /// </summary>
        public string ganttToolTip;

        /// <summary>
        /// Public Properties
        /// </summary>
        public string fulfillmentType;
    }
}
