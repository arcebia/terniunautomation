﻿using System;
using System.Collections.Generic;
using Ternium.Sio_Server.Language;

namespace Ternium.Sio_Server.Models.Gantt
{
    /// <summary>
    /// Gantt Model Data
    /// </summary>
    public class ExitLine
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="rowId"></param>
        /// <param name="rowGroupId"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="material"></param>
        /// <param name="scheduleNumber"></param>
        /// <param name="sequence"></param>
        /// <param name="topValue"></param>
        /// <param name="bottomValue"></param>
        /// <param name="category"></param>
        /// <param name="status"></param>
        /// <param name="statusDescription"></param>
        public ExitLine(
            string id_line,
            string line
        ) {
            this.IdLine = id_line;
            this.Line = line;
        }

        /// <summary>
        /// Gets and sets RowId
        /// </summary>
        public string IdLine { get; set; }
        /// <summary>
        /// Gets and sets RowGroupId
        /// </summary>
        public string Line { get; set; }
    }
}