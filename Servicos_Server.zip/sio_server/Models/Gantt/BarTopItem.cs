﻿using System;
using System.Collections.Generic;
using System.Linq;
using Ternium.Sio_Server.Language;

namespace Ternium.Sio_Server.Models.Gantt
{
    /// <summary>
    /// 
    /// </summary>
    public class BarTopItem
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="rowId"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="sequence"></param>
        /// <param name="serieMaterials"></param>
        /// <param name="scheduledMaterials"></param>
        public BarTopItem(
            string rowId,
            DateTime startDate,
            DateTime endDate,
            string sequence,
            string serieMaterials,
            string scheduledMaterials)
        {
            this.RowId = rowId;
            this.StartTime = GanttUtils.GetGanttDateFormatted(startDate);
            this.EndTime = GanttUtils.GetGanttDateFormatted(endDate);
            this.Duration = GanttUtils.GetGanttTimeFormatted(endDate.Subtract(startDate));

            this.Details = new List<DetailItem>
            {
                new DetailItem(Resources.Schedule, this.RowId),
                new DetailItem(Resources.Sequence, sequence),
                new DetailItem(Resources.Start, this.StartTime),
                new DetailItem(Resources.End, this.EndTime),
                new DetailItem(Resources.SerieMaterials, serieMaterials),
                new DetailItem(Resources.ScheduledMaterials, scheduledMaterials)
            };
        }

        /// <summary>
        /// Gets or Sets RowId
        /// </summary>
        public string RowId { get; set; }

        /// <summary>
        /// Gets StartTime
        /// </summary>
        public string StartTime { get; private set; }

        /// <summary>
        /// UpdateStartTime
        /// </summary>
        /// <param name="dateTime"></param>
        public void UpdateStartTime(DateTime dateTime)
        {
            this.StartTime = GanttUtils.GetGanttDateFormatted(dateTime);
            UpdateDetail(Resources.Start, this.StartTime);
            this.Duration = GanttUtils.GetGanttTimeFormatted(Convert.ToDateTime(this.EndTime).Subtract(Convert.ToDateTime(this.StartTime)));
        }

        /// <summary>
        /// Gets EndTime
        /// </summary>
        public string EndTime { get; private set; }

        /// <summary>
        /// UpdateEndTime
        /// </summary>
        /// <param name="dateTime"></param>
        public void UpdateEndTime(DateTime dateTime)
        {
            this.EndTime = GanttUtils.GetGanttDateFormatted(dateTime);
            UpdateDetail(Resources.End, this.EndTime);
            this.Duration = GanttUtils.GetGanttTimeFormatted(Convert.ToDateTime(this.EndTime).Subtract(Convert.ToDateTime(this.StartTime)));
        }

        /// <summary>
        /// Gets or Sets Duration
        /// </summary>
        public string Duration { get; set; }

        /// <summary>
        /// Gets or Sets Details
        /// </summary>
        public List<DetailItem> Details { get; set; }

        private void UpdateDetail(string detailKey, string detailValue)
        {
            if (this.Details == null || !this.Details.Any())
            {
                return;
            }
                
            var details = this.Details.Where(d => d.Key == detailKey);
            foreach (var detail in details)
            {
                detail.Value = detailValue;
            }
        }
    }
}