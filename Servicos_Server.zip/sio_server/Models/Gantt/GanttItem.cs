﻿using System;
using System.Collections.Generic;
using Ternium.Sio_Server.Language;

namespace Ternium.Sio_Server.Models.Gantt
{
    /// <summary>
    /// Gantt Model Data
    /// </summary>
    public class GanttItem
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="rowId"></param>
        /// <param name="rowGroupId"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="material"></param>
        /// <param name="scheduleNumber"></param>
        /// <param name="sequence"></param>
        /// <param name="topValue"></param>
        /// <param name="bottomValue"></param>
        /// <param name="category"></param>
        /// <param name="status"></param>
        /// <param name="statusDescription"></param>
        /// <param name="idExitLine"></param>
        /// <param name="metric1"></param>
        /// <param name="metric2"></param>
        /// <param name="isMultiline"></param>
        /// <param name="ganttTooltip"></param>
        public GanttItem(
            string rowId,
            string rowGroupId,
            DateTime startDate,
            DateTime endDate,
            string material,
            string scheduleNumber,
            string sequence,
            string topValue,
            string bottomValue,
            string category,
            string status,
            string statusDescription,
            string metric1,
            string metric2,
            string id_input_material,
            int idExitLine = 0,
            string isMultiline = "",
            string additional_tooltip = "",
            string replacement_tooltip = ""
            )
        {
            this.RowId = rowId;
            this.RowGroupId = rowGroupId;
            this.StartTime = GanttUtils.GetGanttDateFormatted(startDate);
            this.EndTime = GanttUtils.GetGanttDateFormatted(endDate);
            this.Duration = GanttUtils.GetGanttTimeFormatted(endDate.Subtract(startDate));
            this.TopValue = topValue;
            this.BottomValue = bottomValue;
            this.Category = category;
            this.Status = status;
            this.StatusDescription = statusDescription;
            this.IdExitLine = idExitLine;

            this.Details = new List<DetailItem> {new DetailItem(Resources.Material, material)};
            if (!string.IsNullOrWhiteSpace(this.Status) && Convert.ToInt32(this.Status) < 1)
            {
                this.Details.Add(new DetailItem(Resources.Status, this.StatusDescription));
            }

            this.Details.Add(new DetailItem(Resources.Schedule, scheduleNumber));
            this.Details.Add(new DetailItem(Resources.Sequence, sequence));
            this.Details.Add(new DetailItem(Resources.Start, this.StartTime));
            this.Details.Add(new DetailItem(Resources.End, this.EndTime));
 		
            // MULTILINE SHOW ONLY METRIC 1
            
            if ( metric1 == null || metric1 == "")
                this.Details.Add(new DetailItem(Resources.Width, this.TopValue));
            else
                this.Details.Add(new DetailItem(metric1, this.TopValue));
            
            if (isMultiline != "1")
            {
                if (metric2 == null || metric2 == "")
                    this.Details.Add(new DetailItem(Resources.Thickness, this.BottomValue));
                else
                    this.Details.Add(new DetailItem(metric2, this.BottomValue));
            }

            this.IdInputMaterial = id_input_material;

            // ADDITIONAL TOOLTIPS
            if (additional_tooltip != null && additional_tooltip != "")
            {
                var split = additional_tooltip.Split('|');
                if (additional_tooltip.IndexOf("|") > 0)
                {
                    for (int J = 0; 1 + J < split.Length; J += 2)
                    {
                        this.Details.Add(new DetailItem(split[J], split[1 + J]));
                    }
                }
            }

            // CUSTOM TOOLTIPS. REPLACEMENT ALL TOOLTIPS
            if (replacement_tooltip != null && replacement_tooltip != "" && replacement_tooltip.IndexOf("|") > 0)
            {
                this.Details.Clear();
                this.Details.Add(new DetailItem(Resources.Material, material));

                var split = replacement_tooltip.Split('|');
                for (int J = 0; 1 + J < split.Length; J +=2 )
                {
                    this.Details.Add(new DetailItem(split[J], split[1 + J]));
                }

                if (metric1 == null || metric1 == "")
                    this.Details.Add(new DetailItem(Resources.Width, this.TopValue));
                else
                    this.Details.Add(new DetailItem(metric1, this.TopValue));

                if (isMultiline != "1")
                {
                    if (metric2 == null || metric2 == "")
                        this.Details.Add(new DetailItem(Resources.Thickness, this.BottomValue));
                    else
                        this.Details.Add(new DetailItem(metric2, this.BottomValue));
                }
            }

        }

        /// <summary>
        /// Gets and sets RowId
        /// </summary>
        public string RowId { get; set; }
        /// <summary>
        /// Gets and sets RowGroupId
        /// </summary>
        public string RowGroupId { get; set; }
        /// <summary>
        /// Gets and sets StartTime
        /// </summary>
        public string StartTime { get; set; }
        /// <summary>
        /// Gets and sets EndTime
        /// </summary>
        public string EndTime { get; set; }
        /// <summary>
        /// Gets and sets Duration
        /// </summary>
        public string Duration { get; set; }
        /// <summary>
        /// Gets and sets TopValue
        /// </summary>
        public string TopValue { get; set; }
        /// <summary>
        /// Gets and sets BottomValue
        /// </summary>
        public string BottomValue { get; set; }
        /// <summary>
        /// Gets and sets Category
        /// </summary>
        public string Category { get; set; }
        /// <summary>
        /// Gets and sets Status
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// Gets and sets StatusDescription
        /// </summary>
        public string StatusDescription { get; set; }
        /// <summary>
        /// Gets and sets IdExitLine
        /// </summary>
        public int IdExitLine { get; set; }
        /// <summary>
        /// Gets and sets Details
        /// </summary>
        public List<DetailItem> Details { get; set; }
        /// <summary>
        /// Gets and sets Material Input ID
        /// </summary>
        public string IdInputMaterial { get; set; }

    }
}
