﻿using System;
using System.Collections.Generic;
using Ternium.Sio_Server.Language;

namespace Ternium.Sio_Server.Models.Gantt
{
    /// <summary>
    /// 
    /// </summary>
    public class XMarkItem
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="rowId"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        public XMarkItem(string rowId, DateTime startDate, DateTime endDate)
        {
            this.RowId = rowId;
            this.StartTime = GanttUtils.GetGanttDateFormatted(startDate);
            this.EndTime = GanttUtils.GetGanttDateFormatted(endDate);
            this.Duration = GanttUtils.GetGanttTimeFormatted(endDate.Subtract(startDate));
        }

        /// <summary>
        /// Gets or Sets RowId
        /// </summary>
        public string RowId { get; set; }
        /// <summary>
        /// Gets or Sets StartTime
        /// </summary>
        public string StartTime { get; set; }
        /// <summary>
        /// Gets or Sets EndTime
        /// </summary>
        public string EndTime { get; set; }
        /// <summary>
        /// Gets or Sets Duration
        /// </summary>
        public string Duration { get; set; }
        /// <summary>
        /// Gets or Sets Details
        /// </summary>
        public List<DetailItem> Details { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="code"></param>
        /// <param name="description"></param>
        /// <param name="tooltip"></param>
        public void AddMark(string code, string description, bool tooltip = true)
        {
            if (this.Details == null)
            {
                this.Details = new List<DetailItem> {new DetailItem(Resources.Defects)};
            }

            this.Details.Add(new DetailItem(code, description, tooltip));
        }
    }
}