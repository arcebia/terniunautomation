﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;

namespace Ternium.Sio_Server.Models.Gantt
{

   

    public class GanttItemSteelWorks
    {

        public GanttItemSteelWorks(Dictionary<string, string> item)
        {

            var properties = this.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);


            foreach (var property in properties)
            {
                if (item.ContainsKey(property.Name))
                {
                    if (property.Name == "numero_salida")
                    {
                        try { 
                             property.SetValue(this, int.Parse(item[property.Name]));
                        }
                        catch (Exception ex)
                        {}
                    }
                    else {
                        property.SetValue(this, item[property.Name]);
                    }
                    
                }
                else if (property.Name == "RowId") {
                    property.SetValue(this, item["id_exit"]);
                }
                
               

            }

        }


        public string RowId { get; set; }
        public string duration { get; set; }
        public string end_time { get; set; }
        public string fecha_fin { get; set; }
        public string fecha_inicio { get; set; }
        public string grade { get; set; }
        public string id_line { get; set; }
        public string program { get; set; }
        public string start_time { get; set; }
        public string flow { get; set; }
        public int group_id { get; set; }
        public string id_exit { get; set; }
        public int numero_salida { get; set; }
        public List<DetailItem> Details { get; set; }

    }

    

}