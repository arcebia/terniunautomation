﻿using System;

namespace Ternium.Sio_Server.Models.Gantt
{
    /// <summary>
    /// Utility for Gantt
    /// </summary>
    public static class GanttUtils
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static string GetGanttDateFormatted(DateTime date)
        {
            return $"{date:yyyy-MM-dd HH:mm:ss}";
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        public static string GetGanttTimeFormatted(TimeSpan time)
        {
            return time.ToString("hh\\:mm\\:ss");
        }
    }
}