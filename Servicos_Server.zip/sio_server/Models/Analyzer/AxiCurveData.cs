﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ternium.Sio_Server.Models.Analyzer
{
    public class AxiCurveData:AxiCurve
    {
        public int VariableXId { get; set; }
        public string Unit { get; set; }
        public int? MaximumScale { get; set; }
        public int? MinimumScale { get; set; }
        public float? TargetValue { get; set; }
        public float? MaximumBand { get; set; }
        public float? MinimumBand { get; set; }
        public string ZipEncode64Curve { get; set; }        
        public bool IsDatType { get; set; }
        public string DppId { get; set; }
        public int ReviewId { get; set; }
        public string AdditionalInformation { get; set; }
        public string TexpertComment { get; set; }
        public int Decimals { get; set; }
        public string LeftLegend { get; set; }
        public string RightLegend { get; set; }
        public string Color { get; set; }
        public bool Inverted { get; set; }
        public int VisualOrder { get; set; }
        public bool XAxiJoined { get; set; }
        public bool ShowInCoilInfo { get; set; }
        public bool CalculateMaxMin { get; set; }
        public bool AutomaticMaxMin { get; set; }
        public bool ApplyFilter { get; set; }
        public float? ValueFilter { get; set; }

        public List<double> Values { get; set; }

        public AxiCurveData()
        {
            Values = new List<double>();
        }
    }
}