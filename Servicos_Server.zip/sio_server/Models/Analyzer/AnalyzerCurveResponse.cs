﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ternium.Sio_Server.Models.Analyzer
{
    public class AnalyzerCurveResponse
    {
        /// <summary>
        /// Gets Success Request
        /// </summary>
        public bool Success { get; set; }

        /// <summary>
        /// Gets ResponseText
        /// </summary>
        public string ResponseText { get; set; }


        public AnalyzerCurveModel analyzerModel;

        public AnalyzerCurveDataModel curveDataModel;

        public int id { get; set; }

       
    }
}