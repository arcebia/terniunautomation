﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ternium.Sio_Server.Models.Analyzer
{
    public class AxiCurve
    {
        public int VariableId { get; set; }
        public string VariableName { get; set; }
        public string VariableDescription { get; set; }
        public string VariableType { get; set; }
        public bool Selected { get; set; }
    }
}