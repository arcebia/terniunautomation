﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ternium.Sio_Server.Models.Analyzer
{
    public class AnalyzerCurveModel
    {
        public List<Dictionary<string, string>> PrinterTemplates { get; set; }
        public List<Dictionary<string, string>> PrinterVariables { get; set; }
        public List<Dictionary<string, string>> PrinterCurveAreas { get; set; }
        public List<Dictionary<string, string>> PrinterVariableNames { get; set; }
        public List<Dictionary<string, string>> PrinterConfig { get; set; }

    }
}