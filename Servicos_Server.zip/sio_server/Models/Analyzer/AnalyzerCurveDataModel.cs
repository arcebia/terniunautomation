﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ternium.Sio_Server.Models.Analyzer
{
    public class AnalyzerCurveDataModel
    {
        public string Tittle { get; set; }
        public AxiCurveData XAxi { get; set; }
        public List<AxiCurveData> YAxis { get; set; }
    }
}