﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ternium.Sio_Server.Models.Analyzer
{
    public class AnalyzerCurveParams
    {
        /// <summary>
        /// Gets or sets IdLine
        /// </summary>
        public int id_line { get; set; }

        /// <summary>
        /// Gets or sets IdExit
        /// </summary>
        public int id_exit { get; set; }

        public string material { get; set; }
        /// <summary>
        /// Gets or sets XAxi
        /// </summary>
        /// 
        public List<string> curveIds;

        public int LastWithCurve { get; set; }

        public int id_model { get; set; }

        public int id_printer_tpl { get; set; }
            
        public string name_printer_tpl { get; set; }
       
        public int id_layout { get; set; }

        public List<Dictionary<string, string>> curveAreas;

        public bool usePipFilter { get; set; }

        public int program { get; set; }

        public int item { get; set; }

        public int position { get; set; }

        public int isPrevious { get; set; }

        public bool by_material { get; set; }

        public string apply_to { get; set; }

        public bool t_expert { get; set; }

    }
}