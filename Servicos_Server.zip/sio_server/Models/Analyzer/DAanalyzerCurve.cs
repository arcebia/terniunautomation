﻿using System;
using System.Collections.Generic;
using Ternium.Sio.Shared.Utils;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Data;
using System.Web;


namespace Ternium.Sio_Server.Models.Analyzer
{
    public class DAanalyzerCurve
    {
        /// <summary>
        /// The connection.
        /// </summary>
        private readonly string connection;

        /// <summary>
        /// The database utility connection.
        /// </summary>
        private readonly DbUtils dbUtils;

        /// <summary>
        /// Initializes a new instance of the <see cref="DAanalizerCurve"/> class.        
        /// </summary>
        public DAanalyzerCurve()
        {
            this.connection = ConfigurationManager.ConnectionStrings["DSSIO_LAM"].ConnectionString;
            this.dbUtils = new DbUtils(this.connection);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref=" GetAnalyzerCurveTemplates"/> class.        
        /// </summary>
        public Dictionary<string, List<Dictionary<string, string>>> GetAnalyzerCurveTemplates(int idLine)
        {
            var paramDictionary = new Dictionary<string, object>
            {
                {"id_line", idLine},
                {"id_type", 1}
            };

            return dbUtils.ExecuteMultipleReaderDictionary("[crud].[usp_web_get_printer_analyzer_tpls]", new[] { "Templates", "Variables", "Areas", "VariableNames" ,"ReportConfig","MaterialFields"}, paramDictionary);
        }
        public Dictionary<string, List<Dictionary<string, string>>> GetCurveAxisData(int idLine, string material)
        {
            var paramDictionary = new Dictionary<string, object>
            {
                {"id_line", idLine},
                {"material", material}
            };

            return dbUtils.ExecuteMultipleReaderDictionary("[prod].[usp_web_get_curve_axis]", new[] { "Curves", "Material" }, paramDictionary);
        }

        public Dictionary<string, string> GetMaterialInfo(int idLine, string material, int lastWithCurve = 0)
        {
            var parameters = new Dictionary<string, object>
            {
                {"id_line", idLine}, 
                {"material", material},
                {"last_with_curve", lastWithCurve}
            };

            return dbUtils.ExecuteReaderDictionary("[prod].[usp_web_material_info]", parameters);
        }
        public string GetPreviousNextCoil(int idLine, int idExit, int isPrevious)
        {
            var material = string.Empty;

            using (var conn = new SqlConnection(connection))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "[prod].[usp_web_get_previous_next_coil]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@id_line", SqlDbType.Int).Value = idLine;
                    cmd.Parameters.Add("@id_exit", SqlDbType.Int).Value = idExit;
                    cmd.Parameters.Add("@is_previous", SqlDbType.Bit).Value = isPrevious;

                    conn.Open();

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            material = reader["material"] is DBNull ? string.Empty : reader["material"].ToString();
                        }
                    }

                    conn.Close();
                }
            }

            return material;
        }
        public Dictionary<string, string> GetMaterialNumberByPip(int idLine, int program, int item, int position)
        {
            var parameters = new Dictionary<string, object>
            {
                {"id_line", idLine}, 
                {"program", program}, 
                {"item", item}, 
                {"position", position}
            };

            return dbUtils.ExecuteReaderDictionary("[prod].[usp_web_material_number_by_pip]", parameters);
        }
        public int DeletePrinterTemplate(Dictionary<string, object> parameters)
        {
            return ExecuteNonQuery("[crud].[usp_web_delete_printer_tpl]", parameters);
        }
        public List<Dictionary<string, string>> GetMaterialDefects(int idLine, int idExit)
        {
            var parameters = new Dictionary<string, object>
            {
                {"id_line", idLine}, 
                {"id_exit", idExit}                
            };

            return dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_coil_defects]", parameters);
        }
        public Dictionary<string, List<Dictionary<string, string>>> GetTexpertSemaphore(int idLine, int idExit, int idModel)
        {
            var parameters = new Dictionary<string, object>
            {
                {"id_line", idLine},               
                {"id_exit", idExit},
                {"id_model", idModel}
            };

            var dataNames = new[] { "Semaphores", "GeneralSemaphore" };

            return dbUtils.ExecuteMultipleReaderDictionary("[prod].[usp_web_get_texpert_sem]", dataNames, parameters);

        }
        public Dictionary<string, string> SaveCurvePrinterTemplate(Dictionary<string, object> parameters)
        {
            var curveAreas = (List<Dictionary<string, string>>)parameters["curve_areas"];

            if (curveAreas.Any(c => string.IsNullOrEmpty(c["x_variables"]) || string.IsNullOrEmpty(c["y_variables"])))
            {
                return new Dictionary<string, string>();
            }

            var dtCurveAreas = new DataTable("[dbo].[PrinterTplCurveArea]");
            dtCurveAreas.Columns.Add("curve_area", typeof(string));
            dtCurveAreas.Columns.Add("x_variables", typeof(string));
            dtCurveAreas.Columns.Add("y_variables", typeof(string));
            dtCurveAreas.Columns.Add("ticks_number_y", typeof(string));


            curveAreas.ForEach(ca => dtCurveAreas.Rows.Add(ca["curve_area"], ca["x_variables"], ca["y_variables"] , 5));
           
            parameters["curve_areas"] = dtCurveAreas;

            return dbUtils.ExecuteReaderDictionary("[crud].[usp_web_save_curve_printer_tpl]", parameters);
        }
        public List<AxiCurveData> GetCurvesData(int idLine, List<int> curveIds)
        {
            var axis = new List<AxiCurveData>();

            using (var conn = new SqlConnection(connection))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "[prod].[usp_web_get_curve_data_by_ids_V2]"; //TODO
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@id_line", SqlDbType.Int).Value = idLine;

                    var dtCurves = new DataTable("[dbo].[IdListDataType]");
                    dtCurves.Columns.Add("id", typeof(Int32));
                    curveIds.ForEach(id => dtCurves.Rows.Add(id));
                    cmd.Parameters.Add(new SqlParameter("@id_curves", dtCurves));

                    conn.Open();

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            axis.Add(new AxiCurveData
                            {
                                VariableId = int.Parse(reader["id_variable"].ToString()),
                                VariableName = DBNull.Value != reader["variable"] ? reader["variable"].ToString() : string.Empty,
                                VariableDescription = DBNull.Value != reader["description"] ? reader["description"].ToString() : string.Empty,
                                VariableType = reader["variable_type"].ToString(),
                                Unit = reader["unit"].ToString(),
                                ZipEncode64Curve = reader["curveData"].ToString(),
                                MaximumBand = DBNull.Value != reader["max_band"] ? float.Parse(reader["max_band"].ToString()) : (float?)null,
                                MinimumBand = DBNull.Value != reader["min_band"] ? float.Parse(reader["min_band"].ToString()) : (float?)null,
                                TargetValue = DBNull.Value != reader["target_scale"] ? float.Parse(reader["target_scale"].ToString()) : (float?)null,
                                ApplyFilter = DBNull.Value != reader["apply_filter"] && int.Parse(reader["apply_filter"].ToString()) == 1,
                                ValueFilter = DBNull.Value != reader["value_filter"] ? float.Parse(reader["value_filter"].ToString()) : (float?)null
                            });
                        }
                    }
                }

                conn.Close();
            }

            return axis;
        }
        public int ExecuteNonQuery(string spName, Dictionary<string, object> parameters)
        {
            var result = -1;
            using (var connection = new SqlConnection(this.connection))
            {
                using (var command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText = spName;
                    command.CommandType = CommandType.StoredProcedure;

                    if (parameters != null)
                    {
                        foreach (var sqlParam in parameters.Select(item => new SqlParameter(item.Key, item.Value)))
                        {
                            command.Parameters.Add(sqlParam);
                        }
                    }

                    connection.Open();
                    result = command.ExecuteNonQuery();
                }

                connection.Close();
            }

            return result;
        }
    }
}