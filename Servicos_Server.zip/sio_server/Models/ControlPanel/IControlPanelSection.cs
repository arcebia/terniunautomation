﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ternium.Sio_Server.Models.ControlPanel
{
    public interface IControlPanelSection
    {
        int Id { get; set; }
        string Name { get; set; }
        List<IControlPanelVariable> Variables { get; set;}
        List<IControlPanelTable> Tables { get; set; }
        List<IControlPanelSection> Sections { get; set; }

        void AddVariable(string field, string label, string description, string unit, string value);
        void AddTable(List<string> columns, List<Dictionary<string, string>> values);
    }
}
