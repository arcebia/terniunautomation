﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ternium.Sio_Server.Models.ControlPanel
{
    public class ControlPanelData
    {
        public ControlPanelData()
        {
            columns = new List<ColumnName>();
            values = new List<string[]>();
        }

        public int configColumnCount { get; set; }
        public int totalPages { get; set; }

        public List<ColumnName> columns { get; set; }
        public List<string[]> values { get; set; }
    }
}