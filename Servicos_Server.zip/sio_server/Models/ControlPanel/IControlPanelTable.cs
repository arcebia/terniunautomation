﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ternium.Sio_Server.Models.ControlPanel
{
    public interface IControlPanelTable
    {
        List<string> Columns { get; set; }
        List<Dictionary<string, string>> Values { get; set; }
    }
}
