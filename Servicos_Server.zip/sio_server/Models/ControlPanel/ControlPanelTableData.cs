﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ternium.Sio_Server.Models.ControlPanel
{
    public class ControlPanelTableData
    {
        public ControlPanelTableData()
        {
            columns = new List<ColumnName>();
            values = new List<Dictionary<string, string>>();
        }

        public List<ColumnName> columns { get; set; }
        public List<Dictionary<string, string>> values { get; set; }
    }
}