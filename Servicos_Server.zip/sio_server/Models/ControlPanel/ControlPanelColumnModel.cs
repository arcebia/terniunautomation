﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ternium.Sio_Server.Models.ControlPanel
{
    public class ControlPanelColumnModel
    {
        public List<IControlPanelSection> Sections { get; set; }

        public ControlPanelColumnModel()
        {
            Sections = new List<IControlPanelSection>();
        }
    }
}