﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ternium.Sio_Server.Models.ControlPanel
{
    public class ColumnName
    {
        public string title { get; set; }
        public string name { get; set; }
    }
}