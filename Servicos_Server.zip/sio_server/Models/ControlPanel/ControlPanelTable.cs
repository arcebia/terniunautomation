﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Ternium.Sio_Server.Models.ControlPanel;

namespace Ternium.Sio_Server.Models.ControlPanel
{
    public class ControlPanelTable : IControlPanelTable
    {
        public List<string> Columns { get; set; }
        public List<Dictionary<string,string>> Values { get; set; }

        public ControlPanelTable()
        {
            Columns = new List<string>();
            Values = new List<Dictionary<string, string>>();
        }
    }
}