﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ternium.Sio_Server.Models.ControlPanel
{
    public interface IControlPanelVariable
    {
        string Field { get; set; }
        string Label { get; set; }
        string Description { get; set; }
        string Unit { get; set; }
        string Val { get; set; }
    }
}
