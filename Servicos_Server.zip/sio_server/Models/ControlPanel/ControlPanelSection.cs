﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Ternium.Sio_Server.Models.ControlPanel;

namespace Ternium.Sio_Server.Models.ControlPanel
{
    public class ControlPanelSection : IControlPanelSection
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<IControlPanelVariable> Variables { get; set; }
        public List<IControlPanelTable> Tables { get; set; }
        public List<IControlPanelSection> Sections { get; set; }

        public ControlPanelSection()
        {
            Id = 0;
            Name = string.Empty;
            Variables = new List<IControlPanelVariable>();
            Tables = new List<IControlPanelTable>();
            Sections = new List<IControlPanelSection>();
        }

        public ControlPanelSection(int id, string name)
        {
            Id = id;
            Name = name;
            Variables = new List<IControlPanelVariable>();
            Tables = new List<IControlPanelTable>();
            Sections = new List<IControlPanelSection>();
        }

        public void AddVariable(string field, string label, string description, string unit, string value)
        {
            Variables.Add(new ControlPanelVariable
            {
                Field = field,
                Label = label,
                Description = description,
                Unit = unit,
                Val = value
            });
        }

        public void AddTable(List<string> columns, List<Dictionary<string,string>> values)
        {
            Tables.Add(new ControlPanelTable
            {
                Columns = columns,
                Values = values
            });
        }
    }
}