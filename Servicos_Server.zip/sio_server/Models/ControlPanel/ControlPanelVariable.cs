﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Ternium.Sio_Server.Models.ControlPanel;

namespace Ternium.Sio_Server.Models.ControlPanel
{
    public class ControlPanelVariable : IControlPanelVariable
    {
        public string Field { get; set; }
        public string Label { get; set; }
        public string Description { get; set; }
        public string Unit { get; set; }
        public string Val { get; set; }
    }
}