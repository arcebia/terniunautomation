﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Reflection;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Linq;

namespace Ternium.Sio_Server.Models
{
    public class MultiColumnHeader
    {

        public MultiColumnHeader(Dictionary<string, string> column)
        {
            var properties = this.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);

           foreach (var property in properties)
           {
              if (column.ContainsKey(property.Name))
              {
                  // TODO: Revisar la propiedad order
                  if (property.PropertyType.Equals(typeof(Int32)))
                  {
                      property.SetValue(this, Int32.Parse(column[property.Name]));
                  }
                  else
                  {
                      property.SetValue(this, column[property.Name]);
                  }
              }
           }
        }

        public MultiColumnHeader()
        {
           
        }

        public string id_header { get; set; }
        public string description { get; set; }
        public string id_header_parent { get; set; }
        public string display_name { get; set; }
        public string alias_column { get; set; }
        public string frontier_column { get; set; }
        public string has_template { get; set; }
        public string id_column { get; set; }
        public string id_line { get; set; }
        public string id_report { get; set; }
        public string additional_cfg { get; set; }
        public string tooltip_item_alias { get; set; }
        public int order { get; set; }
        public string pinned { get; set; }
        public string to_show { get; set; }
        public string width { get; set; }
        public int rowspan { get; set; }
        public int colspan { get; set; }
        public int level { get; set; }
        public int max_levels { get; set; }


        public string id_group          { get; set; }
        public string action            { get; set; }
        public bool   childrenToggled   { get; set; }
        public string variable_type     { get; set; } 

        public List<MultiColumnHeader> child_columns { get; set; }


    }
}
