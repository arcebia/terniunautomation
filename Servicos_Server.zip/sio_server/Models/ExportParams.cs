﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ternium.Sio_Server.Models
{
    public class ExportParams
    {
        public string id_line { get; set; }
        public DateTime start_date { get; set; }
        public DateTime end_date { get; set; }
        public List<Dictionary<string, string>> columns { get; set; }
    }
}