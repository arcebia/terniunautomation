﻿namespace Ternium.Sio_Server.Models.Curves
{
    /// <summary>
    /// Enum for the curve types.
    /// </summary>
    public enum CurveType
    {
        /// <summary>
        /// Type Curve
        /// </summary>
        CURVA = 1,

        /// <summary>
        /// Type Planeza
        /// </summary>
        PLANEZA = 2
    }
}