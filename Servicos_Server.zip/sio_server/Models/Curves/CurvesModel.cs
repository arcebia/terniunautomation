﻿using System.Collections.Generic;
using Ternium.Sio.Shared.Models;

namespace Ternium.Sio_Server.Models.Curves
{
    /// <summary>
    /// Curve Model Object
    /// </summary>
    public class CurvesModel
    {
        /// <summary>
        /// Gets IdLine
        /// </summary>
        public int id_line { get; set; }

        /// <summary>
        /// Gets IdMaterial
        /// </summary>
        public int id_material { get; set; }

        /// <summary>
        /// Gets Material
        /// </summary>
        public string material { get; set; }

        /// <summary>
        /// Gets MultiPanelDefault
        /// </summary>
        public short multi_panel_default { get; set; }

        /// <summary>
        /// Gets JoinYAxisDefault
        /// </summary>
        public short join_y_axis_default { get; set; }

        /// <summary>
        /// Gets CurveTypeSelected
        /// </summary>
        public int curve_type_selected { get; set; }

        /// <summary>
        /// Gets CurveTypes
        /// </summary>
        public List<Dictionary<string, string>> curve_types { get; set; }

        /// <summary>
        /// Gets YAxis
        /// </summary>
        public List<Axi> y_axis { get; set; }

        /// <summary>
        /// Gets YAxisSelected
        /// </summary>
        public List<int> y_axis_selected { get; set; }

        /// <summary>
        /// Gets XAxis
        /// </summary>
        public List<Axi> x_axis { get; set; }

        /// <summary>
        /// Gets XAxisSelected
        /// </summary>
        public int x_axis_selected { get; set; }

        /// <summary>
        /// Gets MaterialInfo
        /// </summary>
        public Dictionary<string, string> material_info { get; set; }

        /// <summary>
        /// CurvesModel Init.
        /// </summary>
        public CurvesModel()
        {
            y_axis_selected = new List<int>();
        }        
    }
}