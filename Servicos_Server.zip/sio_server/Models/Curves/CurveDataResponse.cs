﻿using System.Collections.Generic;

namespace Ternium.Sio_Server.Models.Curves
{
    /// <summary>
    /// Curve Data Response
    /// </summary>
    public class CurveDataResponse
    {
        /// <summary>
        /// Gets Success Request
        /// </summary>
        public bool Success { get; set; }

        /// <summary>
        /// Gets ResponseText
        /// </summary>
        public string ResponseText { get; set; }

        /// <summary>
        /// Gets XAxi
        /// </summary>
        public List<AxiData> XAxi { get; set; }

        /// <summary>
        /// Gets YAxis
        /// </summary>
        public List<AxiData> YAxis { get; set; }
    }
}