﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ternium.Sio_Server.Models.Curves
{
    /// <summary>
    /// Reuest Curve Data parameters
    /// </summary>
    public class CurveDataParams
    {
        /// <summary>
        /// Gets or sets IdLine
        /// </summary>
        public int id_line { get; set; }

        /// <summary>
        /// Gets or sets IdExit
        /// </summary>
        public int id_exit { get;set; }

        public string material { get; set; }
        /// <summary>
        /// Gets or sets XAxi
        /// </summary>
        public int x_axis { get; set; }
        public string x_axis_description { get; set; }

        /// <summary>
        /// Gets or sets YAxis
        /// </summary>
        public int[] y_axis { get; set; }
        public List<Axi> y_axis_list { get; set; }
    }
}