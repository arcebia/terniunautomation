﻿namespace Ternium.Sio_Server.Models.Curves
{
    /// <summary>
    /// The Axi Object
    /// </summary>
    public class Axi
    {
        /// <summary>
        /// Gets VariableId
        /// </summary>
        public int id_variable { get; set; }

        /// <summary>
        /// Gets VariableName
        /// </summary>
        public string name { get; set; }

        /// <summary>
        /// Gets VariableDescription
        /// </summary>
        public string description { get; set; }

        /// <summary>
        /// Gets VariableType
        /// </summary>
        public string type { get; set; }

        /// <summary>
        /// Gets Selected
        /// </summary>
        public bool selected { get; set; }

        public string tag { get; set; }

        public int id_variable_x { get; set; }
        public string unit { get; set; }
    }
}