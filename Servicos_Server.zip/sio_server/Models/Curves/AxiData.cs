﻿using System.Collections.Generic;

namespace Ternium.Sio_Server.Models.Curves
{
    /// <summary>
    /// The Axi Data Object
    /// </summary>
    public class AxiData : Axi
    {
        /// <summary>
        /// Gets Unit
        /// </summary>
        public string Unit { get; set; }

        /// <summary>
        /// Gets MaximumScale
        /// </summary>
        public float? MaximumLimit { get; set; }

        /// <summary>
        /// Gets MinimumScale
        /// </summary>
        public float? MinimumLimit { get; set; }
        
        /// <summary>
        /// Gets TargetScale
        /// </summary>
        public float? TargetLimit { get; set; }

        /// <summary>
        /// Gets ZipEncode64Curve
        /// </summary>
        public string ZipEncode64Curve { get; set; }

        /// <summary>
        /// Gets IsDatType
        /// </summary>
        public bool IsDatType { get; set; }

        /// <summary>
        /// Gets DppId
        /// </summary>
        public string DppId { get; set; }

        /// <summary>
        /// Gets ReviewId
        /// </summary>
        public int? ReviewId { get; set; }

        /// <summary>
        /// Gets AdditionalInformation
        /// </summary>
        public string AdditionalInformation { get; set; }

        /// <summary>
        /// Gets TexpertComment
        /// </summary>
        public string TexpertComment { get; set; }

        /// <summary>
        /// Gets Decimals
        /// </summary>
        public int? Decimals { get; set; }

        /// <summary>
        /// Gets LeftLegend
        /// </summary>
        public string LeftLegend { get; set; }

        /// <summary>
        /// Gets RightLegend
        /// </summary>
        public string RightLegend { get; set; }

        /// <summary>
        /// Gets Color
        /// </summary>
        public string Color { get; set; }

        /// <summary>
        /// Gets Inverted
        /// </summary>
        public bool Inverted { get; set; }

        /// <summary>
        /// Gets Values
        /// </summary>
        public List<double> Values { get; set; }

        /// <summary>
        /// AxiData Init.
        /// </summary>
        public AxiData()
        {
            Values = new List<double>();
        }

        public string tag { get; set; }
    }
}