﻿using System.Collections.Generic;

namespace Ternium.Sio_Server.Models
{
    /// <summary>
    /// Production Report Data
    /// </summary>
    public class ProductionReportData
    {
        private readonly Dictionary<string, List<Dictionary<string, string>>> reportData;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="report"></param>
        /// <param name="gantt"></param>
        public ProductionReportData(Dictionary<string, List<Dictionary<string, string>>> report, Dictionary<string, object> gantt)
        {
            reportData = report;
            GanttData = gantt;            
        }

        /// <summary>
        /// Gets Report Data
        /// </summary>
        public List<Dictionary<string, string>> ReportData => reportData["Production"];

        /// <summary>
        /// Gets Gantt Data
        /// </summary>
        public Dictionary<string, object> GanttData { get; }

        /// <summary>
        /// Gets Summary Data
        /// </summary>
        public List<Dictionary<string, string>> Summary => reportData["Summary"];

        /// <summary>
        /// Gets LineStatus
        /// </summary>
        public List<Dictionary<string, string>> LineStatus => reportData["LineStatus"];
    }
}