﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ternium.Sio_Server.Models
{
    public class User
    {
        public int? id_user { get; set; }
        public string name { get; set; }
        public string mail { get; set; }
        public string username { get; set; }
        public string photo { get; set; }
        public bool? allow_edit { get; set; }
        public bool? allow_hide { get; set; }
        public int id_line { get; set; }
        public bool? allow_create_event { get; set; }
        public bool? allow_edit_inspection { get; set; }
    }
}