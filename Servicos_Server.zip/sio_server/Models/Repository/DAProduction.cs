﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DataAccess.cs" company="Ternium, S.A">
//   Ternium Siderar.
// </copyright>
// <summary>
//   DataAccess Object.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Ternium.Sio_Server.Models.Repository
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data;
    using System.Data.SqlClient;

    using Sio.Shared.Utils;
    using Ternium.Sio_Server.Models.Curves;
    using Ternium.Sio.Shared.Models;

    /// <summary>
    /// DataAccess Object.
    /// </summary>
    public class DAProduction
    {
        /// <summary>
        /// The connection.
        /// </summary>
        private readonly string connection;

        private readonly string connectionAce;

        /// <summary>
        /// The database utility connection.
        /// </summary>
        private readonly DbUtils dbUtils;
        private readonly DbUtils dbUtilsAce;


        /// <summary>
        /// Initializes a new instance of the <see cref="DAProduction"/> class.
        /// </summary>
        public DAProduction()
        {
            this.connection = ConfigurationManager.ConnectionStrings["DSSIO_LAM"].ConnectionString;
            this.connectionAce = ConfigurationManager.ConnectionStrings["DSSIO_ACE"].ConnectionString;
            this.dbUtils = new DbUtils(this.connection);
            this.dbUtilsAce = new DbUtils(this.connectionAce);
        }

        /// <summary>
        /// The get shift report data.
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The <see cref="IDictionary"/>.
        /// </returns>
        public Dictionary<string, List<Dictionary<string, string>>> GetShiftReportData(Dictionary<string, object> parameters)
        {
            var dataNames = new[] { "Defects", "Production", "Summary", "LineStatus", "Delays" };
            return this.dbUtils.ExecuteMultipleReaderDictionary("[dbo].[usp_web_get_production_report]", dataNames, parameters);
        }

        /// <summary>
        /// The get coil defects.
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The <see cref="IList"/>.
        /// </returns>
        public List<Dictionary<string, string>> GetCoilDefects(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_production_report_defect_detail]", parameters);
        }

        /// <summary>
        /// Get Current Shift
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The <see cref="IList"/>.
        /// </returns>
        public List<Dictionary<string, string>> GetCurrentShift(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_current_shift]", parameters);
        }

        /// <summary>
        /// Get All Shifts
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The <see cref="IList"/>.
        /// </returns>
        public List<Dictionary<string, string>> GetShifts(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_shifts]", parameters);
        }

        /// <summary>
        /// Get Current Shift
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The <see cref="IList"/>.
        /// </returns>
        public List<Dictionary<string, string>> GetProductionDefects(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_production_defects]", parameters);
        }


        /// <summary>
        /// The get coil defects.
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The <see cref="IList"/>.
        /// </returns>
        public List<Dictionary<string, string>> GetReportColumns(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_report_all_columns]", parameters);
        }

        /// <summary>
        /// The get production coils.
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The <see cref="IList"/>.
        /// </returns>
        public List<Dictionary<string, string>> GetProductionCoils(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_production]", parameters);
        }

        public List<Dictionary<string, string>> GetMaterialInfo(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_material_info]", parameters);
        }

        /// <summary>
        /// Get Exit Lines Production
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public List<Dictionary<string, string>> GetExitLines(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_exit_lines]", parameters);
        }

        /// <summary>
        /// The get production summary.
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The <see cref="IList"/>.
        /// </returns>
        public List<Dictionary<string, string>> GetProductionSummary(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_production_summary]", parameters);
        }

        /// <summary>
        /// The get line status.
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The <see cref="IDictionary"/>.
        /// </returns>
        public Dictionary<string, string> GetLineStatus(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionary("[dbo].[usp_web_get_line_status]", parameters);
        }

        /// <summary>
        /// The get line delays.
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The <see cref="IList"/>.
        /// </returns>
        public List<Dictionary<string, string>> GetLineDelays(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_production_delays]", parameters);
        }

        /// <summary>
        /// Gets hour range for all the shifts enabled
        /// </summary>
        /// <param name="idLine">ID Line</param>
        /// <returns>Hour ranges for each shift (0 means all the shifts)</returns>
        public List<Shift> GetShiftRanges(int idLine)
        {
            var result = new List<Shift>();
            using (var conn = new SqlConnection(this.connection))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "[dbo].[usp_web_get_shifts_info]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@id_line", SqlDbType.Int).Value = idLine;

                    conn.Open();

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(new Shift
                            {
                                ShiftNumber = Convert.ToInt16(reader["shift"].ToString()),
                                Start = reader["start_time"].ToString(),
                                End = reader["end_time"].ToString()
                            });
                        }
                    }
                }

                conn.Close();
            }

            return result;
        }

        /// <summary>
        /// Gets configuration options belonging to the line
        /// </summary>
        /// <param name="idLine">ID line</param>
        /// <returns>An Line object with all the configuration options</returns>
        public Line GetLineConfig(int idLine)
        {
            var result = new Line();
            using (var conn = new SqlConnection(this.connection))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "[dbo].[usp_web_get_line_info]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@id_line", SqlDbType.Int).Value = idLine;

                    conn.Open();

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result = new Line
                            {
                                IdLine = idLine,
                                LineName = DBNull.Value != reader["line"] ? reader["line"].ToString() : string.Empty,
                                LineCode = DBNull.Value != reader["abbreviature"] ? reader["abbreviature"].ToString() : string.Empty,
                                BannerMessage = DBNull.Value != reader["banner_message"] ? reader["banner_message"].ToString() : string.Empty,
                                BannerCssClass = DBNull.Value != reader["banner_class"] ? reader["banner_class"].ToString() : string.Empty,
                                SsrsProgramPrinting = string.Empty, //DBNull.Value != reader["ssrs_program_printing"] ? reader["ssrs_program_printing"].ToString() : string.Empty,
                                ShowProductionGantt = DBNull.Value != reader["show_production_gantt"] ? Convert.ToInt16(reader["show_production_gantt"]) : (short)0,
                                ShowProductionDelayGantt = DBNull.Value != reader["show_production_delay_gantt"] ? Convert.ToInt16(reader["show_production_delay_gantt"]) : (short)0,
                                ShowProductionSummary = DBNull.Value != reader["show_production_summary"] ? Convert.ToInt16(reader["show_production_summary"]) : (short)0,
                                ShowEntranceMaterialGroups = DBNull.Value != reader["show_entrance_material_groups"] ? Convert.ToInt16(reader["show_entrance_material_groups"]) : (short)0,
                                ShowExitMaterialGroups = DBNull.Value != reader["show_exit_materials_groups"] ? Convert.ToInt16(reader["show_curves"]) : (short)0,
                                ShowCurves = DBNull.Value != reader["show_curves"] ? Convert.ToInt16(reader["show_production_gantt"]) : (short)0,
                                ShowSensorsLevel = DBNull.Value != reader["show_sensors_level"] ? Convert.ToInt16(reader["show_sensors_level"]) : (short)0,
                                DefaultMultiPanelCurves = DBNull.Value != reader["default_multipanel_curves"] ? Convert.ToInt16(reader["default_multipanel_curves"]) : (short)0,
                                DefaultJoinAxisCurves = DBNull.Value != reader["default_join_axis_curves"] ? Convert.ToInt16(reader["default_join_axis_curves"]) : (short)0
                            };
                        }
                    }
                }

                conn.Close();
            }

            return result;
        }

        /// <summary>
        /// Gets the Material Information.
        /// </summary>
        /// <param name="idLine"></param>
        /// <param name="material"></param>
        /// <returns></returns>
        public Dictionary<string, string> GetMaterialInfo(int idLine, string material)
        {
            var parameters = new Dictionary<string, object>
            {
                {"id_line", idLine},
                {"material", material}
            };

            return dbUtils.ExecuteReaderDictionary("[prod].[usp_web_material_info]", parameters);
        }

        /// <summary>
        /// The get report config.
        /// </summary>
        /// <param name="idLine">
        /// The id line.
        /// </param>
        /// <param name="idReport">
        /// The id report.
        /// </param>
        /// <returns>
        /// The <see cref="Report"/>.
        /// </returns>
        public Report GetReportConfig(int idLine, int idReport)
        {
            var result = new Report();
            using (var conn = new SqlConnection(this.connection))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "[dbo].[usp_web_get_report_info]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@id_line", SqlDbType.Int).Value = idLine;
                    cmd.Parameters.Add("@id_report", SqlDbType.Int).Value = idReport;

                    conn.Open();

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result = new Report
                            {
                                ReportName = DBNull.Value != reader["report"] ? reader["report"].ToString() : string.Empty,
                                GanttType = DBNull.Value != reader["id_gantt_type"] ? Convert.ToInt16(reader["id_gantt_type"]) : (short)0,
                                HasSummary = DBNull.Value != reader["has_summary"] ? Convert.ToInt16(reader["has_summary"]) : (short)0,
                                HasSpeed = DBNull.Value != reader["has_speed"] ? Convert.ToInt16(reader["has_speed"]) : (short)0,
                                ToolbarType = DBNull.Value != reader["id_toolbar_type"] ? Convert.ToInt16(reader["id_toolbar_type"]) : (short)0,
                                CurrentTurn = DBNull.Value != reader["current_shift"] ? Convert.ToInt16(reader["current_shift"]) : (short)0,
                                CurrentDate = DBNull.Value != reader["current_date"] ? Convert.ToDateTime(reader["current_date"]) : DateTime.Now,
                                CurrentShiftStartDate = DBNull.Value != reader["start_date_current_shift"] ? Convert.ToDateTime(reader["start_date_current_shift"]) : DateTime.Now.Date,
                                CurrentShiftEndDate = DBNull.Value != reader["end_date_current_shift"] ? Convert.ToDateTime(reader["end_date_current_shift"]) : DateTime.Now.Date
                            };
                        }
                    }
                }

                conn.Close();
            }

            return result;
        }

        /// <summary>
        /// The get user columns.
        /// </summary>
        /// <param name="user">
        /// The user.
        /// </param>
        /// <param name="idLine">
        /// The id line.
        /// </param>
        /// <param name="idReport">
        /// The id report.
        /// </param>
        /// <returns>
        /// The <see cref="string"/>.
        /// </returns>
        public string GetUserColumns(string user, int idLine, int idReport)
        {
            string result = null;
            using (var conn = new SqlConnection(this.connection))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "[cfg].[usp_web_get_user_columns]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@user", SqlDbType.VarChar).Value = user.ToLower();
                    cmd.Parameters.Add("@id_line", SqlDbType.Int).Value = idLine;
                    cmd.Parameters.Add("@id_report", SqlDbType.Int).Value = idReport;

                    conn.Open();

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result = reader["columns"].ToString();
                        }
                    }
                }

                conn.Close();
            }

            return result;
        }

        /// <summary>
        /// The set user columns.
        /// </summary>
        /// <param name="user">
        /// The user.
        /// </param>
        /// <param name="idLine">
        /// The id line.
        /// </param>
        /// <param name="idReport">
        /// The id report.
        /// </param>
        /// <param name="columns">
        /// The columns.
        /// </param>
        public void SetUserColumns(string user, int idLine, int idReport, string columns)
        {
            using (var conn = new SqlConnection(this.connection))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "[cfg].[usp_web_store_user_columns]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@user", SqlDbType.VarChar).Value = user.ToLower();
                    cmd.Parameters.Add("@id_line", SqlDbType.Int).Value = idLine;
                    cmd.Parameters.Add("@id_report", SqlDbType.Int).Value = idReport;
                    cmd.Parameters.Add("@columns", SqlDbType.Int).Value = columns.Trim();

                    conn.Open();

                    cmd.ExecuteNonQuery();
                }

                conn.Close();
            }
        }


        #region "Curves"

        /// <summary>
        /// Get the curve types.
        /// </summary>
        /// <param name="idLine"></param>
        /// <returns></returns>
        public List<Dictionary<string, string>> GetCurveTypes(int idLine)
        {
            var paramDictionary = new Dictionary<string, object>
            {
                {"id_line", idLine}
            };
            List<Entity> list = new List<Entity>();
            var data = dbUtils.ExecuteReaderDictionaryList("cfg.usp_web_get_curve_types", paramDictionary);
            return data;
        }

        /// <summary>
        /// Get the curve axis
        /// </summary>
        /// <param name="idLine"></param>
        /// <param name="idVariableX"></param>
        /// <returns></returns>
        public List<Dictionary<string, string>> GetCurveAxis(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("prod.usp_web_get_curves_axis", parameters);
        }

        /// <summary>
        /// Get the curve data.
        /// </summary>
        /// <param name="idLine"></param>
        /// <param name="idExit"></param>
        /// <returns></returns>
        public List<AxiData> GetCurvesData(int idLine, int idExit, string material)
        {
            var axis = new List<AxiData>();

            using (var conn = new SqlConnection(connection))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "[prod].[usp_web_get_process_curves]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@id_line", SqlDbType.Int).Value = idLine;
                    cmd.Parameters.Add("@id_exit", SqlDbType.Int).Value = idExit;
                    cmd.Parameters.Add("@material", SqlDbType.VarChar).Value = material;

                    conn.Open();

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            axis.Add(new AxiData
                            {
                                id_variable = int.Parse(reader["id_variable"].ToString()),
                                name = ConvertToString(reader, "variable"),
                                description = ConvertToString(reader, "description"),
                                type = reader["id_variable_type"].ToString(),
                                selected = false,
                                Unit = reader["metric"].ToString(),
                                MaximumLimit = ConvertToFloat(reader, "max_limit"),
                                MinimumLimit = ConvertToFloat(reader, "min_limit"),
                                TargetLimit = ConvertToFloat(reader, "target_limit"),
                                ZipEncode64Curve = reader["curve"].ToString(),
                                IsDatType = ConvertToInt(reader, "variable_dat") == 1,
                                DppId = ConvertToString(reader, "id_operative_practice"),
                                ReviewId = ConvertToInt(reader, "id_revision"),
                                AdditionalInformation = ConvertToString(reader, "additional_info"),
                                TexpertComment = ConvertToString(reader, "texpert_comments"),
                                Decimals = ConvertToInt(reader, "decimals"),
                                LeftLegend = ConvertToString(reader, "left_legend"),
                                RightLegend = ConvertToString(reader, "right_legend"),
                                Color = ConvertToString(reader, "color"),
                                Inverted = false
                            });
                        }
                    }
                }

                conn.Close();
            }

            return axis;
        }

        public string ConvertToString(SqlDataReader reader, string column)
        {
            return DBNull.Value != reader[column] ? reader[column].ToString() : string.Empty;
        }

        public int? ConvertToInt(SqlDataReader reader, string column)
        {
            int number;
            return Int32.TryParse(ConvertToString(reader, column), out number) ? (int?)number : null;
        }

        public float? ConvertToFloat(SqlDataReader reader, string column)
        {
            float number;
            return float.TryParse(ConvertToString(reader, column), out number) ? (float?)number : null;
        }
        /// <summary>
        /// Get Next and Previous coil.
        /// </summary>
        /// <param name="idLine"></param>
        /// <param name="idExit"></param>
        /// <param name="isPrevious"></param>
        /// <returns></returns>
        public Dictionary<string, string> GetPreviousNextCoil(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionary("[prod].[usp_web_get_previous_next_coil]", parameters);
        }

        #endregion

        //[prod].[usp_web_get_production_defects_map]
        public List<Dictionary<string, string>> GetProducionDefectsMap(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_production_defects_map]", parameters);
        }

        /// <summary>
        /// The get line status.
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The <see cref="IDictionary"/>.
        /// </returns>
        public List<Dictionary<string, string>> GetSuperficialInspection(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_defects_superficial_inspection]", parameters);
        }

        public List<Dictionary<string, string>> GetCheckSuperficialInspection(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("prod.usp_web_check_defects_superficial_inspection", parameters);
        }

        /// <summary>
        /// The get line status.
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The <see cref="IDictionary"/>.
        /// </returns>
        public List<Dictionary<string, string>> GetCurvesAxisLength(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("prod.usp_web_get_curves_axis_length", parameters);
        }

        /// <summary>
        /// The get line status.
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The <see cref="IDictionary"/>.
        /// </returns>
        public List<Dictionary<string, string>> GetTreeTrace(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_tree_trace_material]", parameters);
        }

        /// <summary>
        /// The get line status.
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The <see cref="IDictionary"/>.
        /// </returns>
        public List<Dictionary<string, string>> GetTreeTraceDetail(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_tree_trace_material_detail]", parameters);
        }

        public Dictionary<string, List<Dictionary<string, string>>> GetTrendingSections(Dictionary<string, object> parameters)
        {
            var dataNames = new[] { "Sections", "Info" };
            return this.dbUtils.ExecuteMultipleReaderDictionary("[prod].[usp_get_trending_graph_sections]", dataNames, parameters);
        }

        //prod.usp_get_surface_inspection_defects_output
        public List<Dictionary<string, string>> GetSurfaceInspectionDefectsOutput(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_get_surface_inspection_defects_output]", parameters);
        }

        //prod.usp_get_all_output_defects
        public List<Dictionary<string, string>> GetAllDefectsOutput(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_get_all_output_defects]", parameters);
        }

        /// <summary>
        /// The get line status.
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The <see cref="IDictionary"/>.
        /// </returns>
        public List<Dictionary<string, string>> GetRollersDetailMaterial(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_rollers_detail_by_material]", parameters);
        }

        /// <summary>
        /// GetProductionSearch
        /// </summary>
        public List<Dictionary<string, string>> GetProductionSearch(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_production_search]", parameters);
        }

        public List<Dictionary<string, string>> GetProductionDictum(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[genr].[usp_web_get_production_dictum]", parameters);
        }


        //GetMetallicBalance
        public List<Dictionary<string, string>> GetMetallicBalance(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_production_report_metallic_balance]", parameters);
        }

        //GetRetirementLine
        public List<Dictionary<string, string>> GetRetirementLine(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_production_report_retirement_line]", parameters);
        }

        // GetDefectsGeneric
        public List<Dictionary<string, string>> GetDefectsGeneric(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_production_report_defects_generic]", parameters);
        }

        // GetShrinks
        public List<Dictionary<string, string>> GetShrinks(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_production_report_shrinks]", parameters);
        }

        // GetSuspension
        public List<Dictionary<string, string>> GetSuspension(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_production_report_suspension]", parameters);
        }

        // GetOrdersList
        public List<Dictionary<string, string>> GetOrdersList(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_report_orders_list]", parameters);
        }

        // GetOrdersDetails
        public List<Dictionary<string, string>> GetOrdersDetails(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_report_orders_details]", parameters);
        }

        // GetOrdersDetailsMaterials
        public List<Dictionary<string, string>> GetOrdersDetailsMaterials(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_report_orders_details_materials]", parameters);
        }

        //GetEnergyConsumption
        public List<Dictionary<string, string>> GetEnergyConsumption(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_energy_consumption]", parameters);
        }

        public List<Dictionary<string, string>> GetEssayReport(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_essay_report]", parameters);
        }
        //ExportPDF SearchProduction
        public List<Dictionary<string, string>> GetDefectTestPdf(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_defect_test_pdf]", parameters);
        }

        public List<Dictionary<string, string>> GetResumenProduction(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_resumen_production_pdf]", parameters);
        }

        /// <summary>
        /// Get Data curve 3d.
        /// </summary>
        /// <param name="IdLine"></param>
        /// <param name="idExit"></param>
        /// <param name="idVariableType"></param>
        /// <returns></returns>
        public List<Dictionary<string, string>> GetCurvePlaneza3D(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_process_curves_3d]", parameters);
        }

        /// <summary>
        /// Get Data curve 3d.
        /// </summary>
        /// <param name="IdLine"></param>
        /// <param name="idExit"></param>
        /// <param name="id_variable"></param>
        /// <returns></returns>
        public List<Dictionary<string, string>> GetProcessCurves3dLimits(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_process_curves_3d_limits]", parameters);
        }


        public Dictionary<string, string> GetCobbleInfo(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionary("[prod].[usp_web_cobble_info]", parameters);
        }

        /// <summary>
        /// Get Report Aceria production
        /// </summary>
        /// <param name="id_line"></param>
        /// <param name="start_date"></param>
        /// <param name="end_date"></param>
        /// <param name="end_date"></param>
        /// <param name="filter"></param>
        /// <param name="order_asc"></param>
        /// <param name="return_defects"></param>
        /// <returns></returns>
        public List<Dictionary<string, string>> GetAceProductionGeneric(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_ace_production_generic]", parameters);
        }

        /// <summary>
        /// Get Report Aceria production
        /// </summary>
        /// <param name="id_plant"></param>
        /// <param name="beginDate"></param>
        /// <param name="endDate"></param>
        /// <param name="shift"></param>
        /// <param name="grade"></param>
        /// <returns></returns>
        public List<Dictionary<string, string>> GetSheetGanttFlow(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_sheet_gantt_flows]", parameters);
        }

        /// <summary>
        /// Get Report Aceria production
        /// </summary>
        /// <param name="lineId"></param>
        /// <param name="flow"></param>
        /// <param name="beginDate"></param>
        /// <param name="endDate"></param>
        /// <param name="shift"></param>
        /// <returns></returns>
        public List<Dictionary<string, string>> GetFlowGeneralData(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_flow_general_data]", parameters);
        }

         public List<Dictionary<string, string>> GetWebGetAceProductionSummary(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_ace_production_summary]", parameters);
        }

        public Dictionary<string, List<Dictionary<string, string>>> GetReportData(string sp_report_data, Dictionary<string, object> parameters)
        {
            var dataNames = new[] { "production", "summary" };
            return this.dbUtils.ExecuteMultipleReaderDictionary(sp_report_data, dataNames, parameters);
        }

        public Dictionary<string, string> GetSearchMaterial(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionary("SIO_ACE.[prod].[usp_web_search_material]", parameters);
        }

		public List<Dictionary<string, string>> GetIntegratedProductionCCD(Dictionary<string, object> parameters)
        {
            return this.dbUtilsAce.ExecuteReaderDictionaryList("[prod].[usp_web_getReporteProduccionIntegradoCCDS]", parameters);
        }

        public List<Dictionary<string, string>> GetIntegratedProductionESC(Dictionary<string, object> parameters)
        {
            return this.dbUtilsAce.ExecuteReaderDictionaryList("[prod].[usp_web_getReporteProduccionIntegradaESC]", parameters);
        }

        public List<Dictionary<string, string>> GetIntegratedProductionPAN(Dictionary<string, object> parameters)
        {
            return this.dbUtilsAce.ExecuteReaderDictionaryList("[prod].[usp_web_getReporteProduccionIntegradaPAN]", parameters);
        }

        public Dictionary<string, List<Dictionary<string, string>>> GetSlabsProductionGraph(Dictionary<string, object> parameters)
        {
            var dataNames = new[] { "Defects", "Quality", "Totals", "Totalp" };
            return this.dbUtilsAce.ExecuteMultipleReaderDictionary("[prod].[usp_web_getSlabsProduccionGraph]", dataNames, parameters);
        }

        public Dictionary<string, string> GetMaterialDetails(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionary("[prod].[usp_web_get_material_details]", parameters);
        }

        public Dictionary<string, List<Dictionary<string, string>>> GetSlabsDimensional(string sp_report_data, Dictionary<string, object> parameters)
        {
            var dataNames = new[] { "Export", "Totals", "Total_bars", "Diario", "Success", "SuccessDaily"};
            return this.dbUtilsAce.ExecuteMultipleReaderDictionary(sp_report_data, dataNames, parameters);
        }

        //public Dictionary<string, List<Dictionary<string, string>>> GetReportData(string sp_report_data, Dictionary<string, object> parameters)
        //{
        //    var dataNames = new[] { "production", "summary" };
        //    return this.dbUtils.ExecuteMultipleReaderDictionary(sp_report_data, dataNames, parameters);
        //}

        public List<Dictionary<string, string>> GetProductionGroup(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[genr].[usp_web_get_production_group]", parameters);
        }

        public List<Dictionary<string, string>> GetProductionLine(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[genr].[usp_web_get_line_group]", parameters);
        }

        public List<Dictionary<string, string>> GetProductionLineHeat(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[genr].[usp_web_get_line_heat]", parameters);
        }

        public List<Dictionary<string, string>> GetProductionSpeed(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[genr].[usp_web_get_speed]", parameters);
        }

        public List<Dictionary<string, string>> GetProductionWidth(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[genr].[usp_web_get_width]", parameters);
        }

        public Dictionary<string, List<Dictionary<string, string>>> GetShapeClassification(Dictionary<string, object> parameters, string[] dataNames)
        {
            
            return this.dbUtils.ExecuteMultipleReaderDictionary("[prod].[usp_web_get_shape_classification]", dataNames, parameters);
        }
    }

}
