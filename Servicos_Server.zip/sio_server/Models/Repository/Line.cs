﻿﻿namespace Ternium.Sio_Server.Models.Repository
 {
     /// <summary>
     /// Line Object
     /// </summary>
     public class Line
     {
         /// <summary>
         /// Gets or Sets the Id Line
         /// </summary>
         public int IdLine { get; set; }
         /// <summary>
         /// Gets or Sets the Line
         /// </summary>
         public string LineName { get; set; }
         /// <summary>
         /// Gets or Sets the Line Code
         /// </summary>
         public string LineCode { get; set; }
         /// <summary>
         /// Gets or Sets the Banner Message
         /// </summary>
         public string BannerMessage { get; set; }
         /// <summary>
         /// Gets or Sets the Banner Message Class
         /// </summary>
         public string BannerCssClass { get; set; }
         /// <summary>
         /// Gets or Sets the Ssrs Url
         /// </summary>
         public string SsrsProgramPrinting { get; set; }
         /// <summary>
         /// Gets or Sets the Show Production Gantt
         /// </summary>
         public short ShowProductionGantt { get; set; }
         /// <summary>
         /// Gets or Sets the Show Production Delay Gantt
         /// </summary>
         public short ShowProductionDelayGantt { get; set; }
         /// <summary>
         /// Gets or Sets the Show Production Summary
         /// </summary>
         public short ShowProductionSummary { get; set; }
         /// <summary>
         /// Gets or Sets the Show Entrance Material Groups
         /// </summary>
         public short ShowEntranceMaterialGroups { get; set; }
         /// <summary>
         /// Gets or Sets the Show Exit Material Groups
         /// </summary>
         public short ShowExitMaterialGroups { get; set; }
         /// <summary>
         /// Gets or Sets the Show Curves
         /// </summary>
         public short ShowCurves { get; set; }
         /// <summary>
         /// Gets or Sets the Show Sensors Level
         /// </summary>
         public short ShowSensorsLevel { get; set; }
         /// <summary>
         /// Gets or Sets the Default MultiPanel Curves
         /// </summary>
         public short DefaultMultiPanelCurves { get; set; }
         /// <summary>
         /// Gets or Sets the Default Join Axis Curves
         /// </summary>
         public short DefaultJoinAxisCurves { get; set; }
     }
 }