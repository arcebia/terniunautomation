﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using Ternium.Sio.Shared.Utils;

namespace Ternium.Sio_Server.Models.Repository
{
    public class DAProcess
    {
        /// <summary>
        /// The connection.
        /// </summary>
        private readonly string connection;

        private readonly string connectionAce;

        /// <summary>
        /// The database utility connection.
        /// </summary>
        private readonly DbUtils dbUtils;

        private readonly DbUtils dbUtilsAce;

        /// <summary>
        /// Initializes a new instance of the <see cref="DAProduction"/> class.        
        /// </summary>
        public DAProcess()
        {
            this.connection = ConfigurationManager.ConnectionStrings["DSSIO_LAM"].ConnectionString;
            this.connectionAce = ConfigurationManager.ConnectionStrings["DSSIO_ACE"].ConnectionString;
            this.dbUtils = new DbUtils(this.connection);
            this.dbUtilsAce = new DbUtils(this.connectionAce);
        }

        public List<Dictionary<string, string>> GetPatternWeight(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_report_pattern_weight]", parameters);
        }

        public List<Dictionary<string, string>> GetDashboardSKI(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_dashboard_ski]", parameters);
        }

        public List<Dictionary<string, string>> GetDashboardElectrode(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_dashboard_electrode]", parameters);
        }

        public List<Dictionary<string, string>> GetDashboardDetailSKI(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_dashboard_ski_detail]", parameters);
        }

        public List<Dictionary<string, string>> GetReportSKI(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_report_ski]", parameters);
        }

        public List<Dictionary<string, string>> GetReportElectrode(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_electrode_report]", parameters);
        }

        public List<Dictionary<string, string>> GetReportSKIPass(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_report_ski_pass]", parameters);
        }

        public List<Dictionary<string, string>> GetDashboardTExpert(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_texpert_dashboard]", parameters);
        }

        public List<Dictionary<string, string>> GetDashboardTExpertActive(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_texpert_actives]", parameters);
        }

        public List<Dictionary<string, string>> GetDashboardTExpertDetail(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_texpert_detail]", parameters);
        }

        public List<Dictionary<string, string>> GetDashboardThickness(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_dashboard_thickness]", parameters);
        }

        public List<Dictionary<string, string>> GetReportThickness(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_report_thickness]", parameters);
        }
        public List<Dictionary<string, string>> GetCoverStatus(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_cover_status]", parameters);
        }
        public List<Dictionary<string, string>> GetCoverTypes(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_cover_types]", parameters);
        }

        public List<Dictionary<string, string>> GetSubstratumObjetive(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_substratum_objetive]", parameters);
        }

        public List<Dictionary<string, string>> GetAnomaliesManagementReport(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_anomalies_management_report]", parameters);
        }

        public List<Dictionary<string, string>> GetAnomaliesManagementCauses(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_anomalies_management_causes]", parameters);
        }

        public List<Dictionary<string, string>> GetAnomaliesManagementDetail(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_anomalies_management_detail]", parameters);
        }

        public List<Dictionary<string, string>> CopyTemplates(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[crud].[usp_web_save_copy_curve_printer_tpl]", parameters);
        }

        public void PostAnomaliesManagementCopy(Dictionary<string, object> parameters)
        {
            DABase.ExecuteNonQuerySP(this.connection, "[proc].[usp_web_post_anomalies_copy]", parameters);
        }

        public void PostAnomaliesManagementCauses(Dictionary<string, object> parameters)
        {
            DABase.ExecuteNonQuerySP(this.connection, "[proc].[usp_web_post_anomalies_det_causes]", parameters);
        }

        public void PostAnomaliesManagementDetail(Dictionary<string, object> parameters)
        {
            DABase.ExecuteNonQuerySP(this.connection, "[proc].[usp_web_post_anomalies_detail]", parameters);
        }

        public void PostAssociateCurves(Dictionary<string, object> parameters)
        {
            DABase.ExecuteNonQuerySP(this.connection, "[crud].[usp_web_assign_curve_printer_tpl]", parameters);
        }
        public Dictionary<string, List<Dictionary<string, string>>> GetCoverageManagement(Dictionary<string, object> parameters)
        {
            var dataNames = new[] { "Summary", "MaterialsDetail", "Laboratory", "Alarms" };
            return this.dbUtils.ExecuteMultipleReaderDictionary("[prod].[usp_web_get_coverage_management]", dataNames, parameters);
        }


        public void InsertFurnaceMeasure(int idLine, string userName, string workOrder, string comments, List<Dictionary<string, object>> furnaceMeasureTb)
        {
            var fMTb = new DataTable("[dbo].[furnace_measure_tb]");
            fMTb.Columns.Add("zone_code", typeof(String));
            fMTb.Columns.Add("variable_code", typeof(String));
            fMTb.Columns.Add("side", typeof(String));
            fMTb.Columns.Add("burner_number", typeof(String));
            fMTb.Columns.Add("value", typeof(Double));
            fMTb.Columns.Add("measure_date", typeof(DateTime));
            fMTb.Columns.Add("color", typeof(String));

            foreach (var fm in furnaceMeasureTb)
            {
                var row = fMTb.NewRow();
                foreach (var k in fm.Keys)
                {
                    row[k] = fm[k] ?? DBNull.Value; ;
                }
                fMTb.Rows.Add(row);
            }

            using (var conn = new SqlConnection(connection))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "[proc].[usp_web_post_furnace_measure]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@id_line", SqlDbType.Int).Value = idLine;
                    cmd.Parameters.Add("@user_name", SqlDbType.VarChar).Value = userName;
                    cmd.Parameters.Add("@work_order", SqlDbType.VarChar).Value = workOrder;
                    cmd.Parameters.Add("@comments", SqlDbType.VarChar).Value = comments;
                    cmd.Parameters.Add("@furnace_measure_tb", SqlDbType.Structured).Value = fMTb;


                    conn.Open();

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void UpdateFurnaceMeasure(int idLine, int idMeasure, string userName, string workOrder, string comments, List<Dictionary<string, object>> furnaceMeasureTb)
        {
            var fMTb = new DataTable("[dbo].[furnace_measure_tb]");
            fMTb.Columns.Add("zone_code", typeof(String));
            fMTb.Columns.Add("variable_code", typeof(String));
            fMTb.Columns.Add("side", typeof(String));
            fMTb.Columns.Add("burner_number", typeof(String));
            fMTb.Columns.Add("value", typeof(Double));
            fMTb.Columns.Add("measure_date", typeof(DateTime));
            fMTb.Columns.Add("color", typeof(String));

            foreach (var fm in furnaceMeasureTb)
            {
                var row = fMTb.NewRow();
                foreach (var k in fm.Keys)
                {
                    row[k] = fm[k] ?? DBNull.Value;
                }
                fMTb.Rows.Add(row);
            }

            using (var conn = new SqlConnection(connection))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "[proc].[usp_web_put_furnace_measure]";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@id_line", SqlDbType.Int).Value = idLine;
                    cmd.Parameters.Add("@id_measure", SqlDbType.Int).Value = idMeasure;
                    cmd.Parameters.Add("@user_name", SqlDbType.VarChar).Value = userName;
                    cmd.Parameters.Add("@work_order", SqlDbType.VarChar).Value = workOrder;
                    cmd.Parameters.Add("@comments", SqlDbType.VarChar).Value = comments;
                    cmd.Parameters.Add("@furnace_measure_tb", SqlDbType.Structured).Value = fMTb;
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public List<Dictionary<string, string>> GetFurnaceMeasure(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_report_furnace_measure]", parameters);
        }

        public object GetFurnaceMeasureDetail(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_furnace_measure_detail]", parameters);
        }

        public List<Dictionary<string, string>> GetDrossMapping(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_dross_mapping]", parameters);
        }

        public List<Dictionary<string, string>> GetOvenFlow(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_oven_flow]", parameters);
        }

        public List<Dictionary<string, string>> GetFurnaceCombustionTags(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_furneace_combustion_tags]", parameters);
        }

        public List<Dictionary<string, string>> GetFlowRelation(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_flow_relation]", parameters);
        }

        public Dictionary<string, List<Dictionary<string, string>>> GetCoverageDistribution(Dictionary<string, object> parameters)
        {
            var dataNames = new[] { "Summary", "Graphics", "Detail" };
            return this.dbUtils.ExecuteMultipleReaderDictionary("[proc].[usp_web_get_coverage_distribution]", dataNames, parameters);
        }

        public List<Dictionary<string, string>> GetWeldersReport(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_welders_report]", parameters);
        }

        public List<Dictionary<string, string>> GetCoverages(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_get_web_coverages]", parameters);
        }

		#region Control Panel

        public Dictionary<string, string> GetControlPanelVariableConfig(Dictionary<string, object> parameters)
        {
            return dbUtils.ExecuteReaderDictionary("[panel].[usp_web_get_variables_cfg]", parameters);
        }

        public DataTable GetControlPanelMainTree(Dictionary<string, object> parameters)
        {
            return dbUtils.ExecuteReaderDataTable("[panel].[usp_web_get_main_tree]", parameters);
        }

        public DataTable GetControlPanelData(Dictionary<string, object> parameters)
        {
            return dbUtils.ExecuteReaderDataTable("[panel].[usp_web_get_panel_main_data]", parameters);
        }

        public List<Dictionary<string, string>> GetControlPanelTable(string spName, Dictionary<string, object> parameters)
        {
            return dbUtils.ExecuteReaderDictionaryList(spName, parameters);
        }

        #endregion
        //Dashboard Process Variables
        // Board
        public Dictionary<string, List<Dictionary<string, string>>> GetDashboardProcessVariableInfo(Dictionary<string, object> parameters)
        {
            var dataNames = new[] { "Summary", "Data" };
            return this.dbUtils.ExecuteMultipleReaderDictionary("[proc].[usp_web_get_process_vars_dashboard_info]", dataNames, parameters);
        }

        public List<Dictionary<string, string>> GetDashboardProcessVariableData(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_process_vars_dashboard_data]", parameters);
        }

        //Datail

        public Dictionary<string, List<Dictionary<string, string>>> GetProcessVariableDashboardDetailInfo(Dictionary<string, object> parameters)
        {
            var dataNames = new[] { "Summary", "Data", "Variables" };
            return this.dbUtils.ExecuteMultipleReaderDictionary("[proc].[usp_web_get_process_vars_dashboard_detail_info]", dataNames, parameters);
        }

        public List<Dictionary<string, string>> GetProcessVariableDashboardDetailData(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_process_vars_dashboard_detail_data]", parameters);
        }
        //Retained

        public List<Dictionary<string, string>> GetProcessVariableDashboardDetailRetained(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_process_vars_dashboard_detail_summary]", parameters);
        }

        //Production Plan
        public List<Dictionary<string, string>> GetProcessVariableDashboardDetailProductionPlan(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_process_vars_dashboard_detail_general_purpose]", parameters);
        }

        //Defects
        public List<Dictionary<string, string>> GetProcessVariableDashboardDetailDefects(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_process_vars_dashboard_detail_defects]", parameters);
        }

        //Curves

        public Dictionary<string, List<Dictionary<string, string>>> GetProcessVariableDashboardCurveInfo(Dictionary<string, object> parameters)
        {
            var dataNames = new[] { "Summary", "Graphs" };
            return this.dbUtils.ExecuteMultipleReaderDictionary("[proc].[usp_web_get_process_vars_dashboard_curve_info]", dataNames, parameters);
        }

        public List<Dictionary<string, string>> GetMaterialsByShift(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_materials]", parameters);
        }

        //Filtros para Dashboard
        public List<Dictionary<string, string>> GetDashboardFilters(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_process_vars_dashboard_filters]", parameters);
        }

        //Materiales segun Filtros
        public List<Dictionary<string, string>> GetDashboardMaterialsFilters(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_process_vars_dashboard_materials_by_filters]", parameters);
        }

        //Data
        public Dictionary<string, List<Dictionary<string, string>>> GetProcessVariableDashboardCurveData(Dictionary<string, object> parameters)
        {
            var dataNames = new[] { "Summary", "Data" };
            return this.dbUtils.ExecuteMultipleReaderDictionary("[proc].[usp_web_get_process_vars_dashboard_curve_data]", dataNames, parameters);
        }

        //Data 4 Graph
        public Dictionary<string, List<Dictionary<string, string>>> GetProcessVariableDashboardCurveDataS4(Dictionary<string, object> parameters)
        {
            var dataNames = new[] { "Summary", "Data" };
            return this.dbUtils.ExecuteMultipleReaderDictionary("[proc].[usp_web_get_process_vars_dashboard_curve_data]", dataNames, parameters);
        }


        // Process Variables Panel

        public Dictionary<string, List<Dictionary<string, string>>> GetProcessVariableTree(Dictionary<string, object> parameters)
        {
            var dataNames = new[] { "Summary", "Data", "Variables", "Filters" };
            return this.dbUtils.ExecuteMultipleReaderDictionary("[proc].[usp_web_get_panel_tree]", dataNames, parameters);
        }

        public List<Dictionary<string, string>> GetProcessVariableData(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_panel_data]", parameters);
        }

        
        // Welding Online        
        public Dictionary<string, List<Dictionary<string, string>>> GetProcessWeldingOnlineData(Dictionary<string, object> parameters)
        {
            var dataNames = new[] { "Bobinas", "Estados", "Recalcos", "EstadoTag" };
            return dbUtils.ExecuteMultipleReaderDictionary("[prod].[usp_web_get_welding_online]", dataNames, parameters);
        }

		public List<Dictionary<string, string>> GetMaterialEventClog(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_material_event_clog]", parameters);
        }

        public Dictionary<string, List<Dictionary<string, string>>> GetAverageScoop(Dictionary<string, object> parameters)
        {
            var dataNames = new[] { "Summary", "Data", "AverageScoop","AverageScoopTotal", "AverageFondo", "AverageFondoTotal", 
                                    "TransPeso", "TransTotal", "StandGrua", "StandTotal" };
            return this.dbUtilsAce.ExecuteMultipleReaderDictionary("[prod].[usp_web_getReporteCierreCuchara]", dataNames, parameters);
        }

        public List<Dictionary<string, string>> GetAverageSteel(Dictionary<string, object> parameters)
        {
            return this.dbUtilsAce.ExecuteReaderDictionaryList("[prod].[usp_web_getPromedioFondoCuchara]", parameters);
        }

        public List<Dictionary<string, string>> GetPercentageCierre(Dictionary<string, object> parameters)
        {
            return this.dbUtilsAce.ExecuteReaderDictionaryList("[prod].[usp_web_getPorcentajeCierreCuchara]", parameters);
        }
        // Obtener los multiheader padres de variables de procesos
        public List<Dictionary<string, string>> GetMultiheadersProcessVariable(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_process_vars_multiheader]", parameters);
        }
        // Obtener los multiheader hijos de variables de procesos
        public List<Dictionary<string, string>> GetReportAllColumnsMultiheadersProcessVariable(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_report_all_columns_process_vars_multiheader]", parameters);
        }

        public List<Dictionary<string, string>> GetReportMultiHeaderData(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_flow_assessment_generic]", parameters);
        }

        public List<Dictionary<string, string>> GetSheetGanttFlow(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_sheet_gantt_flows]", parameters);
        }

        public List<Dictionary<string, string>> GetFlowGeneralData(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_flow_general_data]", parameters);
        }

        public List<Dictionary<string, string>> GetLineDelays(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_production_delays]", parameters);
        }

        public Dictionary<string, List<Dictionary<string, string>>> GetProcessVariableAllData(Dictionary<string, object> parameters)
        {
            var dataNames = new[] { "CountInfo", "Data" };
            return this.dbUtils.ExecuteMultipleReaderDictionary("[dbo].[usp_web_get_variable_proccess]", dataNames, parameters);
        }

        public Dictionary<string, List<Dictionary<string, string>>> GetProcessVariableAllDataXml(Dictionary<string, object> parameters)
        {
            var dataNames = new[] { "CountInfo", "Data" };
            return this.dbUtils.ExecuteMultipleReaderDictionary("[dbo].[usp_web_get_variable_proccess_xml]", dataNames, parameters);
        }

        public Dictionary<string, List<Dictionary<string, string>>> GetEvolutionWeldingVariables(Dictionary<string, object> parameters)
        {
            var dataNames = new[] { "VariablesElectrical", "VariablesRecal" };
            return this.dbUtils.ExecuteMultipleReaderDictionary("[proc].[usp_get_web_evolution_welding_variables]", dataNames, parameters);
        }

        public List<Dictionary<string, string>> GetLabResultsDashboard(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[proc].[usp_web_get_process_vars_dashboard_curve_lab_results]", parameters);
        }
    }
}
