﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DataAccess.cs" company="Ternium, S.A">
//   Ternium Siderar.
// </copyright>
// <summary>
//   DataAccess Object.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Ternium.Sio_Server.Models.Repository
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data;
    using System.Data.SqlClient;

    using Sio.Shared.Utils;
    using Ternium.Sio_Server.Models.Curves;
    using Ternium.Sio.Shared.Models;
    using System.Linq;

    /// <summary>
    /// DataAccess Object.
    /// </summary>
    public class DABase
    {
        /// <summary>
        /// The connection.
        /// </summary>
        private readonly string connection;

        /// <summary>
        /// The database utility connection.
        /// </summary>
        private DbUtils dbUtils;

        /// <summary>
        /// Initializes a new instance of the <see cref="DAProduction"/> class.        
        /// </summary>
        public DABase()
        {
            this.connection = ConfigurationManager.ConnectionStrings["DSSIO_LAM"].ConnectionString;
            this.dbUtils = new DbUtils(this.connection);
        }

        public static DataTable ConvertToDataTable(List<Dictionary<string, string>> dictionaryList)
        {
            var result = new DataTable();
            if (dictionaryList == null || dictionaryList.Count == 0)
            {
                return result;
            }

            var columnNames = dictionaryList.SelectMany(d => d.Keys).Distinct();
            result.Columns.AddRange(columnNames.Select(c => new DataColumn(c)).ToArray());
            foreach (Dictionary<string, string> item in dictionaryList)
            {
                var row = result.NewRow();
                foreach (var key in item.Keys)
                {
                    row[key] = item[key];
                }

                result.Rows.Add(row);
            }

            return result;
        }

        public static void ExecuteNonQuerySP(string connection, string sp_name, Dictionary<string, object> parameters)
        {
            using (var conn = new SqlConnection(connection))
            {
                using (var cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = sp_name;
                    cmd.CommandType = CommandType.StoredProcedure;
                    foreach (var item in parameters)
                    {
                        cmd.Parameters.Add(item.Key, SqlDbType.NVarChar).Value = item.Value;
                    }

                    conn.Open();

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public Dictionary<string, string> GetDataDictionary(string spName, Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionary(spName, parameters);
        }

        public List<Dictionary<string, string>> GetDataDictionaryList(string spName, Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList(spName, parameters);
        }

        public Dictionary<string, List<Dictionary<string, string>>> GetDataMultipleDictionaryList(string spName, string[] dataNames, Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteMultipleReaderDictionary(spName, dataNames, parameters);
        }

        /// <summary>
        /// The get list process
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The <see cref="IDictionary"/>.
        /// </returns>
        public List<Dictionary<string, string>> GetListProcess()
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_processes]", new Dictionary<string, object>());
        }

        /// <summary>
        /// The get list plants
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The <see cref="IDictionary"/>.
        /// </returns>
        public List<Dictionary<string, string>> GetListPlants(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_plants]", parameters);
        }
        
        /// <summary>
        /// The get list Squad
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The <see cref="IDictionary"/>.
        /// </returns>
        public List<Dictionary<string, string>> GetSquad(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[prod].[usp_web_get_squads]", parameters);
        }

        /// <summary>
        /// The get list lines
        /// </summary>
        /// <param name="parameters">
        /// The parameters.
        /// </param>
        /// <returns>
        /// The <see cref="IDictionary"/>.
        /// </returns>
        public List<Dictionary<string, string>> GetListLines(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_lines]", parameters);
        }

        public Dictionary<string, string> GetLineInfo(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionary("dbo.usp_web_get_line_info", parameters);
        }

        public List<Dictionary<string, string>> GetAvailableMetricsInfo(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_available_gantt_metrics]", parameters);
        }

        public Dictionary<string, string> GetGenericReportConfig(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionary("cfg.usp_web_get_generic_report_cfg", parameters);
        }

        public List<Dictionary<string, string>> GetShifts(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_shifts_info]", parameters);
        }

        public List<Dictionary<string, string>> GetGenericReportData(string sp_cnn_name, string sp_data, Dictionary<string, object> parameters)
        {
            if (!string.IsNullOrEmpty(sp_cnn_name))
            {
                this.dbUtils = null;
                var connection = ConfigurationManager.ConnectionStrings[sp_cnn_name].ConnectionString;
                this.dbUtils = new DbUtils(connection);
            }

            return this.dbUtils.ExecuteReaderDictionaryList(sp_data, parameters);
        }

        public Dictionary<string, string>  GetReportConfig(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionary("cfg.usp_web_get_report_cfg", parameters);
        }

        public Dictionary<string, List<Dictionary<string, string>>> GetReportUserConfig(Dictionary<string, object> parameters)
        {
            var dataNames = new[] { "UserConfig", "DefaultConfig" };
            return this.dbUtils.ExecuteMultipleReaderDictionary("[cfg].[usp_web_get_report_user_cfg]", dataNames, parameters);
        }

        public Dictionary<string, string> SetReportUserConfig(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionary("[cfg].[usp_web_store_report_user_cfg]", parameters);
        }


        public List<Dictionary<string, string>> GetGenericReportFilters(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[cfg].[usp_web_get_generic_report_filters]", parameters);
        }

        public List<Dictionary<string, string>> GetGenericReportFiltersData(Dictionary<string, object> parameters,string sp_name)
        {
            return this.dbUtils.ExecuteReaderDictionaryList(sp_name, parameters);
        }

        public List<Dictionary<string, string>> GetMultiheaders(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_multiheader]", parameters);
        }

        public List<Dictionary<string, string>> GetReportAllColumnsMultiheaders(Dictionary<string, object> parameters)
        {
            return this.dbUtils.ExecuteReaderDictionaryList("[dbo].[usp_web_get_report_all_columns_multiheader]", parameters);
        }
    }
}
