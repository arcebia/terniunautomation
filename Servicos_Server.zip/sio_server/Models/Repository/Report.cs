﻿using System;

namespace Ternium.Sio_Server.Models.Repository
{
    /// <summary>
    /// Report Object
    /// </summary>
    public class Report
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public Report()
        {
            this.CurrentDate = DateTime.Now;
        }

        /// <summary>
        /// 
        /// </summary>
        public string ReportName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public short GanttType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public short HasSummary { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public short HasSpeed { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public short ToolbarType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public short CurrentTurn { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTime CurrentDate { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTime CurrentShiftStartDate { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTime CurrentShiftEndDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string CurrentDateString => $"{this.CurrentDate:yyyy-MM-dd}";

        /// <summary>
        /// 
        /// </summary>
        public string CurrentDateStringDMY => $"{this.CurrentDate:dd/MM/yyyy}";

        /// <summary>
        /// 
        /// </summary>
        public string CurrentShiftStartDateString => $"{this.CurrentShiftStartDate:yyyy-MM-dd HH:mm:ss}";

        /// <summary>
        /// 
        /// </summary>
        public string CurrentShiftEndDateString => $"{this.CurrentShiftEndDate:yyyy-MM-dd HH:mm:ss}";
    }
}