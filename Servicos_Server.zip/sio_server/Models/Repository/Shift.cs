﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Shift.cs" company="">
//   
// </copyright>
// <summary>
//   Defines the Shift type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Ternium.Sio_Server.Models.Repository
{
    /// <summary>
    /// The shift.
    /// </summary>
    public class Shift
    {
        /// <summary>
        /// Gets or Sets Shift Number
        /// </summary>
        public int ShiftNumber { get; set; }

        /// <summary>
        /// Gets or Sets Shift Start 
        /// </summary>
        public string Start { get; set; }

        /// <summary>
        /// Gets or Sets Shift End
        /// </summary>
        public string End { get; set; }
    }
}