﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ternium.Sio_Server.Models
{
    public class GenericReportParams
    {
        public int IdGenericReport { get; set; }

        public int? IdReport { get; set; }

        public int IdLine { get; set; }

        public string SpDataName { get; set; }

        public string SpCnnName { get; set; }

        public Dictionary<string, object> SpParameters { get; set; }
    }
}