﻿namespace Ternium.Sio_Server.Models
{
    using System.Collections.Generic;

    using Repository;

    /// <summary>
    /// Line Report Data Repository Configuration
    /// </summary>
    public class LineReportData
    {
        /// <summary>
        /// Gets or Sets LineConfig
        /// </summary>
        public Line LineConfig { get; set; }

        /// <summary>
        /// Gets or Sets ReportConfig
        /// </summary>
        public Report ReportConfig { get; set; }

        /// <summary>
        /// Gets or Sets ReportConfig
        /// </summary>
        public List<Shift> Shifts { get; set; }
     
        
    }
}