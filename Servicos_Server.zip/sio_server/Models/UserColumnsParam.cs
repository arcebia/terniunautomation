﻿namespace Ternium.Sio_Server.Models
{
    
    /// <summary>
    /// Input parameters to store the selected columns by the user.
    /// </summary>
    public class UserColumnsParam
    {
        /// <summary>
        /// Gets or sets the User.
        /// </summary>
        public string User { get; set; }
        /// <summary>
        /// Gets or sets the Id Line.
        /// </summary>
        
        public int IdLine { get; set; }

        /// <summary>
        /// Gest or Sets the Id Report
        /// </summary>
        public int IdReport { get; set; }

        /// <summary>
        /// Gest or Sets the Columns. col1,col2,...,coln
        /// </summary>
        public string Columns { get; set; }

    }
}