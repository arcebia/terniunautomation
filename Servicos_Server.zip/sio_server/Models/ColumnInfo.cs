﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;

namespace Ternium.Sio_Server.Models
{
    public class ColumnInfo
    {
        public ColumnInfo(Dictionary<string, string> column)
        {
           var properties = this.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);
           foreach (var property in properties)
           {
              if (column.ContainsKey(property.Name))
              {
                  property.SetValue(this, column[property.Name]);
              }
           }
               //.ToDictionary(prop => prop.Name, prop => prop.GetValue(someObject, null))
        }

        public ColumnInfo()
        {

        }

        public string display_name { get; set; }
        public string alias_column { get; set; }
        public string frontier_column { get; set; }
        public string has_template { get; set; }
        public string id_column { get; set; }
        public string id_line { get; set; }
        public string id_report { get; set; }
        public string order { get; set; }
        public string pinned { get; set; }
        public string to_show { get; set; }
        public string width { get; set; }
        public int rowspan { get; set; }
        public int colspan { get; set; }
        public int level { get; set; }
        public int max_levels { get; set; }
        public List<ColumnInfo> child_columns { get; set; }
    }
}