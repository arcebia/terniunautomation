﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ternium.Sio_Server.Models
{
    public class GenericReportParamsExport
    {
        public int IdLine { get; set; }
        public int IdReport { get; set; }
        public int IdGenericReport { get; set; }
        public Dictionary<string, object> SpParameters { get; set; }
    }
}