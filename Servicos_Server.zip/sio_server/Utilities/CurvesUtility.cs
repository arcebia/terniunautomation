﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Web;

namespace Ternium.Sio_Server.Utilities
{   
    public static class CurvesUtility
    {
        public static Dictionary<string, object> Decodex64Curve3D(Dictionary<string, string> curve, bool isInverted = false)
        {

            string curveX64 = curve["curve"];
            Dictionary<string, object> grafica = new Dictionary<string, object>();
            List<double> _ValoresPlano = new List<double>();
            List<object> _ValoresSerie = new List<object>();
            List<double> _tmp_eje_x_data = new List<double>();
            List<object> _ValoresYAxis = new List<object>();
            List<object> _ValoresXAxis = new List<object>();
            List<object> _xLabelsZones = new List<object>();
            List<double> y_axis = new List<double>();
            List<double> zonas = new List<double>();
            byte[] _btDecode64;
            byte[] _btUnZip;
            BinaryReader _brCurva = null;
            MemoryStream _msDecode64 = new MemoryStream();
            MemoryStream _msUnZip = new MemoryStream();
            GZipStream _zipStream;
            byte[] _UnzipInfoSizeBytes = new byte[4];
            int _UnzipInfoSize;
            double _ValorDoble;

            try
            {
                _btDecode64 = System.Convert.FromBase64String(curveX64);

                _msDecode64 = new MemoryStream(_btDecode64);
                _msDecode64.Seek(0, SeekOrigin.Begin);

                _zipStream = new GZipStream(_msDecode64, CompressionMode.Decompress);

                // Obtenemos el tamaño del archivo comprimido
                _msDecode64.Position = _msDecode64.Length - 4;
                _msDecode64.Read(_UnzipInfoSizeBytes, 0, 4);
                _UnzipInfoSize = System.BitConverter.ToInt32(_UnzipInfoSizeBytes, 0);
                _msDecode64.Position = 0;

                _btUnZip = new byte[_UnzipInfoSize - 1 + 1];
                _UnzipInfoSize = _zipStream.Read(_btUnZip, 0, _UnzipInfoSize);

                _msUnZip = new MemoryStream(_btUnZip);
                _msUnZip.Seek(0, SeekOrigin.Begin);

                _brCurva = new BinaryReader(_msUnZip);
                while (_msUnZip.Position < _msUnZip.Length)
                {
                    _ValorDoble = _brCurva.ReadDouble();
                    _ValoresPlano.Add(_ValorDoble);
                }
            }
            finally
            {
                if (_brCurva != null)
                    _brCurva.Close();
                if (_msUnZip != null)
                    _msUnZip.Close();
                if (_msDecode64 != null)
                    _msDecode64.Close();
            }


            if (_ValoresPlano.Count > 0)
            {
                var rodillos = _ValoresPlano[0];
                rodillos = rodillos - 1; // Temporal
                
                int puntos = (int) _ValoresPlano[1];
                // Aqui ya tenemos los valores de EjeX y los puntos de los planos, confirmamos que sean los mismos puntos
                if ((puntos * (rodillos + 1)) == (_ValoresPlano.Count - 2)){

                    var saltos = 2;
                    var saltar = false;

                    for (int i = saltos; i < (puntos + saltos); i++)
                    {
                        y_axis.Add(_ValoresPlano[i]);
                    }

                    for (int i = 1; i <= rodillos; i++){

                        zonas = new List<double>();

                        _tmp_eje_x_data = new List<double>();
                        int top = (saltos + puntos) - 1;
                        if (saltar)
                        {
                            for (int j = saltos; j <= top; j++)
                            {
                                _tmp_eje_x_data.Add(_ValoresPlano[j]);
                                zonas.Add(i - 1);
                            }

                            if (!(_tmp_eje_x_data.Max() == 0 && _tmp_eje_x_data.Min() == 0)) // Si toda la fila es 0, no se agrega esa zona/rodillo
                            {
                                 _ValoresSerie.Add(_tmp_eje_x_data.ToArray());
                                 _ValoresYAxis.Add(zonas);
                                 _xLabelsZones.Add("Z" + (i - 1));
                            }

                            _ValoresXAxis.Add(y_axis.ToArray());
                        }
                        else
                        {
                            saltar = true;
                        }
                        
                        saltos += puntos;
                    }
                    
                    int tot = puntos + 2;
                    double max_value_series = _ValoresPlano.Max();
                    int _tickRange = 0;
                    if (IsInRange(max_value_series,0,2000))
                    {
                        _tickRange = 100;
                    }
                    else if (IsInRange(max_value_series, 2000, 4000))
                    {
                        _tickRange = 200;
                    }
                    else if (IsInRange(max_value_series, 4000, 6000))
                    {
                        _tickRange = 300;
                    }
                    
                    _ValoresPlano.RemoveRange(0, tot);

                    grafica = new Dictionary<string, object>
                    {
                         { "series", _ValoresSerie.ToArray() },
                         {"y_axis", _ValoresYAxis.ToArray()},
                         {"x_axis",_ValoresXAxis.ToArray()},
                         {"x_axis_tick_text",_xLabelsZones.ToArray()},
                         {"max",_ValoresPlano.Max()},
                         {"min",_ValoresPlano.Min()},
                         {"tick_series",_tickRange},
                         {"id_variable_type",curve["id_variable_type"]},
                         {"id_variable",curve["id_variable"]},
                         {"description",curve["description"]}                       
                    };


                }

            }

            return grafica;
        }


        public static bool IsInRange(this double value, int minimum, int maximum)
        {
            return value >= minimum && value <= maximum;
        }

        public static List<double> Decodex64Curve(string curveX64, bool isInverted = false)
        {
            var values = new List<double>();
            var btUnZip = new byte[1024];
            BinaryReader brCurve = null;
            var msDecode64 = new MemoryStream();
            var msUnZip = new MemoryStream();
            var unzipInfoSizeBytes = new byte[4];

            if (curveX64.Length <= 0)
            {
                return values;
            }

            try
            {
                var btDecode64 = Convert.FromBase64String(curveX64);

                msDecode64 = new MemoryStream(btDecode64);
                msDecode64.Seek(0, SeekOrigin.Begin);

                var zipStream = new GZipStream(msDecode64, CompressionMode.Decompress);

                //Obtenemos el tamaño del archivo comprimido.
                msDecode64.Position = msDecode64.Length - 4;
                msDecode64.Read(unzipInfoSizeBytes, 0, 4);
                var unzipInfoSize = BitConverter.ToInt32(unzipInfoSizeBytes, 0);
                msDecode64.Position = 0;

                var newSize = unzipInfoSize;
                Array.Resize(ref btUnZip, newSize);
                zipStream.Read(btUnZip, 0, unzipInfoSize);

                msUnZip = new MemoryStream(btUnZip);
                msUnZip.Seek(0, SeekOrigin.Begin);

                brCurve = new BinaryReader(msUnZip);
                while (msUnZip.Position < msUnZip.Length)
                {
                    var doubleValue = brCurve.ReadDouble();
                    values.Add(doubleValue);
                }
            }
            catch (Exception)
            {
                // ignored
            }
            finally
            {
                if (brCurve != null)
                    brCurve.Close();

                msUnZip.Close();
                msDecode64.Close();
            }

            return isInverted ? values.ToArray().Reverse().ToList() : values;
        }
    }
}