﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using Ternium.Sio_Server.Controllers;

namespace Ternium.Sio_Server.Utilities
{
    public class ExcelUtility
    {
        // Get the excel column letter by index
        public static string ColumnLetter(int intCol)
        {
            int intFirstLetter = ((intCol) / 676) + 64;
            int intSecondLetter = ((intCol % 676) / 26) + 64;
            int intThirdLetter = (intCol % 26) + 65;

            char FirstLetter = (intFirstLetter > 64) ? (char)intFirstLetter : ' ';
            char SecondLetter = (intSecondLetter > 64) ? (char)intSecondLetter : ' ';
            char ThirdLetter = (char)intThirdLetter;

            return string.Concat(FirstLetter, SecondLetter, ThirdLetter).Trim();
        }

        // Create a text cell
        private static Cell CreateTextCell(string header, UInt32 index, string text)
        {
            var cell = new Cell { DataType = CellValues.InlineString, CellReference = header + index };
            var istring = new InlineString();
            var t = new Text { Text = text };
            istring.Append(t);
            cell.Append(istring);
            return cell;
        }

        public static MemoryStream GetExcel(DataTable data)
        {
            string[] fieldsToExpose = new string[data.Columns.Count];
            for (int i = 0; i < data.Columns.Count; i++)
            {
                fieldsToExpose[i] = data.Columns[i].ColumnName;
            }

            return GetExcel(fieldsToExpose, data);
        }

        public static MemoryStream GetExcel(string[] fieldsToExpose, DataTable data)
        {
            MemoryStream stream = new MemoryStream();
            UInt32 rowcount = 0;

            // Create the Excel document
            var document = SpreadsheetDocument.Create(stream, SpreadsheetDocumentType.Workbook);
            var workbookPart = document.AddWorkbookPart();
            var worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
            var relId = workbookPart.GetIdOfPart(worksheetPart);

            var workbook = new Workbook();
            var fileVersion = new FileVersion { ApplicationName = "Microsoft Office Excel" };
            var worksheet = new Worksheet();
            var sheetData = new SheetData();
            worksheet.Append(sheetData);
            worksheetPart.Worksheet = worksheet;

            var sheets = new Sheets();
            var sheet = new Sheet { Name = "Sheet1", SheetId = 1, Id = relId };
            sheets.Append(sheet);
            workbook.Append(fileVersion);
            workbook.Append(sheets);
            document.WorkbookPart.Workbook = workbook;
            document.WorkbookPart.Workbook.Save();

            // Add header to the sheet
            var row = new Row { RowIndex = ++rowcount };
            for (int i = 0; i < fieldsToExpose.Length; i++)
            {
                row.Append(CreateTextCell(ColumnLetter(i), rowcount, fieldsToExpose[i]));
            }
            sheetData.AppendChild(row);
            worksheetPart.Worksheet.Save();

            // Add data to the sheet
            foreach (DataRow dataRow in data.Rows)
            {
                row = new Row { RowIndex = ++rowcount };
                for (int i = 0; i < fieldsToExpose.Length; i++)
                {
                    row.Append(CreateTextCell(ColumnLetter(i), rowcount, dataRow[fieldsToExpose[i]].ToString()));
                }
                sheetData.AppendChild(row);
            }
            worksheetPart.Worksheet.Save();

            document.Close();
            return stream;
        }

        public static MemoryStream GetExcelMultipleSheets(Dictionary<string, List<Dictionary<string, string>>> originalData) 
        {
            MemoryStream stream = new MemoryStream();
            SpreadsheetDocument ssDoc = SpreadsheetDocument.Create(stream, SpreadsheetDocumentType.Workbook);
            WorkbookPart workbookPart = ssDoc.AddWorkbookPart();

            Workbook workbook = new Workbook();
            FileVersion fileVersion = new FileVersion { ApplicationName = "Microsoft Office Excel" };
            Sheets sheets = new Sheets();

            int count = 0;
            DataTable data = new DataTable();
            workbook.Append(fileVersion);
            workbook.Append(sheets);

            ssDoc.WorkbookPart.Workbook = workbook;
            ssDoc.WorkbookPart.Workbook.Save();

            foreach (var item in originalData)
            {
                data = ExportController.GetDataToExportOutColumns(item.Value);
                WorksheetPart worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
                Worksheet workSheet = new Worksheet();
                SheetData sheetData = new SheetData();

                //workSheet.Append(sheetData);
                //worksheetPart.Worksheet = workSheet;

                string[] fieldsToExpose = new string[data.Columns.Count];
                for (int i = 0; i < data.Columns.Count; i++)
                {
                    fieldsToExpose[i] = data.Columns[i].ColumnName;
                }

                UInt32 rowcount = 1;
                Row rowInSheet1 = new Row();
                for (int i = 0; i < fieldsToExpose.Length; i++)
                {
                    Cell emptyCell = CreateTextCell(ColumnLetter(i), rowcount, fieldsToExpose[i]);
                    rowInSheet1.Append(emptyCell);
                }
                sheetData.AppendChild(rowInSheet1);
                //worksheetPart.Worksheet.Save();

                //Add data to the sheet
                foreach (DataRow dataRow in data.Rows)
                {
                    rowInSheet1 = new Row { RowIndex = ++rowcount };
                    for (int i = 0; i < fieldsToExpose.Length; i++)
                    {
                        Cell cell2 = CreateTextCell(ColumnLetter(i), rowcount, dataRow[fieldsToExpose[i]].ToString());

                        rowInSheet1.Append(cell2);
                    }
                    sheetData.AppendChild(rowInSheet1);
                }
                workSheet.AppendChild(sheetData);
                worksheetPart.Worksheet = workSheet;

                Sheet sheet = new Sheet()
                {
                    Id = ssDoc.WorkbookPart.GetIdOfPart(worksheetPart),
                    SheetId = (UInt32)count,
                    Name = item.Key
                };
                sheets.Append(sheet);
                count++;
                //worksheetPart.Worksheet.Save();
            }

            ssDoc.Close();
            return stream;
        }

        public static MemoryStream GetExcelMultipleSheets2(Dictionary<string, List<Dictionary<string, string>>> originalData)
        {
            //Create document
            MemoryStream stream = new MemoryStream();
            SpreadsheetDocument ssDoc = SpreadsheetDocument.Create(stream, SpreadsheetDocumentType.Workbook);

            WorkbookPart workbookPart = ssDoc.AddWorkbookPart();
            workbookPart.Workbook = new Workbook();
            Sheets sheets = ssDoc.WorkbookPart.Workbook.AppendChild<Sheets>(new Sheets());

            // Begin: Code block for Excel sheet 1
            WorksheetPart worksheetPart1 = workbookPart.AddNewPart<WorksheetPart>();
            Worksheet workSheet1 = new Worksheet();
            SheetData sheetData1 = new SheetData();

            worksheetPart1.Worksheet = workSheet1;

            // Add header to the sheet
            DataTable data = new DataTable();
            foreach (var item in originalData)
            {
                data = ExportController.GetDataToExportOutColumns(item.Value);
                switch (item.Key)
                {
                    case "Ejecuciones":
                        string[] fieldsToExpose = new string[data.Columns.Count];
                        for (int i = 0; i < data.Columns.Count; i++)
                        {
                            fieldsToExpose[i] = data.Columns[i].ColumnName;
                        }

                        UInt32 rowcount = 1;
                        Row rowInSheet1 = new Row();
                        for (int i = 0; i < fieldsToExpose.Length; i++)
                        {
                            Cell emptyCell = CreateTextCell(ColumnLetter(i), rowcount, fieldsToExpose[i]);
                            rowInSheet1.Append(emptyCell);
                        }
                        sheetData1.AppendChild(rowInSheet1);

                        //Add data to the sheet
                        foreach (DataRow dataRow in data.Rows)
                        {
                            rowInSheet1 = new Row { RowIndex = ++rowcount };
                            for (int i = 0; i < fieldsToExpose.Length; i++)
                            {
                                Cell cell2 = CreateTextCell(ColumnLetter(i), rowcount, dataRow[fieldsToExpose[i]].ToString());

                                rowInSheet1.Append(cell2);
                            }
                            sheetData1.AppendChild(rowInSheet1);
                        }
                        workSheet1.AppendChild(sheetData1);

                        Sheet sheet1 = new Sheet()
                        {
                            Id = ssDoc.WorkbookPart.GetIdOfPart(worksheetPart1),
                            SheetId = 1,
                            Name = "Ejecuciones"
                        };
                        sheets.Append(sheet1);
                        // End: Code block for Excel sheet 1
                        break;
                    case "2":
                        // Begin: Code block for Excel sheet 2
                        WorksheetPart worksheetPart2 = workbookPart.AddNewPart<WorksheetPart>();
                        Worksheet workSheet2 = new Worksheet();
                        SheetData sheetData2 = new SheetData();

                        // the data for sheet 2
                        Row rowInSheet2 = new Row();
                        string[] fieldsToExpose2 = new string[data.Columns.Count];
                        for (int i = 0; i < data.Columns.Count; i++)
                        {
                            fieldsToExpose2[i] = data.Columns[i].ColumnName;
                        }

                        UInt32 rowcount2 = 1;
                        for (int i = 0; i < fieldsToExpose2.Length; i++)
                        {
                            Cell emptyCell = CreateTextCell(ColumnLetter(i), rowcount2, fieldsToExpose2[i]);
                            rowInSheet2.Append(emptyCell);
                        }
                        sheetData2.AppendChild(rowInSheet2);

                        //Add data to the sheet 2
                        foreach (DataRow dataRow in data.Rows)
                        {
                            rowInSheet2 = new Row { RowIndex = ++rowcount2 };
                            for (int i = 0; i < fieldsToExpose2.Length; i++)
                            {
                                Cell cell2 = CreateTextCell(ColumnLetter(i), rowcount2, dataRow[fieldsToExpose2[i]].ToString());

                                rowInSheet2.Append(cell2);
                            }
                            sheetData2.AppendChild(rowInSheet2);
                        }
                        workSheet2.AppendChild(sheetData2);
                        worksheetPart2.Worksheet = workSheet2;
          

                        Sheet sheet2 = new Sheet()
                        {
                            Id = ssDoc.WorkbookPart.GetIdOfPart(worksheetPart2),
                            SheetId = 2,
                            Name = "Sheet2"
                        };
                        sheets.Append(sheet2);
                        // End: Code block for Excel sheet 2
                        break;
                    case "Defects":
                        // Begin: Code block for Excel sheet 3
                        WorksheetPart worksheetPart3 = workbookPart.AddNewPart<WorksheetPart>();
                        Worksheet workSheet3 = new Worksheet();
                        SheetData sheetData3 = new SheetData();

                        // the data for sheet 3
                        Row rowInSheet3 = new Row();
                        string[] fieldsToExpose3 = new string[data.Columns.Count];
                        for (int i = 0; i < data.Columns.Count; i++)
                        {
                            fieldsToExpose3[i] = data.Columns[i].ColumnName;
                        }

                        UInt32 rowcount3 = 1;
                        for (int i = 0; i < fieldsToExpose3.Length; i++)
                        {
                            Cell emptyCell = CreateTextCell(ColumnLetter(i), rowcount3, fieldsToExpose3[i]);
                            rowInSheet3.Append(emptyCell);
                        }
                        sheetData3.AppendChild(rowInSheet3);

                        //Add data to the sheet 3
                        foreach (DataRow dataRow in data.Rows)
                        {
                            rowInSheet3 = new Row { RowIndex = ++rowcount3 };
                            for (int i = 0; i < fieldsToExpose3.Length; i++)
                            {
                                Cell cell2 = CreateTextCell(ColumnLetter(i), rowcount3, dataRow[fieldsToExpose3[i]].ToString());

                                rowInSheet3.Append(cell2);
                            }
                            sheetData3.AppendChild(rowInSheet3);
                        }
                        workSheet3.AppendChild(sheetData3);
                        worksheetPart3.Worksheet = workSheet3;


                        Sheet sheet3 = new Sheet()
                        {
                            Id = ssDoc.WorkbookPart.GetIdOfPart(worksheetPart3),
                            SheetId = 3,
                            Name = "Defectos"
                        };
                        sheets.Append(sheet3);
                        // End: Code block for Excel sheet 3
                        break;
                    case "Sem":
                        // Begin: Code block for Excel sheet 4
                        WorksheetPart worksheetPart4 = workbookPart.AddNewPart<WorksheetPart>();
                        Worksheet workSheet4 = new Worksheet();
                        SheetData sheetData4 = new SheetData();

                        // the data for sheet 4
                        Row rowInSheet4 = new Row();
                        string[] fieldsToExpose4 = new string[data.Columns.Count];
                        for (int i = 0; i < data.Columns.Count; i++)
                        {
                            fieldsToExpose4[i] = data.Columns[i].ColumnName;
                        }

                        UInt32 rowcount4 = 1;
                        for (int i = 0; i < fieldsToExpose4.Length; i++)
                        {
                            Cell emptyCell = CreateTextCell(ColumnLetter(i), rowcount4, fieldsToExpose4[i]);
                            rowInSheet4.Append(emptyCell);
                        }
                        sheetData4.AppendChild(rowInSheet4);

                        //Add data to the sheet 4
                        foreach (DataRow dataRow in data.Rows)
                        {
                            rowInSheet4 = new Row { RowIndex = ++rowcount4 };
                            for (int i = 0; i < fieldsToExpose4.Length; i++)
                            {
                                Cell cell2 = CreateTextCell(ColumnLetter(i), rowcount4, dataRow[fieldsToExpose4[i]].ToString());

                                rowInSheet4.Append(cell2);
                            }
                            sheetData4.AppendChild(rowInSheet4);
                        }
                        workSheet4.AppendChild(sheetData4);
                        worksheetPart4.Worksheet = workSheet4;


                        Sheet sheet4 = new Sheet()
                        {
                            Id = ssDoc.WorkbookPart.GetIdOfPart(worksheetPart4),
                            SheetId = 4,
                            Name = "Semáforos"
                        };
                        sheets.Append(sheet4);
                        // End: Code block for Excel sheet 4
                        break;
                    case "Statistics":
                        WorksheetPart worksheetPart5 = workbookPart.AddNewPart<WorksheetPart>();
                        Worksheet workSheet5 = new Worksheet();
                        SheetData sheetData5 = new SheetData();

                        Row rowInSheet5 = new Row();
                        string[] fieldsToExpose5 = new string[data.Columns.Count];
                        for (int i = 0; i < data.Columns.Count; i++)
                        {
                            fieldsToExpose5[i] = data.Columns[i].ColumnName;
                        }

                        UInt32 rowcount5 = 1;
                        for (int i = 0; i < fieldsToExpose5.Length; i++)
                        {
                            Cell emptyCell = CreateTextCell(ColumnLetter(i), rowcount5, fieldsToExpose5[i]);
                            rowInSheet5.Append(emptyCell);
                        }
                        sheetData5.AppendChild(rowInSheet5);

                        foreach (DataRow dataRow in data.Rows)
                        {
                            rowInSheet5 = new Row { RowIndex = ++rowcount5 };
                            for (int i = 0; i < fieldsToExpose5.Length; i++)
                            {
                                Cell cell2 = CreateTextCell(ColumnLetter(i), rowcount5, dataRow[fieldsToExpose5[i]].ToString());

                                rowInSheet5.Append(cell2);
                            }
                            sheetData5.AppendChild(rowInSheet5);
                        }
                        workSheet5.AppendChild(sheetData5);
                        worksheetPart5.Worksheet = workSheet5;

                        Sheet sheet5 = new Sheet()
                        {
                            Id = ssDoc.WorkbookPart.GetIdOfPart(worksheetPart5),
                            SheetId = 5,
                            Name = "Estadística"
                        };
                        sheets.Append(sheet5);
                        break;
                    case "Value":
                        WorksheetPart worksheetPart6 = workbookPart.AddNewPart<WorksheetPart>();
                        Worksheet workSheet6 = new Worksheet();
                        SheetData sheetData6 = new SheetData();

                        Row rowInSheet6 = new Row();
                        string[] fieldsToExpose6 = new string[data.Columns.Count];
                        for (int i = 0; i < data.Columns.Count; i++)
                        {
                            fieldsToExpose6[i] = data.Columns[i].ColumnName;
                        }

                        UInt32 rowcount6 = 1;
                        for (int i = 0; i < fieldsToExpose6.Length; i++)
                        {
                            Cell emptyCell = CreateTextCell(ColumnLetter(i), rowcount6, fieldsToExpose6[i]);
                            rowInSheet6.Append(emptyCell);
                        }
                        sheetData6.AppendChild(rowInSheet6);

                        foreach (DataRow dataRow in data.Rows)
                        {
                            rowInSheet6 = new Row { RowIndex = ++rowcount6 };
                            for (int i = 0; i < fieldsToExpose6.Length; i++)
                            {
                                Cell cell2 = CreateTextCell(ColumnLetter(i), rowcount6, dataRow[fieldsToExpose6[i]].ToString());

                                rowInSheet6.Append(cell2);
                            }
                            sheetData6.AppendChild(rowInSheet6);
                        }
                        workSheet6.AppendChild(sheetData6);
                        worksheetPart6.Worksheet = workSheet6;

                        Sheet sheet6 = new Sheet()
                        {
                            Id = ssDoc.WorkbookPart.GetIdOfPart(worksheetPart6),
                            SheetId = 6,
                            Name = "Valores Calculados"
                        };
                        sheets.Append(sheet6);
                        break;
                    case "Analyzed":
                        WorksheetPart worksheetPart7 = workbookPart.AddNewPart<WorksheetPart>();
                        Worksheet workSheet7 = new Worksheet();
                        SheetData sheetData7 = new SheetData();

                        Row rowInSheet7 = new Row();
                        string[] fieldsToExpose7 = new string[data.Columns.Count];
                        for (int i = 0; i < data.Columns.Count; i++)
                        {
                            fieldsToExpose7[i] = data.Columns[i].ColumnName;
                        }

                        UInt32 rowcount7 = 1;
                        for (int i = 0; i < fieldsToExpose7.Length; i++)
                        {
                            Cell emptyCell = CreateTextCell(ColumnLetter(i), rowcount7, fieldsToExpose7[i]);
                            rowInSheet7.Append(emptyCell);
                        }
                        sheetData7.AppendChild(rowInSheet7);

                        foreach (DataRow dataRow in data.Rows)
                        {
                            rowInSheet7 = new Row { RowIndex = ++rowcount7 };
                            for (int i = 0; i < fieldsToExpose7.Length; i++)
                            {
                                Cell cell2 = CreateTextCell(ColumnLetter(i), rowcount7, dataRow[fieldsToExpose7[i]].ToString());

                                rowInSheet7.Append(cell2);
                            }
                            sheetData7.AppendChild(rowInSheet7);
                        }
                        workSheet7.AppendChild(sheetData7);
                        worksheetPart7.Worksheet = workSheet7;

                        Sheet sheet7 = new Sheet()
                        {
                            Id = ssDoc.WorkbookPart.GetIdOfPart(worksheetPart7),
                            SheetId = 7,
                            Name = "Variable Analizada"
                        };
                        sheets.Append(sheet7);
                        break;
                    default:
                        break;
                }
            }
            ssDoc.Close();
            return stream;
            
        }
    }
}