﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.Filters;

namespace Ternium.Sio_Server.Controllers
{
    public class EnableCORS : ActionFilterAttribute
    {
        private string[] origins;
        private string methods;

        public EnableCORS(string[] origins = null, string methods = "*")
        {
            this.origins = origins;
            this.methods = methods;
        }

        public override void OnActionExecuted(HttpActionExecutedContext actionExecutedContext)
        {
            if (this.origins == null || !this.origins.Any() || HttpContext.Current.Request.Headers.GetValues("Origin") == null)
            {
                HttpContext.Current.Response.AppendHeader("Access-Control-Allow-Origin", "*");
            }
            else if (HttpContext.Current.Request.UrlReferrer != null)
            {
                HttpContext.Current.Response.AppendHeader("Access-Control-Allow-Origin", "http://" + HttpContext.Current.Request.UrlReferrer.Authority);
            }
            else
            {  
                var origin = HttpContext.Current.Request.Headers.GetValues("Origin").FirstOrDefault();
                if (origin != null)
                {
                    HttpContext.Current.Response.AppendHeader("Access-Control-Allow-Origin", origin);
                }
                else
                {
                    HttpContext.Current.Response.AppendHeader("Access-Control-Allow-Origin", "*");
                }
            }

            HttpContext.Current.Response.AppendHeader("Access-Control-Allow-Credentials", "true");
            HttpContext.Current.Response.AppendHeader("Access-Control-Allow-Methods", "GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS");
            HttpContext.Current.Response.AppendHeader("Access-Control-Allow-Headers", "Content-Type");
        }
    }  
}