﻿using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Mvc;

namespace LIN.Controllers
{
    public class RDLCController : Controller
    {
        private readonly string deviceInfoTemplate =  
            @"<DeviceInfo>
                <PageWidth>{0}</PageWidth>
                <PageHeight>{1}cm</PageHeight>
                <MarginTop>{2}</MarginTop>
                <MarginLeft>{3}</MarginLeft>
                <MarginRight>{4}</MarginRight>
                <MarginBottom>{5}</MarginBottom>
            </DeviceInfo>";

        private string deviceInfo = "<DeviceInfo>" +
                                     "  <PageWidth>27.94cm</PageWidth>" +
                                     "  <PageHeight>21.59cm</PageHeight>" +
                                     "  <MarginTop>1cm</MarginTop>" +
                                     "  <MarginLeft>1cm</MarginLeft>" +
                                     "  <MarginRight>1cm</MarginRight>" +
                                     "  <MarginBottom>1cm</MarginBottom>" +
                                     "</DeviceInfo>";

        private int id_line = 0;
        public byte[] SequenceProgram(DataTable dataTable, Dictionary<string, string> reportConfig, string report_path)
        {
            LocalReport localReport = new LocalReport();
            localReport.ReportPath = report_path;
            localReport.DataSources.Add(new ReportDataSource("SequenceProgram", dataTable));

            Warning[] warnings;
            string[] streamids;
            string mimeType = "";
            string encoding = "";
            string extension = "";
            byte[] bytes = localReport.Render("PDF", deviceInfo, out mimeType, out encoding, out extension, out streamids, out warnings);

            return File(bytes, mimeType).FileContents;
        }

        public byte[] DefectTest(DataTable dataTable,DataTable dataTableResumen, Dictionary<string, string> reportConfig, DateTime start_date, DateTime end_date, string shift_1, string shift_2, string shift_3, string report_path)
        {
            LocalReport localReport = new LocalReport();
            ReportParameter line = new ReportParameter("LineName", reportConfig["line"]);
            ReportParameter abbreviature = new ReportParameter("Abbreviature", reportConfig["abbreviature"]);
            ReportParameter startDate = new ReportParameter("StartDate", start_date.ToString("dd/MM/yyyy"));
            ReportParameter endDate = new ReportParameter("EndDate", end_date.ToString("dd/MM/yyyy"));
            ReportParameter shift1 = new ReportParameter("shift1", shift_1);
            ReportParameter shift2 = new ReportParameter("shift2", shift_2);
            ReportParameter shift3 = new ReportParameter("shift3", shift_3);
            localReport.ReportPath = report_path;
            localReport.DataSources.Add(new ReportDataSource("DefectTest", dataTable));
            localReport.DataSources.Add(new ReportDataSource("ResumenProduction", dataTableResumen));
            localReport.SetParameters(new ReportParameter[] { line, abbreviature, startDate, endDate, shift1, shift2, shift3 });

            Warning[] warnings;
            string[] streamids;
            string mimeType = "";
            string encoding = "";
            string extension = "";
            byte[] bytes = localReport.Render("PDF", deviceInfo, out mimeType, out encoding, out extension, out streamids, out warnings);

            return File(bytes, mimeType).FileContents;
        }

    }
}