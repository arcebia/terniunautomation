﻿namespace Ternium.Sio_Server.Controllers
{
    using System;
    using System.Web.Http;
    using System.Web.Http.Description;
    using Models;
    using Models.Repository;
    
    /// <summary>
    /// Api Methods for Line and Reports Configuration Data.
    /// </summary>
    [EnableCORS()]
    [RoutePrefix("Api/Configuration")]
    public class ConfigurationController : ApiController
    {
        private readonly DAProduction dataAccess = new DAProduction();

        /// <summary>
        /// Get the line and report configuration.
        /// </summary>
        /// <param name="idLine"></param>
        /// <param name="idReport"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("LineReport/{idLine}/{idReport}")]
        [ResponseType(typeof(LineReportData))]
        public IHttpActionResult GetLineReportConfig(int idLine, int idReport)
        {

            try
            {
                var shifts = dataAccess.GetShiftRanges(idLine);
                var lineConfig = dataAccess.GetLineConfig(idLine);
                var reportConfig = dataAccess.GetReportConfig(idLine, idReport);

                var lineReport = new LineReportData
                                     {
                                         LineConfig = lineConfig,
                                         ReportConfig = reportConfig,
                                         Shifts = shifts
                                     };

                return Ok(lineReport);
            }
            catch (Exception ex)
            {
                return BadRequest("GetLineReportConfig Error => " + ex.Message);
            }
        }

        /// <summary>
        /// Get the line and report configuration.
        /// </summary>
        /// <param name="idLine"></param>        
        /// <returns></returns>
        [HttpGet]
        [Route("Line/{idLine}")]
        [ResponseType(typeof(Line))]
        public IHttpActionResult GetLineConfig(int idLine)
        {
            try
            {
                var lineConfig = dataAccess.GetLineConfig(idLine);
                return Ok(lineConfig);
            }
            catch (Exception ex)
            {
                return BadRequest("GetLineConfig Error => " + ex.Message);
            }
        }

        /// <summary>
        /// Get the report configuration.
        /// </summary>
        /// <param name="idLine"></param>
        /// <param name="idReport"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("Report/{idLine}/{idReport}")]
        [ResponseType(typeof(Report))]
        public IHttpActionResult GetReportConfig(int idLine, int idReport)
        {
            try
            {
                var reportConfig = dataAccess.GetReportConfig(idLine, idReport);
                return Ok(reportConfig);
            }
            catch (Exception ex)
            {
                return BadRequest("GetReportConfig Error => " + ex.Message);
            }
        }
    }
}
