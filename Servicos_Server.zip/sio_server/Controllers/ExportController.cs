﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Http;
using Ternium.Sio_Server.Models;
using Ternium.Sio_Server.Models.Repository;
using Ternium.Sio_Server.Utilities;
using System.Xml;

namespace Ternium.Sio_Server.Controllers
{
    [EnableCORS()]
    public class ExportController : ApiController
    {
        public static DataTable GetDataToExport(List<Dictionary<string, string>> reportData, List<Dictionary<string, string>> columns)
        {
            var rowsToExport = new List<Dictionary<string, string>>();
            var columnHeaders = columns.Where(x => Convert.ToBoolean(x["to_export"]) == true).ToList();
            foreach (var row in reportData)
            {
                var dictionaryToExport = new Dictionary<string, string>();
                if (columnHeaders.Count == 0)
                {
                    foreach (var datarow in row)
                    {
                        dictionaryToExport.Add(datarow.Key, datarow.Value);
                    }
                }
                else
                {
                    foreach (var column in columnHeaders)
                    {
                        var fieldName = column["alias_column"];
                        if (row.ContainsKey(fieldName))
                        {
                            dictionaryToExport.Add(column["display_name"], row[fieldName]);
                        }
                    }
                }
                rowsToExport.Add(dictionaryToExport);
            }

            var reportDataDt = DABase.ConvertToDataTable(rowsToExport);

            return reportDataDt;
        }

        public static DataTable GetDataToExportOutColumns(List<Dictionary<string, string>> reportData)
        {
            List<Dictionary<string, string>> columns = new List<Dictionary<string,string>>();
            List<string> arr = new List<string>();
            if (reportData.Count == 0) return new DataTable();
            foreach (var item in reportData[0])
	        {
                arr.Add(item.Key);		 
	        }

            arr.ToArray();

            foreach (var i in arr)
            {
                var col = new Dictionary<string, string>();
                col.Add("display_name", i);
                columns.Add(col);
            }

            var rowsToExport = new List<Dictionary<string, string>>();
            foreach (var row in reportData)
            {
                var dictionaryToExport = new Dictionary<string, string>();
                foreach (var column in columns)
                {
                    var fieldName = column["display_name"];
                    if (row.ContainsKey(fieldName))
                    {
                        dictionaryToExport.Add(column["display_name"], row[fieldName]);
                    }
                }

                rowsToExport.Add(dictionaryToExport);
            }

            var reportDataDt = DABase.ConvertToDataTable(rowsToExport);

            return reportDataDt;
        }

        public HttpResponseMessage GetMessageExport(HttpStatusCode status, DataTable data, string filename, string error)
        {
            HttpResponseMessage response = new HttpResponseMessage();
            if (status == HttpStatusCode.OK)
            {
                MemoryStream filedata = ExcelUtility.GetExcel(data);

                response.StatusCode = status;
                //application/vnd.ms-excel .xls
                var contenttype = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

                response.Content = new ByteArrayContent(filedata.ToArray());
                response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
                response.Content.Headers.ContentType = new MediaTypeHeaderValue(contenttype);
                response.Content.Headers.ContentDisposition.FileName = filename + ".xlsx";
            }
            else
            {
                response.StatusCode = status;
                response.Content = new StringContent(error);
            }
            return response;
        }

        public HttpResponseMessage GetMessagePublicReportExport(HttpStatusCode status, Dictionary<string, List<Dictionary<string, string>>> data_, string filename, string error)
        {
            HttpResponseMessage response = new HttpResponseMessage();

            if (status == HttpStatusCode.OK)
            {
                DataTable reportDataDt = new DataTable();
                //MemoryStream filedata = new MemoryStream();
                //foreach (var item in data_)
                //{
                //    reportDataDt = ExportController.GetDataToExportOutColumns(item.Value);
                //    filedata = ExcelUtility.GetExcelMultiple(reportDataDt);

                //}

                MemoryStream filedata = ExcelUtility.GetExcelMultipleSheets(data_);                

                //Data es el arreglo puro de BD, ¿hay que apasarlo a dataTable para que "funcione"?

                response.StatusCode = status;
                //application/vnd.ms-excel .xls
                var contenttype = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

                response.Content = new ByteArrayContent(filedata.ToArray());
                // response.Headers.Location = new Uri(Request.RequestUri, string.Format("Hola/{0}", 123));
                response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
                response.Content.Headers.ContentType = new MediaTypeHeaderValue(contenttype);
                response.Content.Headers.ContentDisposition.FileName = filename + ".xlsx";
            }
            else
            {
                response.StatusCode = status;
                response.Content = new StringContent(error);
            }



            return response;
            //return ResponseMessage(Request.CreateResponse(HttpStatusCode.OK, response));
        }

        public HttpResponseMessage GetMessageGenericReportExport(HttpStatusCode status, DataTable data, string filename, string error)
        {
            HttpResponseMessage response = new HttpResponseMessage();
            //Request = new HttpRequestMessage();
            //response.Method = HttpMethod.Post;
            

            if (status == HttpStatusCode.OK)
            {
                MemoryStream filedata = ExcelUtility.GetExcel(data);

                response.StatusCode = status;
                //application/vnd.ms-excel .xls
                var contenttype = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

                response.Content = new ByteArrayContent(filedata.ToArray());
               // response.Headers.Location = new Uri(Request.RequestUri, string.Format("Hola/{0}", 123));
                response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
                response.Content.Headers.ContentType = new MediaTypeHeaderValue(contenttype);
                response.Content.Headers.ContentDisposition.FileName = filename + ".xlsx";
            }
            else
            {
                response.StatusCode = status;
                response.Content = new StringContent(error);
            }
            
            
            
            return response;
            //return ResponseMessage(Request.CreateResponse(HttpStatusCode.OK, response));
        }
        public static DataTable GetDataToExportVariableProcess(List<Dictionary<string, string>> reportData, List<MultiColumnHeader> columns)
        {
            var rowsToExport = new List<Dictionary<string, string>>();
            var columnHeaders = columns.ToList();
            foreach (var row in reportData)
            {
                var dictionaryToExport = new Dictionary<string, string>();
                foreach (var column in columnHeaders)
                {
                    var fieldName = column.alias_column;
                    if (row.ContainsKey(fieldName))
                    {
                        if (!dictionaryToExport.ContainsKey(fieldName))
                            dictionaryToExport.Add(fieldName, row[fieldName]);
                        else
                            dictionaryToExport.Add(fieldName + "1", row[fieldName]);
                        //TODO Generar un aleatorio
                    }
                    else
                    {
                        if (!dictionaryToExport.ContainsKey(fieldName))
                            dictionaryToExport.Add(fieldName, " ");
                        else
                            dictionaryToExport.Add(fieldName + "1", " ");
                        //TODO Generar un aleatorio
                    }
                }

                rowsToExport.Add(dictionaryToExport);
            }

            var reportDataDt = DABase.ConvertToDataTable(rowsToExport);

            return reportDataDt;
        }

        public static DataTable GetDataToExportVariableProcessXml(List<Dictionary<string, string>> reportData, List<MultiColumnHeader> columns)
        {
           
            var rowsToExport = new List<Dictionary<string, string>>();
            var columnHeaders = columns.ToList();
            foreach (var row in reportData)
            {
                var dictionaryToExport = new Dictionary<string, string>();
                foreach (var column in columnHeaders)
                {
                    if (column.pinned != "True")
                    {
                        XmlDocument xmlDoc = new XmlDocument();
                        xmlDoc.LoadXml(row["xml_data"]);
                        var nodes = xmlDoc.SelectNodes("/row/V" + column.alias_column);

                        string text = "";
                        if ((nodes != null) && (nodes.Count > 0))
                        {
                            if(column.variable_type == "FLOAT" )
                                text = Convert.ToDouble(nodes[0].InnerText).ToString();
                            else
                                text = nodes[0].InnerText;
                        }
                        if (!dictionaryToExport.ContainsKey(column.alias_column))
                            dictionaryToExport.Add(column.alias_column, text);
                        else
                            dictionaryToExport.Add(column.alias_column + "1", text);
                    }
                    else
                    {

                        var fieldName = column.alias_column;
                        if (row.ContainsKey(fieldName))
                        {

                            if (!dictionaryToExport.ContainsKey(fieldName))
                                dictionaryToExport.Add(fieldName, row[fieldName]);
                            else
                                dictionaryToExport.Add(fieldName + "1", row[fieldName]);
                            //TODO Generar un aleatorio
                        }
                        else
                        {
                            if (!dictionaryToExport.ContainsKey(fieldName))
                                dictionaryToExport.Add(fieldName, " ");
                            else
                                dictionaryToExport.Add(fieldName + "1", " ");
                            //TODO Generar un aleatorio
                        }
                    }
                }

                rowsToExport.Add(dictionaryToExport);
            }

            var reportDataDt = DABase.ConvertToDataTable(rowsToExport);

            return reportDataDt;
        }

        public static string transformAccentsHtml(string str)
        {
            str = str.Replace("á", "&aacute;");
            str = str.Replace("é", "&eacute;");
            str = str.Replace("í", "&iacute;");
            str = str.Replace("ó", "&oacute;");
            str = str.Replace("ú", "&uacute;");

            return str;
        }

        public HttpResponseMessage GetMessageExportCSV(HttpStatusCode status, DataTable data, string filename, string error)
        {
            HttpResponseMessage response = new HttpResponseMessage();
            if (status == HttpStatusCode.OK)
            {
                MemoryStream filedata = CSVUtility.GetCSV(data);

                response.StatusCode = status;
                //application/vnd.ms-excel .xls
                var contenttype = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

                response.Content = new ByteArrayContent(filedata.ToArray());
                response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
                response.Content.Headers.ContentType = new MediaTypeHeaderValue(contenttype);
                response.Content.Headers.ContentDisposition.FileName = filename + ".csv";
            }
            else
            {
                response.StatusCode = status;
                response.Content = new StringContent(error);
            }
            return response;
        }
    }
}
