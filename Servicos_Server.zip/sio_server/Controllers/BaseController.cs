﻿using Newtonsoft.Json;
using Seguridad.Negocio;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;
using Ternium.Sio_Server.Models;
using Ternium.Sio_Server.Models.Repository;
using Ternium.Sio_Server.SecuritySoap;

namespace Ternium.Sio_Server.Controllers
{
    /// <summary>
    /// Api Methods for Production Data.
    /// </summary>
    [EnableCORS(origins: new string[] { "localhost:13050", "termxsppapp45" }, methods: "*")]  
    [RoutePrefix("api/base")]
    public class BaseController : Ternium.ApiBaseController
    {
        private readonly DAProduction dbProduction = new DAProduction();
        private readonly DABase db = new DABase();
        private ExportController export = new ExportController();


        /// <summary>
        /// Gets the line status
        /// </summary>
        /// <param name="id_line"></param>
        /// <returns></returns>
        /// 
        public User GetName(string user_domain)
        {
            string DomainName = "ternium";
            string UserName = user_domain.IndexOf('\\') != -1 ? user_domain.Substring(user_domain.IndexOf('\\') + 1) : "";
            User user = new User();
            if (UserName == "")
            {
                return user;
            }
            UserDomainAttributes userInfoMail = new UserDomainAttributes();
            UserDomainAttributes userInfoName = new UserDomainAttributes();
            UserDomainAttributes userInfoPhoto = new UserDomainAttributes();
            SecuritySoapClient webservice = new SecuritySoapClient();
            userInfoMail = webservice.GetUserActiveDirectoryAttributes(DomainName, UserName, "mail");
            userInfoName = webservice.GetUserActiveDirectoryAttributes(DomainName, UserName, "name");
            userInfoPhoto = webservice.GetUserActiveDirectoryAttributes(DomainName, UserName, "thumbnailPhoto");
            if (userInfoMail.ErrorMessage.Length == 0)
            {
                user.mail = userInfoMail.Attributes[0].Value;
                user.name = userInfoName.Attributes[0].Value;
                user.username = user_domain.ToLower();
                user.photo = userInfoPhoto.Attributes[0].Value;
            }
            return user;
        }

        [HttpGet]
        [Route("current_user")]
        public User GetCurrentUser()
        {
            string identity = HttpContext.Current.Request.LogonUserIdentity.Name;
            string user = !string.IsNullOrEmpty(identity) ? identity : "ternium\\c.jmobil";
            return GetName(user);
        }

        [HttpGet]
        [Route("current_domain_user")]
        public string GetCurrentDomainUser()
        {
            return HttpContext.Current.Request.LogonUserIdentity.Name;
        }

        /// <summary>
        /// Gets the line status
        /// </summary>
        /// <param name="id_line"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("shift/{id_line}")]
        public IHttpActionResult GetCurrentShift(int id_line)
        {
            try
            {
                var parameters = new Dictionary<string, object> { { "id_line", id_line } };
                var status = dbProduction.GetCurrentShift(parameters);
                return Ok(status);
            }
            catch (Exception ex)
            {
                return BadRequest("GetCurrentShift Error => " + ex.Message);
            }
        }

        /// <summary>
        /// Gets the line status
        /// </summary>
        /// <param name="id_line"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("shifts/{id_line}")]
        public IHttpActionResult GetShifts(int id_line)
        {
            try
            {
                var parameters = new Dictionary<string, object> { { "id_line", id_line } };
                var status = dbProduction.GetShifts(parameters);
                return Ok(status);
            }
            catch (Exception ex)
            {
                return BadRequest("GetShifts Error => " + ex.Message);
            }
        }

        /// <summary>
        /// Gets the line Squad
        /// </summary>
        /// <param name="id_line"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("squad")]
        public IHttpActionResult GetSquad(int id_line)
        {
            try
            {
                var parameters = new Dictionary<string, object> { { "id_line", id_line } };
                var data = db.GetSquad(parameters);//GetSquad
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest("GetSquad Error => " + ex.Message);
            }
        }

        /// <summary>
        /// Gets the list process
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        [HttpGet]
        [Route("processes")]
        public IHttpActionResult GetProcesses()
        {
            try
            {
                var result = db.GetListProcess();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest("GetProcesses Error => " + ex.Message);
            }
        }


        /// <summary>
        /// Gets the list plants
        /// </summary>
        /// <param name="id_process"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("plants")]
        public IHttpActionResult GetPlants(int id_process)
        {
            try
            {
                var parameters = new Dictionary<string, object> { { "id_process", id_process } };
                var result = db.GetListPlants(parameters);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest("GetPlants Error => " + ex.Message);
            }
        }

        /// <summary>
        /// Gets the list lines
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        [HttpGet]
        [Route("lines")]
        public IHttpActionResult GetListLines(int id_process, int id_plant)
        {
            try
            {
                var parameters = new Dictionary<string, object> { { "id_process", id_process }, { "id_plant", id_plant } };
                var result = db.GetListLines(parameters);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest("GetListLines Error => " + ex.Message);
            }
        }

        [HttpGet]
        [Route("line_info/{id_line}")]
        public IHttpActionResult GetLineInfo(string id_line)
        {
            try
            {
                Dictionary<string, object> line = new Dictionary<string, object>();
                var parameters = new Dictionary<string, object> { { "id_line", id_line } };
                Dictionary<string, string>  line_info = db.GetLineInfo(parameters);
                List<Dictionary<string, string>> list_process = db.GetListProcess();
                Dictionary<string, string> process = new Dictionary<string, string>();
                Dictionary<string, string> plant = new Dictionary<string, string>();

                if (line_info.Count == 0)
                {
                    return Ok(line);
                }

                line.Add("process", list_process.Find(x => x["id_process"] == line_info["id_process"]));
                process = (Dictionary<string, string>) line["process"];

                parameters = new Dictionary<string, object> { { "id_process", process["id_process"] } };
                List<Dictionary<string, string>> list_plants = db.GetListPlants(parameters);
            
                line.Add("plant", list_plants.Find(x => x["id_plant"] == line_info["id_plant"]));
                plant = (Dictionary<string, string>)line["plant"];

                line["list_plants"] = list_plants;

                parameters = new Dictionary<string, object> { { "id_process", process["id_process"] }, { "id_plant", plant["id_plant"] } };
                List<Dictionary<string, string>> list_lines = db.GetListLines(parameters);

                line["list_lines"] = list_lines;

                foreach (var item in line_info)
                {
                    line[item.Key] = item.Value;
                }

                return Ok(line);
            }
            catch (Exception e)
            {
                return InternalServerError(e);
            }
        }

        /// <summary>
        /// Gets the report config
        /// </summary>
        [HttpGet]
        [Route("report_config")]
        public IHttpActionResult GetReportConfig(int id_report, int id_line, string report_code = "")
        {
            try
            {
                var parameters = new Dictionary<string, object>
                                     {
                                         { "id_line", id_line },
                                         { "id_report", id_report },
                                         { "report_code", report_code },
                                     };

                var columns = this.db.GetReportConfig(parameters);
                return Ok(columns);
            }
            catch (Exception ex)
            {
                return BadRequest("GetReportConfig Error => " + ex.Message);
            }
        }

        /// <summary>
        /// Gets the production data of the date/shift selected.
        /// </summary>
        [HttpGet]
        [Route("report_columns")]
        public IHttpActionResult GetReportColumns(int id_line, int id_report, string report_code = "")
        {
            try
            {
                var parameters = new Dictionary<string, object>
                                     {
                                         { "id_line", id_line },
                                         { "id_report", id_report },
                                         { "report_code", report_code }
                                     };

                var columns = dbProduction.GetReportColumns(parameters);
                return Ok(columns);
            }
            catch (Exception ex)
            {
                return BadRequest("GetReportColumns Error => " + ex.Message);
            }
        }

        private void AddChildColumns(Dictionary<string, string> column, ColumnInfo current_parent, string[] descriptions, ref int i, int max_level)
        {
            i++;
            var current_index = i;
            if (descriptions.Length > current_index)
            {
                var current_child = current_parent.child_columns.Find(x => x.display_name == descriptions[current_index]);
                if (current_child == null)
                {
                    current_child = new ColumnInfo(column);
                    current_child.display_name = descriptions[current_index];
                    current_child.child_columns = new List<ColumnInfo>();
                    current_child.colspan = 1;
                    current_child.level = current_parent.level + 1;
                    current_child.max_levels = max_level;
                    current_parent.child_columns.Add(current_child);

                    if (current_index < descriptions.Length - 1)
                    {
                        current_child.rowspan = 1;
                        this.AddChildColumns(column, current_child, descriptions, ref i, max_level);
                    }
                    else
                    {
                        current_child.rowspan = max_level - current_child.level + 1;
                    }
                }
                else
                {
                    this.AddChildColumns(column, current_child, descriptions, ref i, max_level);
                }               
            }
            else
            {
                current_parent.rowspan = max_level - current_parent.level + 1;
            }

            current_parent.colspan = current_parent.child_columns == null || current_parent.child_columns.Count == 0 ? 1 : current_parent.child_columns.Sum(x => x.colspan);
        }


        [HttpGet]
        [Route("permissions")]
        public IHttpActionResult GetPermissions(int id_line, int id_rol)
        {
            try
            {
                string username = HttpContext.Current.User.Identity.Name;
                var request = new HttpRequestWrapper(HttpContext.Current.Request);
                Permisos permissions = new Permisos(request, username, id_rol, id_line);
                return Ok(permissions.PermisoRol);
            }
            catch (Exception ex)
            {
                return BadRequest("GetPermissions Error => " + ex.Message);
            }            
        }

        /// <summary>
        /// Gets the generic report config
        /// </summary>
        [HttpGet]
        [Route("generic_report_config")]
        public IHttpActionResult GetGenericReportConfig(int id_line, int id_generic_report)
        {
            try
            {
                var parameters = new Dictionary<string, object>
                                     {
                                         { "id_line", id_line },
                                         { "id_generic_report", id_generic_report },
                                     };

                var columns = db.GetGenericReportConfig(parameters);

                return Ok(columns);
            }
            catch (Exception ex)
            {
                return BadRequest("GetGenericReportConfig Error => " + ex.Message);
            }
        }

        /// <summary>
        /// Gets the report user config
        /// </summary>
        [HttpGet]
        [Route("report_user_config")]
        public IHttpActionResult GetReportUserConfig(int id_line, int id_report, string username = "", string report_code= "")
        {
            try
            {
                var parameters = new Dictionary<string, object>
                                     {
                                         { "report_code", report_code ?? "" },
                                         { "id_report", id_report },
                                         { "id_line", id_line },
                                         { "username", username ?? "" },
                                     };

                var columns = db.GetReportUserConfig(parameters);

                return Ok(columns);
            }
            catch (Exception ex)
            {
                return BadRequest("GetReportUserConfig Error => " + ex.Message);
            }
        }

        /// <summary>
        /// Gets the generic report config
        /// </summary>
        [HttpPost, HttpOptions]
        [Route("generic_report_data")]
        public IHttpActionResult GetGenericReportData([FromBody] GenericReportParams parameters)
        {
            this.InitializeWebStatistic();

            if (HttpContext.Current.Request.HttpMethod == "OPTIONS")
            {
                return Ok();    
            }

            try
            {
                var data = db.GetGenericReportData(parameters.SpCnnName, parameters.SpDataName, parameters.SpParameters);

               return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest("GetGenericReportData Error => " + ex.Message);
            }
        }

        [HttpGet]
        [Route("export_generic_report")]
        public HttpResponseMessage GenericReportExportExcel(string generic_params)
        {
            var parameters = JsonConvert.DeserializeObject<GenericReportParamsExport>(generic_params);

            try
            {
                var configReportParams = new Dictionary<string, object> 
                                    {
                                         { "id_line", parameters.IdLine },
                                         { "id_generic_report", parameters.IdGenericReport }
                                     };

                var Params = new Dictionary<string, object> 
                                    {
                                         { "id_line", parameters.IdLine },
                                         { "id_report", parameters.IdReport }
                                     };

                var config = db.GetGenericReportConfig(configReportParams);
                var columns = dbProduction.GetReportColumns(Params);


                var reportData = db.GetGenericReportData(config["sp_cnn_name"], config["sp_data"], parameters.SpParameters);
                var reportDataDt = ExportController.GetDataToExport(reportData, columns);
                return export.GetMessageGenericReportExport(HttpStatusCode.OK, reportDataDt, config["generic_report"].Replace(" ", "_") +
                                                            DateTime.Now.ToString("dd_MM_yyyy"), null);
            }
            catch (Exception ex)
            {
                return export.GetMessagePublicReportExport(HttpStatusCode.InternalServerError, null, null, ex.Message);
            }

        }
        
        [HttpPost, HttpOptions]
        [Route("report_user_config")]
        public IHttpActionResult SetReportUserConfig([FromBody] Dictionary<string, object> body)
        {
            this.InitializeWebStatistic();

            if (HttpContext.Current.Request.HttpMethod == "OPTIONS")
            {
                return Ok();
            }

            try
            {
                var data = db.SetReportUserConfig(body);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest("SetReportUserConfig Error => " + ex.Message);
            }
        }

	[HttpGet]
        [Route("generic_report_filters")]
        public IHttpActionResult GetGenericReportFilter(int id_generic_report)
        {
            try
            {
                var parameters = new Dictionary<string, object> {
                { "id_generic_report", id_generic_report }          
                };

                var data = db.GetGenericReportFilters(parameters);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }
        [HttpGet]
        [Route("generic_report_filters_data")]
        public IHttpActionResult GetGenericReportFilterData(int id_line,string sp_name)
        {
            try
            {
                var parameters = new Dictionary<string, object> {
                { "id_line",  id_line}          
                };

                var data = db.GetGenericReportFiltersData(parameters,sp_name);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        [HttpGet]
        [Route("get_multiheader_columns")]
        public IHttpActionResult GetMultiheadersColumns(int id_line, int id_report)
        {
            try
            {
                Dictionary<string, dynamic> response = new Dictionary<string, dynamic>();
                List<MultiColumnHeader> columns = new List<MultiColumnHeader>();

                var parameters = new Dictionary<string, object> {
                    { "id_line", id_line },          
                    { "id_report", id_report }          
                };

                List<Dictionary<string, string>> dataParentsColumns = db.GetMultiheaders(parameters);
                List<Dictionary<string, string>> dataChildsColumns = db.GetReportAllColumnsMultiheaders(parameters);

                Dictionary<string, dynamic> parents;
                MultiColumnHeader multiHeader;

                if (dataParentsColumns.Count > 0)
                {

                    foreach (var item in dataParentsColumns)
                    {
                        int _idHeaderParent = item["id_header_parent"].Length > 0 ? int.Parse(item["id_header_parent"]) : 0;
                        List<MultiColumnHeader> childsColumns = new List<MultiColumnHeader>();

                        var _childs = dataChildsColumns.FindAll(s => s["id_header"] == item["id_header"]);

                        foreach (var _child in _childs)
                        {
                            MultiColumnHeader _item = new MultiColumnHeader(_child);

                            if (_item.child_columns == null)
                            {
                                _item.child_columns = new List<MultiColumnHeader>();
                            }

                            childsColumns.Add(_item);
                        }

                        multiHeader = new MultiColumnHeader(item);

                        multiHeader.width = _childs.Sum(i => int.Parse(i["width"])).ToString();
                        multiHeader.display_name = multiHeader.description;
                        multiHeader.child_columns = childsColumns;
                        columns.Add(multiHeader);

                    }

                    foreach (MultiColumnHeader item in columns)
                    {
                        List<MultiColumnHeader> _parents = columns.FindAll(x => x.id_header == item.id_header_parent);

                        if (_parents.Count > 0)
                        {
                            MultiColumnHeader _parent = _parents[0];

                            String width = (int.Parse(_parent.width) + int.Parse(item.width)).ToString();
                            _parent.width = width;
                            _parent.child_columns.Add(item);



                        }
                    }

                    // se actualiza el width para los elementos hijos que tambien son padres de otros que no se actualizaron en el primer foreach
                    // debido a que el padre podria haber esta en una posicion anterior al hijo 
                    foreach (MultiColumnHeader item in columns.FindAll(x => x.id_header_parent.Length == 0))
                    {
                        item.child_columns.OrderBy(x => x.order);
                        item.width = item.child_columns.Sum(i => int.Parse(i.width)).ToString();
                    }

                    // Para tomar los casos especiales cuando una columna no es hija ni tampoco padre
                    var specials_childs = dataChildsColumns.FindAll(x => x["id_header"].Length == 0);
                    foreach (var child in specials_childs)
                    {
                        MultiColumnHeader _item = new MultiColumnHeader(child);
                        _item.id_header_parent = "";
                        _item.child_columns = new List<MultiColumnHeader>();
                        columns.Add(_item);
                    }


                    response.Add("success", "1");
                    response.Add("data", columns.FindAll(x => x.id_header_parent.Length == 0));
                }
                else
                {
                    response.Add("success", "0");
                }

                return Ok(response);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

       
    }
}
