﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ProductionController.cs" company="Ternium Siderar">
//   Ternium Siderar
// </copyright>
// <summary>
//   Api Methods for Production Data.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Ternium.Sio_Server.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Http;
    using System.Web.Http.Description;

    using Models;
    using Models.Gantt;
    using Models.Repository;
    using System.Net.Http;
    using System.Net;
    using System.Net.Http.Headers;
    using System.Web;
    using LIN.Controllers;
    using System.Configuration;
    using Newtonsoft.Json;
    using Ternium.Sio_Server.Models.Curves;
    using Ternium.Sio_Server.Utilities;

    /// <summary>
    /// Api Methods for Production Data.
    /// </summary>
    [EnableCORS()]
    //[EnableCORS(origins: new string[] { "localhost:50698", "termxsppapp45" }, methods: "*")]
    [RoutePrefix("Api/Production")]
    public class ProductionController : Ternium.ApiBaseController
    {

        private readonly DAProduction db = new DAProduction();
        private DABase dbAccess = new DABase();
        private ExportController export = new ExportController();
        private RDLCController rdlc = new RDLCController();

        /// <summary>
        /// Gets the production data of the date/shift selected.
        /// </summary>
        [HttpGet]
        [Route("production_data")]
        [ResponseType(typeof(ProductionReportData))]
        public IHttpActionResult GetProductionDetail(int id_line, DateTime date, int shift)
        {
            try
            {
                var parameters = new Dictionary<string, object>
                                     {
                                         { "id_line", id_line },
                                         { "id_shift", shift },
                                         { "ternium_date", date },
                                         { "has_tooltip", 1 }
                                     };
                List<Dictionary<string, string>> status = new List<Dictionary<string, string>>();
                status.Add(GetLineStatus(id_line));

                var reportData = new Dictionary<string, List<Dictionary<string, string>>>
                {
                    {"Defects", GetInfoProductionDetails(id_line, date, shift)},
                    {"Production", GetInfoProductionCoils(id_line, date, shift, true)},
                    {"Summary", GetProductionSummary(id_line, date, shift)},
                    {"LineStatus", status},
                    {"Delays", GetLineDelays(id_line, date, shift)}
                };

                var ganttData = GetGantt(id_line, date, shift);

                var data = new ProductionReportData(reportData, ganttData);

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest("GetProductionDetail Error => " + ex.Message);
            }
        }

        /// <summary>
        /// Gets the production data of the date/shift selected.
        /// </summary>
        [HttpGet]
        [Route("production_columns")]
        [ResponseType(typeof(ProductionReportData))]
        public IHttpActionResult GetProductionColumns(int id_line)
        {
            try
            {
                var parameters = new Dictionary<string, object>
                                     {
                                         { "id_line", id_line },
                                         { "id_report", 1 },
                                     };

                var columns = db.GetReportColumns(parameters);

                return Ok(columns);
            }
            catch (Exception ex)
            {
                return BadRequest("GetProductionDetail Error => " + ex.Message);
            }
        }


        /// <summary>
        /// Gets the coils produced into of date/shift selected.
        /// </summary>
        [HttpGet]
        [Route("production_coils")]
        public List<Dictionary<string, string>> GetProductionCoils(int id_line, DateTime date, int shift, bool order_asc = false)
        {
            this.InitializeWebStatistic();

            var data = GetInfoProductionCoils(id_line, date, shift, order_asc);

            return data;
        }

        /// <summary>
        /// Gets production summary of a date/shift selected.
        /// </summary>
        [HttpGet]
        [Route("production_summary")]
        public List<Dictionary<string, string>> GetProductionSummary(int id_line, DateTime date, int shift)
        {
            var parameters = new Dictionary<string, object>
                                    {
                                        { "id_line", id_line },
                                        { "id_shift", shift },
                                        { "date", date }
                                    };

            return db.GetProductionSummary(parameters);
        }

        /// <summary>
        /// Gets the defects of a coil
        /// </summary>
        /// <param name="id_line"></param>
        /// <param name="id_exit"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("coil_defects")]
        [ResponseType(typeof(List<Dictionary<string, string>>))]
        public IHttpActionResult GetCoilDefects(int id_line, int id_exit)
        {
            this.InitializeWebStatistic();

            try
            {
                var parameters = new Dictionary<string, object> {
                    { "id_line", id_line },
                    { "id_exit", id_exit }
                };
                var defects = db.GetCoilDefects(parameters);
                return Ok(defects);
            }
            catch (Exception ex)
            {
                return BadRequest("GetCoilDefects Error => " + ex.Message);
            }
        }

        /// <summary>
        /// Gets the line status
        /// </summary>
        /// <param name="idLine"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("line_status/{id_line}")]
        public Dictionary<string, string> GetLineStatus(int id_line)
        {
            var parameters = new Dictionary<string, object> { { "id_line", id_line } };
            try
            {
                return db.GetLineStatus(parameters);
            }
            catch (Exception)
            {
                throw;
                //return new Dictionary<string, string>();
            }
        }

        /// <summary>
        /// Gets the delays of a line
        /// </summary>
        /// <param name="id_line"></param>
        /// <param name="start_date"></param>
        /// <param name="end_date"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("line_delays")]
        public List<Dictionary<string, string>> GetLineDelays(int id_line, DateTime date, int shift)
        {
            var parameters = new Dictionary<string, object> {
                { "id_line", id_line },
                { "date", date },
                { "shift", shift }
            };
            try
            {
                return db.GetLineDelays(parameters);
            }
            catch (Exception)
            {
                throw;
                //return new List<Dictionary<string, string>>();
            }

        }

        /// <summary>
        /// Gets the delays of a line
        /// </summary>
        /// <param name="id_line"></param>
        /// <param name="start_date"></param>
        /// <param name="end_date"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("production_defects")]
        public List<Dictionary<string, string>> GetProductionDefects(int id_line, DateTime date, int shift)
        {
            this.InitializeWebStatistic();

            var data = GetInfoProductionDetails(id_line, date, shift);

            return data;
        }

        /// <summary>
        /// Get the columns picked by the user.
        /// </summary>
        /// <param name="idLine">The id Line</param>
        /// <param name="user">The user</param>
        /// <param name="idReport">The Id Report</param>
        /// <returns></returns>
        [HttpGet]
        [Route("SelectedColumns/{user}/{idLine}/{idReport}")]
        [ResponseType(typeof(string))]
        public IHttpActionResult GetUserColumns(string user, int idLine, int idReport)
        {
            try
            {
                var columns = db.GetUserColumns(user, idLine, idReport);
                return Ok(columns);
            }
            catch (Exception ex)
            {
                return BadRequest("GetUserColumns Error => " + ex.Message);
            }
        }

        /// <summary>
        /// Set the columns picked by the user.
        /// </summary>
        /// <param name="param">param object</param>
        /// <returns></returns>
        [HttpPost]
        [Route("StoreSelectedColumns")]
        public IHttpActionResult SetUserColumns(UserColumnsParam param)
        {
            try
            {
                db.SetUserColumns(param.User, param.IdLine, param.IdReport, param.Columns);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest("SetUserColumns Error => " + ex.Message);
            }
        }

        [HttpGet]
        [Route("production_gantt")]
        public Dictionary<string, object> GetGantt(int id_line, DateTime date, int shift)
        {
            List<Dictionary<string, string>> production = GetInfoProductionCoils(id_line, date, shift, true);
            List<Dictionary<string, string>> delays = GetLineDelays(id_line, date, shift);
            List<Dictionary<string, string>> AllDefects = GetInfoProductionDetails(id_line, date, shift);
            List<Dictionary<string, string>> exitLinesData = GetExitLines(id_line);
            

            List<GanttItem> SteelCoils = new List<GanttItem>();
            List<BarTopItem> Schedules = new List<BarTopItem>();
            List<XMarkItem> Defects = new List<XMarkItem>();
            List<BarBottomItem> Delays = new List<BarBottomItem>();
            List<ExitLine> ExitLines = new List<ExitLine>();

            // Dinamyc Gantts
            DABase daBase = new DABase();
            var lineInfo = daBase.GetLineInfo(new Dictionary<string, object> { { "id_line", id_line } });
            var reportConfig = daBase.GetReportConfig(new Dictionary<string, object> { { "id_line" , id_line } , { "id_report" , 1 } });
            var Config = new GanttConfig( lineInfo["gantt_metrics1"] , lineInfo["gantt_metrics2"] );
            //var metric1_field = Config.metric1_field;
            //var metric2_field = Config.metric2_field;

            Config.barBottomLabel = "DEMORAS";
            Config.type = "PROD";
            Config.isMultiline = ((!reportConfig.ContainsKey("id_gantt_type")) || (reportConfig.ContainsKey("id_gantt_type") && string.IsNullOrEmpty(reportConfig["id_gantt_type"]))) ? "0" : (int.Parse(reportConfig["id_gantt_type"]) == 3 ? "1" : "0");
            Config.ganttToolTip = reportConfig.ContainsKey("gantt_tooltip") ? reportConfig["gantt_tooltip"] : "" ;

            if (production.Count > 0 && !production[0].ContainsKey(Config.metric1_field))
            {
                Config.metric1_field = "gantt_top_value";
            }
            if (production.Count > 0 && !production[0].ContainsKey(Config.metric2_field))
            {
                Config.metric2_field = "gantt_bottom_value";
            }

            int rowGroupId = 1;
            int index = 0;
            BarTopItem Schedule = null;
            string scheduleNumber = string.Empty;
            Dictionary<string, int> listSchedules = new Dictionary<string, int>();

            foreach (var row in production)
            {
                DateTime tmp_date;
                DateTime start_date = (DateTime.TryParse(row["start_date"], out tmp_date)) ? tmp_date : Convert.ToDateTime(row["end_date"]); 
                //DateTime start_date = Convert.ToDateTime(row["start_date"]);
                DateTime end_date = Convert.ToDateTime(row["end_date"]);
                DateTime start_program;
                DateTime end_program;

                //Primer Programa
                if (Schedules.Count == 0)
                {
                    scheduleNumber = row["program"];

                    Schedule = new BarTopItem(
                        scheduleNumber,
                        start_date,
                        end_date,
                        row["program_sequence"],
                        "0",
                        row["programmed_material_quantity"]);
                    Schedules.Add(Schedule);

                    listSchedules.Add(scheduleNumber, rowGroupId);
                }

                if (index > 0)
                {
                    string current_program = row["program"];
                    start_program = start_date;
                    end_program = end_date;
                    if (production[index - 1]["id_exit"] != row["id_exit"])
                    {
                        if (production[index - 1]["end_date"] != row["start_date"])
                        {
                            scheduleNumber = "NA";
                            end_program = start_date;
                            start_program = Convert.ToDateTime(production[index - 1]["end_date"]);
                            //barTopData.Add(new BarTopItem("NA", start_program, end_program, "NA", "0", ""));
                            //ganttData.Add(new GanttItem("NA", "", start_program, end_program, "", "", "", "", "", "0", "", ""));
                        }
                    }

                    // Schedules
                    if (scheduleNumber != current_program)
                    {
                        if (scheduleNumber == "NA") //Espacio sin Produccion
                        {
                            start_program = start_date;
                            end_program = end_date;
                        }
                        scheduleNumber = current_program;
                        if (listSchedules.ContainsKey(scheduleNumber)) //Busca el RowGroup, para el mismo color
                        {
                            rowGroupId = listSchedules[scheduleNumber];
                        }
                        else
                        {
                            rowGroupId = listSchedules.Count;
                            rowGroupId++;
                            listSchedules.Add(scheduleNumber, rowGroupId);
                        }

                        Schedule = new BarTopItem(
                            scheduleNumber,
                            start_program,
                            end_program,
                            row["program_sequence"],
                            "0",
                            row["programmed_material_quantity"]);
                        Schedules.Add(Schedule);
                    }
                    else
                    {
                        //Actualiza el inicio/fin del programa
                        if (Schedule != null && end_date > Convert.ToDateTime(Schedule.EndTime))
                        {
                            Schedule.UpdateEndTime(end_date);
                        }

                        if (Schedule != null && start_date < Convert.ToDateTime(Schedule.StartTime))
                        {
                            Schedule.UpdateStartTime(start_date);
                        }
                    }
                }

                /* 
                 * CUSTOM DETAIL INFO
                 * "title1|field1|title2|field2|...titlen|fieldn"
                 * */

                var gantt_tooltip_split = Config.ganttToolTip.Split('|');
                string gantt_tooltip = "";

                if (Config.ganttToolTip.IndexOf("|") > 0 ) {
                    for (int J = 0; J < gantt_tooltip_split.Length; J += 2)
                    {
                        gantt_tooltip += gantt_tooltip_split[J].ToString() + "|" + row[gantt_tooltip_split[1+J]].ToString() + "|";
                    }
                }
                
              
                GanttItem SteelCoil = new GanttItem(
                    row["id_exit"],
                    rowGroupId.ToString(),
                    start_date,
                    end_date,
                    row["exit_material"],
                    row["program"],
                    row["material_sequence"],
                    row[Config.metric1_field].Replace(",", "."),
                    row[Config.metric2_field].Replace(",", "."),
                    "0",
                    row["production_status"],
                    row["stratix_status"],
                    Config.metric1_tooltip ,
                    Config.metric2_tooltip ,
                    "0",
                    row.ContainsKey("id_exit_line") ? int.Parse(row["id_exit_line"]) : 0,                  
                    Config.isMultiline ,
                    gantt_tooltip
                );

                SteelCoils.Add(SteelCoil);

                // Defects
                int defectQuantity = Convert.ToInt32(row["defect_quantity"]);
                if (defectQuantity > 0)
                {
                    XMarkItem xMarkItem = new XMarkItem(row["id_exit"], start_date, end_date);

                    var defects = AllDefects.Where(d => d["id_exit"] == row["id_exit"]);
                    xMarkItem.AddMark("Material", row["exit_material"], false);

                    foreach (var defect in defects)
                    {
                        xMarkItem.AddMark(defect["id_defect_code"], defect["defect"]);
                        Defects.Add(xMarkItem);
                    }

                    //Defects.Add(xMarkItem);
                }
                index++;
                //Fin Produccion
            }

            Delays = delays.Select(row => new BarBottomItem(Convert.ToDateTime(row["fecha_inicio"]), Convert.ToDateTime(row["fecha_fin"]), Convert.ToInt32(row["tipo"]), row["desc_nivel_1"], row["desc_nivel_2"], row["desc_nivel_3"], row["desc_nivel_4"], row["desc_nivel_5"], row["comentario"])).ToList();

            double ganttTopMin = 0;
            double ganttTopMax = 0;
            double ganttBottomMin = 0;
            double ganttBottomMax = 0;

            ganttBottomMax = SteelCoils.Any() ? SteelCoils.Max(x => Convert.ToDouble(x.BottomValue)) : 0;
            ganttBottomMin = SteelCoils.Any() ? SteelCoils.Min(x => Convert.ToDouble(x.BottomValue)) : 0;
            ganttTopMax = SteelCoils.Any() ? SteelCoils.Max(x => Convert.ToDouble(x.TopValue)) : 0;
            ganttTopMin = SteelCoils.Any() ? SteelCoils.Min(x => Convert.ToDouble(x.TopValue)) : 0;


            var totalData = new Dictionary<string, object>
            {
                {"Schedules", Schedules},
                {"SteelCoils", SteelCoils},
                {"Defects", Defects},
                {"Delays", Delays},
                {"Config", Config}
            };

            if (SteelCoils.Any())
            {
                totalData.Add("Ranges", new
                {
                    ganttTopMin = Decimal.Round((decimal)(ganttTopMin * 0.8)), //Bajar el limite inferior, para que pueda ser visible
                    ganttTopMax = Decimal.Round((decimal)(ganttTopMax * 1.1)), //Subir el limite superior, para que pueda ser visible
                    ganttBottomMin = 0.00,
                    ganttBottomMax = Decimal.Round((decimal)(ganttBottomMax), 2)
                });
            }
            else
            {
                totalData.Add("Ranges", new { ganttTopMin = 0, ganttTopMax = 0, ganttBottomMin = 0, ganttBottomMax = 0 });
            }

            if (Config.isMultiline == "1")
            {
                exitLinesData = GetExitLines(id_line);

                foreach (var row in exitLinesData)
                {
                    ExitLines.Add(new ExitLine(row["id_line"], row["line"]));
                }
            }
            
            totalData.Add("ExitLines", ExitLines );
            return totalData;
        }

        /// <summary>
        /// Get Superficial Inspection - Defects/Holes Map
        /// </summary>
        /// <param name="id_line"></param>
        /// <param name="id_material"></param>
        /// <param name="id_graph_type"></param>
        /// <param name="is_entrance"></param>
        /// <param name="id_defect_status"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("superficial_inspection")]
        public List<Dictionary<string, string>> GetSuperficialInspection(int id_line, string id_material, int id_graph_type, bool is_entrance, int id_defect_status)
        {
            this.InitializeWebStatistic();

            var parameters = new Dictionary<string, object> {
                { "id_line", id_line },
                { "id_material", id_material },
                { "id_graph_type", id_graph_type },
                { "id_defect_status", id_defect_status }
            };
            return db.GetSuperficialInspection(parameters);
        }

        //GetProducionDefectsMap
        [HttpGet]
        [Route("production_defects_map")]
        public List<Dictionary<string, string>> GetProducionDefectsMap(int id_line, string id_exit)
        {
            this.InitializeWebStatistic();

            var parameters = new Dictionary<string, object> {
                { "id_line", id_line },
                { "id_exit", id_exit }
            };
            return db.GetProducionDefectsMap(parameters);
        }

        //GetMaterialInfo
        [HttpGet]
        [Route("material_info")]
        public List<Dictionary<string, string>> GetMaterialInfo(int id_line, string id_exit)
        {
            var parameters = new Dictionary<string, object> {
                { "id_line", id_line },
                { "id_exit", id_exit }
            };
            return db.GetMaterialInfo(parameters);
        }

        [HttpGet]
        [Route("check_superficial_inspection")]
        public List<Dictionary<string, string>> GetCheckSuperficialInspection(int id_line, int id_exit)
        {
            this.InitializeWebStatistic();

            var parameters = new Dictionary<string, object> {
                { "id_line", id_line },
                { "id_exit", id_exit }
            };
            return db.GetCheckSuperficialInspection(parameters);
        }

        [HttpGet]
        [Route("search")]
        public List<Dictionary<string, string>> GetProductionSearch(int id_line, DateTime start_date, DateTime end_date, string filter = "", int id_dictum = 0, int filter_mode = 0)
        {
            this.InitializeWebStatistic();

            var parameters = new Dictionary<string, object> {
                { "id_line", id_line },
                { "start_date", start_date },
                { "end_date", end_date },
                { "filter", filter ?? "" },
                { "id_dictum", id_dictum },
                { "filter_mode", filter_mode }
            };

            var data = db.GetProductionSearch(parameters);
            return data;
        }

        [HttpGet]
        [Route("production_dictum")]
        public List<Dictionary<string, string>> GetProductionDictum(int id_line)
        {
            var parameters = new Dictionary<string, object> {
                {"id_line", id_line}
            };

            return db.GetProductionDictum(parameters);
        }

        //[prod].[usp_web_get_production_report_metallic_balance]
        [HttpGet]
        [Route("metallic_balance")]
        public IHttpActionResult GetMetallicBalance(int id_line, DateTime start_date, DateTime end_date, string filter = "")
        {
            try
            {
                this.InitializeWebStatistic();

                var parameters = new Dictionary<string, object> {
                    { "id_line", id_line },
                    { "start_date", start_date },
                    { "end_date", end_date },
                    { "material", filter }
                };
                return Ok(db.GetMetallicBalance(parameters));
            }
            catch (Exception e)
            {
                return InternalServerError(e);
            }
        }

        [HttpGet]
        [Route("retirement_line")]
        public List<Dictionary<string, string>> GetRetirementLine(int id_line, DateTime start_date, DateTime end_date, string filter = "")
        {
            this.InitializeWebStatistic();

            var parameters = new Dictionary<string, object> {
                { "id_line", id_line },
                { "start_date", start_date },
                { "end_date", end_date },
                { "material", filter }
            };
            return db.GetRetirementLine(parameters);
        }

        [HttpGet]
        [Route("defects_generic")]
        public List<Dictionary<string, string>> GetDefectsGeneric(int id_line, int id, string type)
        {
            this.InitializeWebStatistic();

            var parameters = new Dictionary<string, object> {
                { "id_line", id_line },
                { "id", id },
                { "type", type }
            };
            return db.GetDefectsGeneric(parameters);
        }

        [HttpGet]
        [Route("shrinks")]
        public List<Dictionary<string, string>> GetShrinks(int id_line, DateTime start_date, DateTime end_date, string filter = "")
        {
            this.InitializeWebStatistic();

            var parameters = new Dictionary<string, object> {
                { "id_line", id_line },
                { "start_date", start_date },
                { "end_date", end_date },
                { "material", filter }
            };
            return db.GetShrinks(parameters);
        }

        [HttpGet]
        [Route("suspension")]
        public List<Dictionary<string, string>> GetSuspension(int id_line, DateTime start_date, DateTime end_date, string filter = "")
        {
            this.InitializeWebStatistic();

            var parameters = new Dictionary<string, object> {
                { "id_line", id_line },
                { "start_date", start_date },
                { "end_date", end_date },
                { "material", filter }
            };
            return db.GetSuspension(parameters);
        }

        //GetOrdersList
        [HttpGet]
        [Route("orders_list")]
        public List<Dictionary<string, string>> GetOrdersList(int id_line, string filter = "")
        {
            this.InitializeWebStatistic();

            var parameters = new Dictionary<string, object> {
                { "id_line", id_line },
                { "order", filter }
            };
            return db.GetOrdersList(parameters);
        }

        //GetOrdersDetails
        [HttpGet]
        [Route("orders_details")]
        public List<Dictionary<string, string>> GetOrdersDetails(int id_line, int id_order_item)
        {
            this.InitializeWebStatistic();

            var parameters = new Dictionary<string, object> {
                { "id_line", id_line },
                { "id_order_item", id_order_item }
            };
            return db.GetOrdersDetails(parameters);
        }

        //GetOrdersDetailsMaterials
        [HttpGet]
        [Route("orders_details_materials")]
        public List<Dictionary<string, string>> GetOrdersDetailsMaterials(int id_line, int id_order_item)
        {
            this.InitializeWebStatistic();

            var parameters = new Dictionary<string, object> {
                { "id_line", id_line },
                { "id_order_item", id_order_item }
            };
            return db.GetOrdersDetailsMaterials(parameters);
        }

        //GetOrdersDetailsMaterials
        [HttpGet]
        [Route("energy_consumption")]
        public List<Dictionary<string, string>> GetEnergyConsumption(int id_line, DateTime start_date, DateTime end_date)
        {
            this.InitializeWebStatistic();

            var parameters = new Dictionary<string, object> {
                { "id_line", id_line },
                { "start_date", start_date } ,
                { "end_date", end_date }
            };
            return db.GetEnergyConsumption(parameters);
        }

        //prod.usp_get_surface_inspection_defects_output
        [HttpGet]
        [Route("inspection_defects_output")]
        public IHttpActionResult GetSurfaceInspectionDefectsOutput(int id_line, int id_exit)
        {
            var parameters = new Dictionary<string, object>
                                     {
                                         { "id_line", id_line },
                                         { "id_exit", id_exit }
                                     };
            try
            {
                var data = db.GetSurfaceInspectionDefectsOutput(parameters);
                return Ok(data);
            }
            catch (Exception e)
            {
                return InternalServerError(e);
            }
        }

        [HttpGet]
        [Route("all_defects_output")]
        public IHttpActionResult GetAllDefectsOutput(int id_line, int id_exit)
        {
            var parameters = new Dictionary<string, object>
                                     {
                                         { "id_line", id_line },
                                         { "id_exit", id_exit }
                                     };
            try
            {
                var data = db.GetAllDefectsOutput(parameters);
                return Ok(data);
            }
            catch (Exception e)
            {
                return InternalServerError(e);
            }
        }

        [HttpGet]
        [Route("export_retirement_suspension_shrink")]
        public HttpResponseMessage GetExportExcel(int? id_line, int? id_report, DateTime start_date, DateTime end_date, string filter = "", string activeTab = "retirement") //, string material
        {
            this.InitializeWebStatistic();

            try
            {
                var columnsParams = new Dictionary<string, object>
                                    {
                                         { "id_line", id_line },
                                         { "id_report", id_report },
                                         { "to_show", 2}
                                     };

                var columns = db.GetReportColumns(columnsParams);

                var parameters = new Dictionary<string, object>{

                                {"id_line", id_line},
                                {"start_date", start_date},
                                {"end_date", end_date},
                                {"material", filter}

                };

                var result = new List<Dictionary<string, string>>();

                switch (activeTab)
                {
                    case "retirement":
                        result = this.db.GetRetirementLine(parameters);
                        break;
                    case "metallic-balance":
                        result = this.db.GetMetallicBalance(parameters);
                        break;
                    case "shrink":
                        result = this.db.GetShrinks(parameters);
                        break;
                    case "suspension":
                        result = this.db.GetSuspension(parameters);
                        break;
                }


                var reportDataDt = ExportController.GetDataToExport(result, columns);
                return export.GetMessageGenericReportExport(HttpStatusCode.OK, reportDataDt, "Retiro_Suspenciones_Mermas_Balance_" +
                                                                DateTime.Now.ToString("dd_MM_yyyy"), null);
            }
            catch (Exception ex)
            {
                return export.GetMessageExport(HttpStatusCode.InternalServerError, null, null, ex.Message);
            }

        }

        [HttpGet]
        [Route("export_defect_test_pdf")]
        public HttpResponseMessage getExportPDF(int id_line, int id_report, DateTime start_date, DateTime end_date, int id_dictum, string filter)
        {

            var parameters = new Dictionary<string, object>
                {
                    {"id_line", id_line},
                    {"id_report", id_report}
                };


            var reportConfig = dbAccess.GetReportConfig(parameters);

            byte[] file_content = createReport(id_line, id_report, start_date, end_date, id_dictum, filter, reportConfig);
            HttpResponseMessage result = null;
            result = Request.CreateResponse(HttpStatusCode.OK);
            result.Content = new ByteArrayContent(file_content);
            result.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("inline");
            result.Content.Headers.ContentType = new MediaTypeHeaderValue("application/pdf");
            result.Content.Headers.ContentDisposition.FileName = reportConfig["report"].Replace(" ", "_") + "_" + Convert.ToDateTime(reportConfig["current_date"]).ToString("dd-MM-yyyy").Replace("-", "_") + ".pdf";
            return result;
        }

        public byte[] createReport(int id_line, int id_report, DateTime start_date, DateTime end_date, int id_dictum, string filter, Dictionary<string, string> reportConfig)
        {
            var parameters = new Dictionary<string, object>
            {
                {"id_line", id_line},
                {"start_date", start_date},
                {"end_date", end_date},
                {"id_dictum", id_dictum},
                {"material", filter}
            };

            var shiftsParams = new Dictionary<string, object>
            {
                {"id_line", id_line}
            };

            var shiftsData = dbAccess.GetShifts(shiftsParams);
            var shifts = new Dictionary<string, string>();
            foreach (var shift in shiftsData)
            {
                shifts.Add("shift_" + shift["shift"], shift["start_time"] + " - " + shift["end_time"]);
            }

            var dataReport = db.GetDefectTestPdf(parameters);
            var dataResumen = db.GetResumenProduction(parameters);

            var dataTable = DABase.ConvertToDataTable(dataReport);
            var dataTableResumen = DABase.ConvertToDataTable(dataResumen);

            return rdlc.DefectTest(dataTable, dataTableResumen, reportConfig, start_date, end_date, shifts["shift_1"], shifts["shift_2"], shifts["shift_3"], HttpContext.Current.Server.MapPath("~/Reports/DefectTest.rdlc"));
        }

        [HttpGet]
        [Route("export_production_excel")]
        public HttpResponseMessage GetExportProductionExcel(int? id_line, int? id_report, DateTime date, int? shift, bool order_asc = false)
        {
            //this.InitializeWebStatistic();

            try
            {
                var columnsParams = new Dictionary<string, object>
                                    {
                                         { "id_line", id_line },
                                         { "id_report", id_report },
                                         { "to_show", 2}
                                     };

                var columns = db.GetReportColumns(columnsParams);

                var parameters = new Dictionary<string, object> {
                { "id_line", id_line },
                { "ternium_date", date },
                { "id_shift", shift },
                { "order_asc", order_asc }

            };

                var reportData = db.GetProductionCoils(parameters);
                var reportDataDt = ExportController.GetDataToExport(reportData, columns);
                return export.GetMessageGenericReportExport(HttpStatusCode.OK, reportDataDt, "Produccion_" + 
                                                            DateTime.Now.ToString("dd_MM_yyyy"), null);// NO poner acento porque se daña en IE
            }
            catch (Exception ex)
            {
                return export.GetMessagePublicReportExport(HttpStatusCode.InternalServerError, null, null, ex.Message);
            }

        }

        [HttpGet]
        [Route("export_search_excel")]
        public HttpResponseMessage GetExportSearchExcel(int? id_line, int? id_report, DateTime start_date, DateTime end_date, int? id_dictum, string filter = "", int filter_mode = 0) //, string material
        {
            //this.InitializeWebStatistic();

            try
            {
                var columnsParams = new Dictionary<string, object>
                                    {
                                         { "id_line", id_line },
                                         { "id_report", id_report },
                                         { "to_show", 2}
                                     };

                var columns = db.GetReportColumns(columnsParams);

                var parameters = new Dictionary<string, object> {
                { "id_line", id_line },
                { "start_date", start_date },
                { "end_date", end_date },
                { "filter", filter ?? "" },
                { "id_dictum", id_dictum },
                { "filter_mode", filter_mode }

            };

                var reportData = db.GetProductionSearch(parameters);
                var reportDataDt = ExportController.GetDataToExport(reportData, columns);
                return export.GetMessageGenericReportExport(HttpStatusCode.OK, reportDataDt, "Produccion_" + // NO poner acento porque se daña en IE
                                                            DateTime.Now.ToString("dd_MM_yyyy"), null);
            }
            catch (Exception ex)
            {
                return export.GetMessagePublicReportExport(HttpStatusCode.InternalServerError, null, null, ex.Message);
            }

        }


        [HttpGet]
        [Route("get_report_sheet_gantt_flow")]
        public IHttpActionResult GetAceProductionGeneric(String id_line, String return_defects, String start_date, String end_date, string filter, string order_asc)
        {
            //usp_web_get_ace_production_generic
            try
            {
                Dictionary<string, dynamic> response = new Dictionary<string, dynamic>();

                var parameters = new Dictionary<string, object> {
                    { "id_line", id_line },
                    { "return_defects", (return_defects != null || return_defects != "") ? return_defects : null },
                    { "start_date", start_date },
                    { "end_date", end_date },
                    { "filter", (filter != null || filter != "") ? filter : null },
                    { "order_asc", (order_asc != null || order_asc != "") ? order_asc : null }
                };

                List<Dictionary<string, string>> data = db.GetAceProductionGeneric(parameters);


                response.Add("sucess", "1");
                response.Add("data", data);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

       public List<Dictionary<string, string>> GetInfoProductionDetails(int id_line, DateTime date, int shift)
        {
            var parameters = new Dictionary<string, object> {
                { "id_line", id_line },
                { "date", date },
                { "shift", shift }
            };
            return db.GetProductionDefects(parameters);
        }

            
        
        [HttpGet]
        [Route("get_web_ace_production_summary")]
       public IHttpActionResult GetWebGetAceProductionSummary(String id_line, String beginDate, String endDate, int shift, int grade)
        {
            Dictionary<string, dynamic> response = new Dictionary<string, dynamic>();

            try{
                var parameters = new Dictionary<string, object> {
                    { "id_line", id_line },
                    { "beginDate", beginDate },
                    { "endDate", endDate },
                    { "shift", shift },
                    { "grade", grade }
                };

                List<Dictionary<string, string>> dataFlows = db.GetWebGetAceProductionSummary(parameters);

                response.Add("success", "1");
                response.Add("data", dataFlows);

            }
            catch (Exception ex)
            {
                response.Add("success", "0");
                response.Add("message", ex);
                
            }

            return Ok(response);
        }
        [HttpGet]
        [Route("get_gantt_flow_general")]
        public IHttpActionResult GetFlowGeneralData(String id_plant, String grade, String beginDate, String endDate, int shift)
        {
            try
            {
                Dictionary<string, dynamic> response = new Dictionary<string, dynamic>();
                List<Dictionary<string, dynamic>> items = new List<Dictionary<string, dynamic>>();
                List<DetailItem> detail = new List<DetailItem>();

                var parameters = new Dictionary<string, object> {
                    { "id_plant", id_plant },
                    { "beginDate", beginDate },
                    { "endDate", endDate },
                    { "shift", shift },
                    { "grade",  (grade != null || grade != "") ? grade : null }
                };

                List<Dictionary<string, string>> dataFlows = db.GetFlowGeneralData(parameters);
                Dictionary<string, dynamic> data;

                var dataRows = dataFlows.GroupBy(p => p["id_line"]).ToArray();
                //ToDictionary(t => t.Key)
                string title = "";
                foreach (var i in dataRows)
                {
                    data = new Dictionary<string, dynamic>();
                    List<GanttItemSteelWorks> itemsGanttIteSteel = new List<GanttItemSteelWorks>();
                    List<Dictionary<string, dynamic>> groups = new List<Dictionary<string, dynamic>>();
                    int rowGroupId = 1;

                    foreach (var item in i)
                    {
                        title = item["line"];
                        detail = new List<DetailItem>();
                        GanttItemSteelWorks ganttItemCasting = new GanttItemSteelWorks(item);

                        DetailItem _flow = new DetailItem("Colada", item["flow"]);
                        DetailItem fecha_inicio = new DetailItem("Fecha Inicio", item["fecha_inicio"]);
                        DetailItem fecha_fin = new DetailItem("Fecha Fin", item["fecha_fin"]);
                        DetailItem _grade = new DetailItem("Grado", item["grade"]);

                        parameters = new Dictionary<string, object> {
                            { "id_line", ganttItemCasting.id_line },
                            { "date", endDate },
                            { "shift", shift }
                        };

                        detail.Add(_flow);
                        detail.Add(fecha_inicio);
                        detail.Add(fecha_fin);
                        detail.Add(_grade);
                        ganttItemCasting.Details = detail;


                        Dictionary<string, dynamic> group = groups.FirstOrDefault(d => d.ContainsKey(ganttItemCasting.grade));

                        if (group == null)
                        {
                            Dictionary<string, dynamic> _group = new Dictionary<string, dynamic>();
                            _group.Add(ganttItemCasting.grade, rowGroupId);
                            groups.Add(_group);
                            ganttItemCasting.group_id = rowGroupId;
                            rowGroupId++;
                        }
                        else
                        {
                            ganttItemCasting.group_id = group[ganttItemCasting.grade];
                        }

                        itemsGanttIteSteel.Add(ganttItemCasting);



                    }

                    List<Dictionary<string, string>> dataDelays = db.GetLineDelays(parameters);

                    var items_group_by_exit_number = itemsGanttIteSteel.OrderBy(x => x.numero_salida).GroupBy(x => x.numero_salida);


                    data.Add("title", title);
                    data.Add("castings", items_group_by_exit_number);
                    data.Add("delays", dataDelays);
                    items.Add(data);

                }
                response.Add("sucess", "1");
                response.Add("data", items);
                return Ok(response);

            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        [HttpGet]
        [Route("get_sheet_gantt_flow")]
        public IHttpActionResult GetSheetGanttFlow(String id_line, String flow, String beginDate, String endDate, int shift)
        {

            try
            {
                Dictionary<string, dynamic> response = new Dictionary<string, dynamic>();
                Dictionary<string, dynamic> data = new Dictionary<string, dynamic>();
                List<DetailItem> detail = new List<DetailItem>();
                List<GanttItemSteelWorks> items = new List<GanttItemSteelWorks>();

                var parameters = new Dictionary<string, object> {
                    { "lineId", id_line },
                    { "flow", (flow != null || flow != "") ? flow : null },
                    { "beginDate", beginDate },
                    { "endDate", endDate },
                    { "shift", shift }
                };

                List<Dictionary<string, string>> dataFlows = db.GetSheetGanttFlow(parameters);

                parameters = new Dictionary<string, object> {
                    { "id_line", id_line },
                    { "date", endDate },
                    { "shift", shift }
                };

                List<Dictionary<string, dynamic>> groups = new List<Dictionary<string, dynamic>>();

                List<Dictionary<string, string>> getLineDelays = db.GetLineDelays(parameters);
                int rowGroupId = 1;
                string titleGantt = "";

                foreach (var item in dataFlows)
                {
                    titleGantt = item["line"];
                    detail = new List<DetailItem>();
                    GanttItemSteelWorks ganttItemCasting = new GanttItemSteelWorks(item);

                    DetailItem _flow = new DetailItem("Colada", item["flow"]);
                    DetailItem fecha_inicio = new DetailItem("Fecha Inicio", item["fecha_inicio"]);
                    DetailItem fecha_fin = new DetailItem("Fecha Fin", item["fecha_fin"]);
                    DetailItem grade = new DetailItem("Grado", item["grade"]);

                    detail.Add(_flow);
                    detail.Add(fecha_inicio);
                    detail.Add(fecha_fin);
                    detail.Add(grade);
                    ganttItemCasting.Details = detail;

                    //d["key"] == ganttItemCasting.grade
                    Dictionary<string, dynamic> group = groups.FirstOrDefault(d => d.ContainsKey(ganttItemCasting.grade));

                    if (group == null)
                    {
                        Dictionary<string, dynamic> _group = new Dictionary<string, dynamic>();
                        _group.Add(ganttItemCasting.grade, rowGroupId);
                        groups.Add(_group);
                        ganttItemCasting.group_id = rowGroupId;
                        rowGroupId++;
                    }
                    else
                    {
                        ganttItemCasting.group_id = group[ganttItemCasting.grade];
                    }
                    items.Add(ganttItemCasting);

                }

                List<Dictionary<string, dynamic>> _item = new List<Dictionary<string, dynamic>>();
                _item.Add(data);
                var items_group_by_exit_number = items.OrderBy(x => x.numero_salida).GroupBy(x => x.numero_salida);
                //.Select(x => x.OrderByDescending(f => f.numero_salida));

                data.Add("title", titleGantt);
                data.Add("castings", items_group_by_exit_number);
                data.Add("delays", getLineDelays);
                response.Add("sucess", "1");
                response.Add("data", _item);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }


        private List<Dictionary<string, string>> GetInfoProductionCoils(int id_line, DateTime date, int shift, bool order_asc)
        {
            var parameters = new Dictionary<string, object>
                                    {
                                        { "id_line", id_line },
                                        { "id_shift", shift },
                                        { "ternium_date", date },
                                        { "order_asc", order_asc }
                                    };

            try
            {
                return db.GetProductionCoils(parameters);
            }
            catch (Exception)
            {
                throw;
                //return new List<Dictionary<string, string>>();
            }
        }

        private List<Dictionary<string, string>> GetExitLines(int id_line)
        {
            var parameters = new Dictionary<string, object>
                                    {
                                        { "id_line", id_line },
                                    };

            try
            {
                return db.GetExitLines(parameters);
            }
            catch (Exception)
            {
                throw;
                //return new List<Dictionary<string, string>>();
            }
        }

        [HttpGet]
        [Route("get_cobble_info")]
        public Dictionary<string, string> GetCobbleInfo(int id_line, string material = null, string program = null, int? item = null, int? position = null)
        {
            var parameters = new Dictionary<string, object>
                                    {
                                        { "id_line", id_line },
                                        { "material", material },
                                        { "program", program },
                                        { "item", item },
                                        { "position", position }
                                    };

            try
            {
                return db.GetCobbleInfo(parameters);

            }
            catch (Exception)
            {
                throw;
                //return new List<Dictionary<string, string>>();
            }
        }

        /// <summary>
        /// Generic data collector 
        /// </summary>
        [HttpGet]
        [Route("get_report_data_steelworks")]
        public IHttpActionResult GetReportDataSteelWorks(int id_line, int id_report, DateTime start_date, DateTime end_date, int? shift = null, int? mode = null)
        {
            try
            {
                var reportConfigParams = new Dictionary<string, object>
                {
                    {"id_line", id_line},
                    {"id_report", id_report}
                };
                if (mode != null)
                {
                    var spParams = new Dictionary<string, object> {
                    {"id_line", id_line},
                    {"start_date", start_date},
                    {"end_date", end_date},
                    {"shift", shift },
                    {"mode", mode }

                };
                    var reportConfig = dbAccess.GetReportConfig(reportConfigParams);
                    var reportData = db.GetReportData(reportConfig["sp_report_data"], spParams);
                    return Ok(reportData);
                }
                else
                {
                    var spParams = new Dictionary<string, object> {
                    {"id_line", id_line},
                    {"start_date", start_date},
                    {"end_date", end_date},
                    {"shift", shift }
                };
                    var reportConfig = dbAccess.GetReportConfig(reportConfigParams);
                    var reportData = db.GetReportData(reportConfig["sp_report_data"], spParams);
                    return Ok(reportData);
                }

            }
            catch (Exception ex)
            {
                return BadRequest("GetReportDataSteelWorks Error => " + ex.Message);
            }
        }

        [HttpGet]
        [Route("export_steelwork_production_excel")]
        public HttpResponseMessage GetExportSteelWorkProductionExcel(int id_line, int id_report, DateTime date_init, DateTime date_end, int? shift = null, bool order_asc = false)
        {
            //this.InitializeWebStatistic();

            try
            {
                var reportConfigParams = new Dictionary<string, object>
                {
                    {"id_line", id_line},
                    {"id_report", id_report}
                };

                var columns = db.GetReportColumns(reportConfigParams);

                var spParams = new Dictionary<string, object> {
                     {"id_line", id_line},
                    {"date_init", date_init},
                    {"date_end", date_end},
                    {"shift", shift }
                };

                var reportConfig = dbAccess.GetReportConfig(reportConfigParams);

                var reportData = db.GetReportData(reportConfig["sp_report_data"], spParams);
                var reportDataDt = ExportController.GetDataToExport(reportData["production"], columns);
                return export.GetMessageGenericReportExport(HttpStatusCode.OK, reportDataDt, reportConfig["report_code"] +
                                                            DateTime.Now.ToString("dd_MM_yyyy"), null);
            }
            catch (Exception ex)
            {
                return export.GetMessagePublicReportExport(HttpStatusCode.InternalServerError, null, null, ex.Message);
            }

        }

        [HttpGet]
        [Route("search_material")]
        public IHttpActionResult SteelworkSearchByMaterial(int id_line, string material_number, int? search_by_ld = 0)
        {
            try
            {
                var spParams = new Dictionary<string, object> {
                    {"id_line", id_line},
                    {"material_number", material_number},
                    {"search_by_ld", search_by_ld}
                };

                var searchResult = db.GetSearchMaterial(spParams);

                return Ok(searchResult);

            }
            catch (Exception ex)
            {
                return BadRequest("SteelworkSearchByMaterial Error => " + ex.Message);
            }
        }


		[HttpGet]
        [Route("integrada_ccd")]
        public List<Dictionary<string, string>> GetIntegratedProductionCCD(int id_line, DateTime date, int shift, string hit, string line, string slab)
        {
            var parameters = new Dictionary<string, object>
                                    {
                                        { "id_linea", id_line },
                                        { "fecha_ini", date },
                                        { "turno", shift },
                                        //{ "id_salida", id_salida },
                                        { "colada", hit },
                                        { "nroLinea", line },
                                        { "planchon", slab },
                                    };

            try
            {
                return db.GetIntegratedProductionCCD(parameters);
            }
            catch (Exception)
            {
                throw;
                //return new List<Dictionary<string, string>>();
            }
        }

        [HttpGet]
        [Route("integrada_esc")]
        public List<Dictionary<string, string>> GetIntegratedProductionESC(int id_line, DateTime date, int shift, string hit, string line, string slab)
        {
            var parameters = new Dictionary<string, object>
                                    {
                                        { "id_linea_esc", id_line },
                                        { "fecha_ini", date },
                                        { "turno", shift },
                                        //{ "id_salida", id_salida }
                                        { "colada", hit },
                                        { "nroLinea", line },
                                        { "planchon", slab },
                                       
                                    };

            try
            {
                return db.GetIntegratedProductionESC(parameters);
            }
            catch (Exception)
            {
                throw;
                //return new List<Dictionary<string, string>>();
            }
        }

        [HttpGet]
        [Route("integrada_pan")]
        public List<Dictionary<string, string>> GetIntegratedProductionPAN(int id_line, DateTime date, int shift, string hit, string line, string slab)
        {
            var parameters = new Dictionary<string, object>
                                    {
                                        { "id_linea_pan", id_line },
                                        { "fecha_ini", date },
                                        { "turno", shift },
                                        //{ "id_salida", id_salida }
                                        { "colada", hit },
                                         { "nroLinea", line },
                                        { "planchon", slab },
                                       
                                    };

            try
            {
                return db.GetIntegratedProductionPAN(parameters);
            }
            catch (Exception)
            {
                throw;
                //return new List<Dictionary<string, string>>();
            }
        }

        [HttpGet]
        [Route("slabs_graph")]
        public IHttpActionResult GetSlabsProductionGraph(int id_line, DateTime date, string unit, int shift)
        {
            this.InitializeWebStatistic();
            try
            {
                var parameters = new Dictionary<string, object>
                                    {
                                        { "id_line", id_line },
                                        { "date", date },
                                        { "unidad", unit },
                                        { "shift", shift }
                                       
                                       
                                    };
                var data = db.GetSlabsProductionGraph(parameters);
                return Ok(data);
               
            }
            catch (Exception ex )
            {
                return InternalServerError(ex);
               
            }
        }

        /// <summary>
        /// Get Next/Previous Coil
        /// </summary>
        /// <param name="id_line"></param>
        /// <param name="id_exit"></param>
        /// <param name="is_previous"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("get_previous_next_coil")]
        public Dictionary<string, string> GetPreviousNextCoil(int id_line, int id_exit, int is_previous)
        {
            var parameters = new Dictionary<string, object>
            {
                { "id_line", id_line },
                { "id_exit", id_exit },
                { "is_previous", is_previous }
            };

            return db.GetPreviousNextCoil(parameters);

        }

      

        [HttpGet]
        [Route("dimensions")]
        public IHttpActionResult GetSlabsDimensional(int id_line, int id_report, DateTime start_date, DateTime end_date, int shift, string unit, int id_out, int group, int line_heat, int speed, int width)
        {
            try
            {
               
                var parameters = new Dictionary<string, object>
                            {
                                { "id_linea", id_line },
                                { "fecha_ini", start_date },
                                { "fecha_fin", end_date },
                                { "turno", shift },
                                { "unidad", unit },
                                { "id_salida", id_out },
                                { "grupo", group },
                                { "linea_colada", line_heat },
                                { "velocidad", speed },
                                { "ancho", width }
                                };

                var reportData = db.GetSlabsDimensional("[prod].[usp_web_getSlabsDimensional]", parameters);

                return Ok(reportData);

            }
            catch (Exception ex)
            {
                return BadRequest("GetSlabsDimensional Error => " + ex.Message);
            }
        }

       
 [HttpGet]
        [Route("export_dimensions_slabs")]
        public HttpResponseMessage GetExportDimensionsSlabs(int id_line, int id_report, DateTime start_date, DateTime end_date, int shift = 0, string unit = "", int id_out = -1, int group = 0, int line_heat = 0, int speed = 0, int width = 0) //, string material
        {
            //this.InitializeWebStatistic();

            try
            {
                var columnsParams = new Dictionary<string, object>
                                    {
                                         { "id_line", id_line },
                                         { "id_report", id_report },
                                      };

                var columns = db.GetReportColumns(columnsParams);

                var parameters = new Dictionary<string, object> {
                                { "id_linea", id_line },
                                { "fecha_ini", start_date },
                                { "fecha_fin", end_date },
                                { "turno", shift },
                                { "unidad", unit },
                                { "id_salida", id_out },
                                { "grupo", group },
                                { "linea_colada", line_heat },
                                { "velocidad", speed },
                                { "ancho", width }
                };

                var reportConfig = dbAccess.GetReportConfig(columnsParams);
                var reportData = db.GetSlabsDimensional(reportConfig["sp_report_data"], parameters);
                var reportDataDt = ExportController.GetDataToExport(reportData["Export"], columns);
                return export.GetMessageGenericReportExport(HttpStatusCode.OK, reportDataDt, reportConfig["report_code"] +
                                                           DateTime.Now.ToString("dd_MM_yyyy"), null);

              
            }
            catch (Exception ex)
            {
                return export.GetMessagePublicReportExport(HttpStatusCode.InternalServerError, null, null, ex.Message);
            }

        }

         [HttpGet]
         [Route("group")]
         public List<Dictionary<string, string>> GetProductionGroup(int id_line)
         {
             var parameters = new Dictionary<string, object> {
                        {"id_line", id_line}
                    };

             return db.GetProductionGroup(parameters);
         }

         [HttpGet]
         [Route("line")]
         public List<Dictionary<string, string>> GetProductionLine(int id_line)
         {
             var parameters = new Dictionary<string, object> {
                        {"id_line", id_line}
                    };

             return db.GetProductionLine(parameters);
         }


        [HttpGet]
        [Route("line_heat")]
        public List<Dictionary<string, string>> GetProductionLineHeat(int id_line)
        {
            var parameters = new Dictionary<string, object> {
                        {"id_line", id_line}
                    };
                   
            return db.GetProductionLineHeat(parameters);
        }


        [HttpGet]
        [Route("speed")]
        public List<Dictionary<string, string>> GetProductionSpeed(int id_line)
        {
            var parameters = new Dictionary<string, object> {
                        {"id_line", id_line}
                    };

            return db.GetProductionSpeed(parameters);
        }


        [HttpGet]
        [Route("width")]
        public List<Dictionary<string, string>> GetProductionWidth(int id_line)
        {
            var parameters = new Dictionary<string, object> {
                        {"id_line", id_line}
                    };

            return db.GetProductionWidth(parameters);
        }


        [HttpGet]
        [Route("get_sgl_indicators")]
        public Dictionary<string, string> GetSglApiData(int id_line, DateTime date, int shift)
        {
            //var settingUrl = ConfigurationManager.AppSettings["UrlSglAllIndicatorsApi"];
            //var url = new Uri(settingUrl.Replace("{id}", idLine.ToString()).Replace("{f}", date).Replace("{t}", shift.ToString()));

            //var client = new HttpClient();
            //client.BaseAddress = new Uri(url.GetLeftPart(UriPartial.Authority));
            //client.DefaultRequestHeaders.Accept.Clear();
            //client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            //var response = client.GetAsync(url.PathAndQuery).Result;

            //var content = new Dictionary<string, string>();
            //if (response.IsSuccessStatusCode)
            //{
            //    content = response.Content.ReadAsAsync<Dictionary<string, string>>().Result;

            //}
            
                var d = date.ToString("yyyyMMdd");

                var settingUrl = ConfigurationManager.AppSettings["UrlSglAllIndicatorsApi"];
                var url = new Uri(settingUrl.Replace("{id}", id_line.ToString()).Replace("{f}", d));

                var client = new HttpClient();
                client.BaseAddress = new Uri(url.GetLeftPart(UriPartial.Authority));
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync(url.PathAndQuery).Result;

                var content = new Dictionary<string, string>();
                if (response.IsSuccessStatusCode)
                {
                    var querySglData = response.Content.ReadAsAsync<Dictionary<string, object>>().Result;
                    if (querySglData != null && querySglData.Any())
                    {
                        var shiftName = "Todos";
                        switch (shift)
                        {
                            case 2:
                                shiftName = "Maniana";
                                break;
                            case 3:
                                shiftName = "Tarde";
                                break;
                            case 1:
                                shiftName = "Noche";
                                break;
                        }

                        if (querySglData.ContainsKey(shiftName))
                        {
                            var shiftData = JsonConvert.DeserializeObject<Dictionary<string, object>>(querySglData[shiftName].ToString());
                            if (shiftData.ContainsKey("Eficiencia_Neta_Real"))
                            {
                                content.Add("Eficiencia_Neta_Real", shiftData["Eficiencia_Neta_Real"] != null ? shiftData["Eficiencia_Neta_Real"].ToString() : string.Empty);
                            }
                        }
                    }
                }
           
                return content;
        }
    }
    

}
