﻿﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;
using Ternium.Sio_Server.Models.Curves;
using Ternium.Sio_Server.Models.Repository;
using Ternium.Sio_Server.Utilities;

namespace Ternium.Sio_Server.Controllers
{
    /// <summary>
    /// Api method for Curves
    /// </summary>
    [EnableCORS(origins: new string[] { "localhost:50698", "termxsppapp45" }, methods: "*")]  
    [RoutePrefix("api/curves")]
    public class CurvesController : ApiController
    {
        private readonly DAProduction db = new DAProduction();

        [HttpGet]
        [Route("config_length")]
        public IHttpActionResult GetCurveConfigLength(int id_line, string material)
        {
            try
            {
                if (id_line == 0)
                {
                    return BadRequest("IdLine is not specified");
                }

                var model = new CurvesModel();

                var config = db.GetLineConfig(id_line);
                var parameters = new Dictionary<string, object>
                                    {
                                        { "id_line", id_line }
                                    };
                model.id_line = config.IdLine;
                model.material = material;
                model.multi_panel_default = config.DefaultMultiPanelCurves;
                model.join_y_axis_default = config.DefaultJoinAxisCurves;
                var xAxis = db.GetCurvesAxisLength(parameters).Where(x => x["id_variable_type"] == "X").ToList();

                // Get X Axis
                model.x_axis = ConvertToAxi(xAxis);

                // Get Y Axis
                var yAxis = db.GetCurvesAxisLength(parameters).Where(x => x["id_variable_type"] == "Y").ToList();
                model.y_axis = ConvertToAxi(yAxis);
                return Ok(model);
            }
            catch (Exception ex)
            {
                return BadRequest("GetCurveConfig Error => " + ex.Message);
            }
        }

        
        [HttpGet]
        [Route("curves_types")]
        public IHttpActionResult GetCurveTypes(int id_line)
        {
            var parameters = new Dictionary<string, object>
                                    {
                                        { "id_line", id_line }
                                    };
            try
            {
                return Ok(db.GetCurveTypes(id_line));
            }
            catch (Exception e)
            {
                return InternalServerError(e);
            }
        }

        /// <summary>
        /// Get the curve configuration.
        /// </summary>
        /// <param name="id_line"></param>
        /// <param name="material"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("config")]
        public IHttpActionResult GetCurveConfig(int id_line, string material)
        {

            try
            {
                if (id_line == 0)
                {
                    return BadRequest("IdLine is not specified");
                }

                var model = new CurvesModel();

                var config = db.GetLineConfig(id_line);
                var parameters = new Dictionary<string, object>
                                    {
                                        { "id_line", id_line },
                                        { "id_variable_x", 0 }
                                    };
                model.id_line = config.IdLine;
                model.material = material;
                model.multi_panel_default = config.DefaultMultiPanelCurves;
                model.join_y_axis_default = config.DefaultJoinAxisCurves;
                var xAxis = db.GetCurveAxis(parameters).Where(x => x["id_variable_type"] == "X").ToList();
                model.curve_types = db.GetCurveTypes(id_line);
                // Get X Axis
                model.x_axis = ConvertToAxi(xAxis);

                // Get Y Axis
                var yAxis = db.GetCurveAxis(parameters).Where(x => x["id_variable_type"] == "Y").ToList();
                model.y_axis = ConvertToAxi(yAxis);

                return Ok(model);
            }
            catch (Exception ex)
            {
                return BadRequest("GetCurveConfig Error => " + ex.Message);
            }
        }

        /// <summary>
        /// Get Y axis.
        /// </summary>
        /// <param name="id_line"></param>
        /// <param name="x_axi"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("y_axis")]
        public List<Axi> GetYAxis(int id_line, int x_axi)
        {
            var parameters = new Dictionary<string, object>
                                    {
                                        { "id_line", id_line },
                                        { "id_variable_x", x_axi }
                                    };
            return ConvertToAxi(db.GetCurveAxis(parameters));
        }

        /// <summary>
        /// Get Trending Sections
        /// </summary>
        /// <param name="id_line"></param>
        /// <param name="material"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("trending_sections")]
        public IHttpActionResult GetTrendingSections(int id_line, string material)
        {
            var parameters = new Dictionary<string, object>
                                     {
                                         { "id_line", id_line },
                                         { "material", material }
                                     };
            try
            {
                var data = db.GetTrendingSections(parameters);
                return Ok(data);
            }
            catch (Exception e)
            {
                return InternalServerError(e);
            }
        }
        
        /// <summary>
        /// Get Curve Data.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        [HttpPost, HttpOptions]
        [Route("curve_data")]
        public IHttpActionResult GetCurvesData(CurveDataParams parameters)
        {
            if (HttpContext.Current.Request.HttpMethod == "OPTIONS")
            {
                return Ok();
            }
            CurveDataResponse response = new CurveDataResponse { Success = true };

            parameters.material = parameters.material ?? "";
            var data = db.GetCurvesData(parameters.id_line, parameters.id_exit, parameters.material);

            //if (data.Count == 0)
            //{
            //    response.Success = false;
            //    response.ResponseText = "No existen datos para graficar.";
            //    return Ok(response);
            //}

            var _params = new Dictionary<string, object>
                                {
                                    { "id_line", parameters.id_line }
                                };

            List<int> xAxisId = new List<int>();
            List<AxiData> yAxisData = new List<AxiData>();
            var yAxis = parameters.y_axis_list;
            foreach (var item in yAxis)
            {
                if (xAxisId.Contains(item.id_variable_x) == false)
                    xAxisId.Add(item.id_variable_x);
                var yAxi = data.Find(x => x.id_variable == item.id_variable);
                if (yAxi != null) {
                    yAxisData.Add(yAxi);
                }
                else
                {
                    yAxisData.Add(new AxiData());
                }
            }

            List<AxiData> xAxisData = new List<AxiData>();
            //data.Where(x => xAxisId.Contains(x.id_variable)).ToList();
            foreach (var xVariable in xAxisId)
            {
                if (data.Exists(x => x.id_variable == xVariable))
                {
                    xAxisData.Add(data.Find(x => x.id_variable == xVariable));
                }
                else
                {
                    xAxisData.Add(new AxiData());
                }
            }

            foreach (var item in xAxisData)
            {
                if (item.ZipEncode64Curve != null)
                {
                    item.Values = CurvesUtility.Decodex64Curve(item.ZipEncode64Curve);
                    item.Values.Sort();
                }
            }

            if (xAxisData.Count == 0)
            {
                xAxisData.Add(new AxiData());
            }

            foreach (var yAxiData in yAxisData)
            {
                if (yAxiData.ZipEncode64Curve != null)
                {
                    yAxiData.id_variable_x = yAxis.First(x => x.id_variable == yAxiData.id_variable).id_variable_x;
                    yAxiData.Values = CurvesUtility.Decodex64Curve(yAxiData.ZipEncode64Curve);
                }
            }

            if (yAxisData.Count == 0)
            {
                yAxisData.Add(new AxiData());
            }
            response.XAxi = xAxisData;
            response.YAxis = yAxisData;

            return Ok(response);
        }

        /// <summary>
        /// Get Next/Previous Coil
        /// </summary>
        /// <param name="id_line"></param>
        /// <param name="id_exit"></param>
        /// <param name="is_previous"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("get_coil")]
        public Dictionary<string, string> GetPreviousNextCoil(int id_line, int id_exit, int is_previous)
        {
            var parameters = new Dictionary<string, object>
            {
                { "id_line", id_line },
                { "id_exit", id_exit },
                { "is_previous", is_previous }
            };
            return db.GetPreviousNextCoil(parameters);
        }

        /// <summary>
        /// Get Curve Planeza 3D Data.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("curve_data_planeza_3d")]
        public Dictionary<string, object> GetCurvePlaneza3D(int id_line, int id_exit, String id_variable_type)
        {
            var parameters = new Dictionary<string, object>
            {
                { "id_line", id_line },
                { "id_exit", id_exit }
            };
           
            var data = db.GetCurvePlaneza3D(parameters);
            Dictionary<string, object> curve_dataset = new Dictionary<string, object>();
            List<object> description = new List<object>();
            List<object> curves = new List<object>();
            List<object> dataCurvesPlanezaUI = new List<object>();

            if(data.Count > 0){


                foreach (var curve in data) {
                    Dictionary<string, object> _description = new Dictionary<string, object>();
                    parameters["id_variable"] = curve["id_variable"];
                    

                    _description.Add("name", curve["description"]);
                    _description.Add("id_variable", curve["id_variable"]);
                    
                    description.Add(_description);
                    Dictionary<string, object> _curves =  CurvesUtility.Decodex64Curve3D(curve);

                    _curves.Add("additional_info", curve["additional_info"]);
                    _curves.Add("scale_colors",db.GetProcessCurves3dLimits(parameters));
                    curves.Add(_curves);
                }
                curve_dataset.Add("success", 1);
                curve_dataset.Add("dropdown_labels", description);
                curve_dataset.Add("curves", curves);
                
            }
            else
            {
                curve_dataset.Add("success", "0");
            }

          
            return curve_dataset;

        }

        private List<Axi> ConvertToAxi(List<Dictionary<string, string>> data)
        {
            List<Axi> list = new List<Axi>();
            foreach (var item in data)
            {
                list.Add(new Axi
                {
                    id_variable = int.Parse(item["id_variable"].ToString()),
                    description = item["description"].ToString(),
                    type = item["id_variable_type"].ToString(),
                    tag = item["tag"].ToString(),
                    selected = item["default"] == "1",
                    unit = item.ContainsKey("unit") ? item["unit"].ToString() : "",
                    id_variable_x = int.Parse(item["id_variable_x"].ToString())
                });
            }
            return list;
        }
    }
}
