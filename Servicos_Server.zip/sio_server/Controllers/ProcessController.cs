﻿using LIN.Controllers;
using System;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Http;
using Ternium.Sio_Server.Models;
using Ternium.Sio_Server.Models.Repository;
using System.Web;
using Newtonsoft.Json.Linq;
//using Ternium.Sio_Server.Models.ControlPanel;
using Ternium.Sio_Server.Reports;
using System.IO;
using System.Xml;
//using Ternium.Sio_Server.Models.Events;
using Ternium.Sio_Server.Models.Gantt;


namespace Ternium.Sio_Server.Controllers
{
    [EnableCORS()]
    [RoutePrefix("api/process")]
    public class ProcessController : Ternium.ApiBaseController
    {

    }
}
